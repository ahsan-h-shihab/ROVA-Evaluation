# REV-001 analysis report (full profile)

Auto-generated from unit results by `rova_revision/analysis.py`. It lists results without interpretation. Plan: `docs/REVISION_ANALYSIS_PLAN.md`. All between-method comparisons use matched worlds (one method-independent world per seed).

## Completeness

- units planned (excluding this analysis): 798; done: 798; failed: 0; not run: 0

- Q-learning stability gate: **passed**
- sequential-oracle decision (plan R7): **no label change: disagreement not substantial**
- protocol-family Holm: 3635 tests

## Verdicts per cell

| env | c | published v2 (own worlds) | frozen pipeline, matched worlds | CEW rule | CEW, TPE-tuned | CEW, protocol budget | Mann–Whitney (archived) | S1 (archived) | G | G 95% CI |
|---|---|---|---|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 0.5 | ROVA_loses | ROVA_loses | ROVA_loses | ROVA_loses | ROVA_loses | ROVA_loses | ROVA_loses | – | – |
| favorable_hmm_coupled | 1.5 | ROVA_loses | ROVA_loses | ROVA_loses | ROVA_loses | mixed | ROVA_loses | ROVA_loses | – | – |
| favorable_hmm_coupled | 3.5 | ROVA_wins | ROVA_wins | ROVA_wins | mixed | mixed | ROVA_wins | mixed | 0.5658 | – |
| favorable_hmm_coupled | 8.0 | ROVA_wins | ROVA_wins | ROVA_wins | mixed | ROVA_wins | ROVA_wins | ROVA_wins | 0.001012 | [0.0004555, 0.002329] |
| favorable_hmm_coupled | 20.0 | ROVA_wins | ROVA_wins | ROVA_wins | mixed | ROVA_wins | ROVA_wins | ROVA_wins | -0.0001582 | [-0.0002972, -8.275e-05] |
| unfavorable_oscillation_uncoupled | 0.5 | mixed | mixed | mixed | mixed | mixed | mixed | mixed | – | – |
| unfavorable_oscillation_uncoupled | 1.5 | ROVA_loses | ROVA_loses | ROVA_loses | mixed | ROVA_loses | ROVA_loses | ROVA_loses | – | – |
| unfavorable_oscillation_uncoupled | 3.5 | mixed | ROVA_wins | ROVA_wins | ROVA_loses | mixed | ROVA_wins | mixed | -0.09886 | [-0.235, -0.04928] |
| unfavorable_oscillation_uncoupled | 8.0 | ROVA_wins | ROVA_wins | ROVA_wins | mixed | ROVA_wins | ROVA_wins | ROVA_wins | -0.001637 | [-0.003588, -0.0006673] |
| unfavorable_oscillation_uncoupled | 20.0 | ROVA_wins | ROVA_wins | ROVA_wins | mixed | ROVA_wins | ROVA_wins | ROVA_wins | -2.12e-05 | [-0.0001236, 2.897e-06] |
| collapse_moderate_coupled | 0.5 | mixed | mixed | mixed | ROVA_loses | mixed | mixed | mixed | – | – |
| collapse_moderate_coupled | 1.5 | mixed | mixed | mixed | ROVA_loses | mixed | mixed | mixed | – | – |
| collapse_moderate_coupled | 3.5 | mixed | mixed | mixed | ROVA_loses | mixed | mixed | mixed | – | – |
| collapse_moderate_coupled | 8.0 | ROVA_wins | ROVA_wins | ROVA_wins | ROVA_loses | ROVA_wins | ROVA_wins | ROVA_wins | 0.001713 | [-0.0001029, 0.004243] |
| collapse_moderate_coupled | 20.0 | ROVA_wins | ROVA_wins | ROVA_wins | mixed | ROVA_wins | ROVA_wins | ROVA_wins | -0.002092 | [-0.004655, -0.001087] |

## Mean regret on the common evaluation worlds (BCa 95%)

| env | c | method | mean | 95% CI | median | oracle a*=0 fraction |
|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 0.5 | static | 0.009771 | [0.008186, 0.01149] | 0.006333 | 0.2517 |
| favorable_hmm_coupled | 0.5 | ewma | 0.01994 | [0.01792, 0.02236] | 0.01858 | 0.2509 |
| favorable_hmm_coupled | 0.5 | rova | 0.03845 | [0.03524, 0.04219] | 0.0344 | 0.2625 |
| favorable_hmm_coupled | 0.5 | A0 | 0.4939 | [0.4859, 0.501] | 0.4942 | 0.06703 |
| favorable_hmm_coupled | 0.5 | A5 | 0.05682 | [0.05031, 0.06388] | 0.05392 | 0.2853 |
| favorable_hmm_coupled | 0.5 | learned | 0.0004017 | [0.0003749, 0.0004327] | 0.0003882 | 0.2594 |
| favorable_hmm_coupled | 0.5 | qlearn | 0.001463 | [0.001366, 0.001564] | 0.001422 | 0.2621 |
| favorable_hmm_coupled | 0.5 | static_ext | 0.01403 | [0.01255, 0.01563] | 0.01343 | 0.2484 |
| favorable_hmm_coupled | 0.5 | ewma_ext | 0.03265 | [0.02937, 0.03735] | 0.03128 | 0.2615 |
| favorable_hmm_coupled | 0.5 | clairvoyant | 0.01401 | [0.0125, 0.01565] | 0.01206 | 0.2522 |
| favorable_hmm_coupled | 0.5 | abl_full | 0.03891 | [0.03533, 0.04292] | 0.03654 | 0.2593 |
| favorable_hmm_coupled | 0.5 | abl_no_memory | 0.0159 | [0.01423, 0.0178] | 0.01459 | 0.253 |
| favorable_hmm_coupled | 0.5 | abl_no_decay | 0.05462 | [0.04839, 0.06116] | 0.05279 | 0.2531 |
| favorable_hmm_coupled | 0.5 | abl_no_propagation | 0.03482 | [0.03077, 0.03947] | 0.02997 | 0.2439 |
| favorable_hmm_coupled | 0.5 | abl_no_stability | 0.02924 | [0.02613, 0.03285] | 0.02678 | 0.2609 |
| favorable_hmm_coupled | 0.5 | rova_single | 0.007959 | [0.007034, 0.00901] | 0.006994 | 0.2556 |
| favorable_hmm_coupled | 0.5 | static_tpe | 0.001852 | [0.001669, 0.002043] | 0.001582 | 0.2577 |
| favorable_hmm_coupled | 0.5 | ewma_tpe | 0.004713 | [0.003772, 0.006117] | 0.002905 | 0.2615 |
| favorable_hmm_coupled | 0.5 | rova_tpe | 0.01623 | [0.01344, 0.019] | 0.01657 | 0.2668 |
| favorable_hmm_coupled | 0.5 | fx_decay-propagation | 0.04659 | [0.04264, 0.05117] | 0.04578 | 0.2492 |
| favorable_hmm_coupled | 0.5 | fx_decay-stability | 0.0333 | [0.02913, 0.03748] | 0.03643 | 0.2702 |
| favorable_hmm_coupled | 0.5 | fx_propagation-stability | 0.03449 | [0.03172, 0.03775] | 0.03178 | 0.2506 |
| favorable_hmm_coupled | 0.5 | fx_memory-decay-propagation | 0.01621 | [0.01378, 0.01931] | 0.01406 | 0.2598 |
| favorable_hmm_coupled | 0.5 | fx_memory-decay-stability | 0.01599 | [0.01419, 0.01817] | 0.01314 | 0.2442 |
| favorable_hmm_coupled | 0.5 | fx_decay-propagation-stability | 0.03184 | [0.02682, 0.03829] | 0.02595 | 0.2601 |
| favorable_hmm_coupled | 0.5 | fx_memory-decay-propagation-stability | 0.02452 | [0.02166, 0.02748] | 0.02266 | 0.258 |
| favorable_hmm_coupled | 0.5 | ewma_out | 0.01833 | [0.01641, 0.02052] | 0.01624 | 0.2589 |
| favorable_hmm_coupled | 0.5 | rova_out | 0.05347 | [0.04906, 0.058] | 0.0542 | 0.2298 |
| favorable_hmm_coupled | 0.5 | static_pb | 0.006345 | [0.005604, 0.007185] | 0.005074 | 0.2533 |
| favorable_hmm_coupled | 0.5 | ewma_pb | 0.01728 | [0.01587, 0.01883] | 0.0166 | 0.2486 |
| favorable_hmm_coupled | 0.5 | rova_pb | 0.02968 | [0.02708, 0.03245] | 0.02935 | 0.2539 |
| favorable_hmm_coupled | 1.5 | static | 0.02756 | [0.02576, 0.02937] | 0.02726 | 0.5436 |
| favorable_hmm_coupled | 1.5 | ewma | 0.06324 | [0.05672, 0.06985] | 0.04932 | 0.5603 |
| favorable_hmm_coupled | 1.5 | rova | 0.07999 | [0.0753, 0.08458] | 0.0815 | 0.5473 |
| favorable_hmm_coupled | 1.5 | A0 | 0.276 | [0.2664, 0.2851] | 0.2782 | 0.3525 |
| favorable_hmm_coupled | 1.5 | A5 | 0.4417 | [0.4175, 0.4663] | 0.4486 | 0.6475 |
| favorable_hmm_coupled | 1.5 | learned | 0.0007808 | [0.00074, 0.0008225] | 0.0007799 | 0.5232 |
| favorable_hmm_coupled | 1.5 | qlearn | 0.003606 | [0.002623, 0.004983] | 0.001391 | 0.5216 |
| favorable_hmm_coupled | 1.5 | static_ext | 0.02603 | [0.02372, 0.02881] | 0.02278 | 0.5304 |
| favorable_hmm_coupled | 1.5 | ewma_ext | 0.06672 | [0.06117, 0.07281] | 0.06292 | 0.5381 |
| favorable_hmm_coupled | 1.5 | clairvoyant | 0.03555 | [0.03318, 0.03823] | 0.03384 | 0.5394 |
| favorable_hmm_coupled | 1.5 | abl_full | 0.0806 | [0.07559, 0.08586] | 0.08056 | 0.546 |
| favorable_hmm_coupled | 1.5 | abl_no_memory | 0.03125 | [0.02876, 0.03383] | 0.02929 | 0.5336 |
| favorable_hmm_coupled | 1.5 | abl_no_decay | 0.07833 | [0.07512, 0.08192] | 0.07682 | 0.5275 |
| favorable_hmm_coupled | 1.5 | abl_no_propagation | 0.06659 | [0.06286, 0.07109] | 0.06434 | 0.5632 |
| favorable_hmm_coupled | 1.5 | abl_no_stability | 0.07715 | [0.07311, 0.08279] | 0.0711 | 0.5242 |
| favorable_hmm_coupled | 1.5 | rova_single | 0.009612 | [0.007924, 0.0117] | 0.005776 | 0.5293 |
| favorable_hmm_coupled | 1.5 | static_tpe | 0.003169 | [0.002859, 0.003517] | 0.002914 | 0.523 |
| favorable_hmm_coupled | 1.5 | ewma_tpe | 0.008427 | [0.007199, 0.009704] | 0.009087 | 0.5288 |
| favorable_hmm_coupled | 1.5 | rova_tpe | 0.01755 | [0.01353, 0.02306] | 0.008646 | 0.5262 |
| favorable_hmm_coupled | 1.5 | fx_decay-propagation | 0.06932 | [0.0633, 0.07455] | 0.07494 | 0.54 |
| favorable_hmm_coupled | 1.5 | fx_decay-stability | 0.08 | [0.07625, 0.08413] | 0.07829 | 0.5305 |
| favorable_hmm_coupled | 1.5 | fx_propagation-stability | 0.07031 | [0.06714, 0.07402] | 0.0669 | 0.5457 |
| favorable_hmm_coupled | 1.5 | fx_memory-decay-propagation | 0.02802 | [0.02455, 0.03157] | 0.02619 | 0.5084 |
| favorable_hmm_coupled | 1.5 | fx_memory-decay-stability | 0.03597 | [0.03267, 0.03963] | 0.02903 | 0.5357 |
| favorable_hmm_coupled | 1.5 | fx_decay-propagation-stability | 0.07959 | [0.07499, 0.08428] | 0.0762 | 0.5535 |
| favorable_hmm_coupled | 1.5 | fx_memory-decay-propagation-stability | 0.03978 | [0.03541, 0.04461] | 0.03641 | 0.5263 |
| favorable_hmm_coupled | 1.5 | ewma_out | 0.05788 | [0.05525, 0.06062] | 0.05773 | 0.5537 |
| favorable_hmm_coupled | 1.5 | rova_out | 0.06936 | [0.06595, 0.07247] | 0.07167 | 0.531 |
| favorable_hmm_coupled | 1.5 | static_pb | 0.02221 | [0.02066, 0.02385] | 0.02043 | 0.5409 |
| favorable_hmm_coupled | 1.5 | ewma_pb | 0.05071 | [0.04758, 0.05427] | 0.04614 | 0.5512 |
| favorable_hmm_coupled | 1.5 | rova_pb | 0.05485 | [0.05059, 0.05947] | 0.05123 | 0.5494 |
| favorable_hmm_coupled | 3.5 | static | 0.09545 | [0.08359, 0.1076] | 0.0888 | 0.7857 |
| favorable_hmm_coupled | 3.5 | ewma | 0.1528 | [0.1383, 0.1654] | 0.1624 | 0.7815 |
| favorable_hmm_coupled | 3.5 | rova | 0.07746 | [0.07212, 0.08364] | 0.07441 | 0.7448 |
| favorable_hmm_coupled | 3.5 | A0 | 0.08764 | [0.08009, 0.09465] | 0.08812 | 0.7294 |
| favorable_hmm_coupled | 3.5 | A5 | 1.478 | [1.412, 1.547] | 1.485 | 0.8626 |
| favorable_hmm_coupled | 3.5 | learned | 0.001989 | [0.001877, 0.002118] | 0.001868 | 0.758 |
| favorable_hmm_coupled | 3.5 | qlearn | 0.00901 | [0.00842, 0.009678] | 0.008918 | 0.7594 |
| favorable_hmm_coupled | 3.5 | static_ext | 0.07197 | [0.06592, 0.07902] | 0.06468 | 0.7514 |
| favorable_hmm_coupled | 3.5 | ewma_ext | 0.08509 | [0.07837, 0.09127] | 0.08403 | 0.7379 |
| favorable_hmm_coupled | 3.5 | clairvoyant | 0.1052 | [0.09442, 0.1166] | 0.102 | 0.7887 |
| favorable_hmm_coupled | 3.5 | abl_full | 0.07803 | [0.07233, 0.08443] | 0.07496 | 0.742 |
| favorable_hmm_coupled | 3.5 | abl_no_memory | 0.05324 | [0.0496, 0.05696] | 0.05238 | 0.7498 |
| favorable_hmm_coupled | 3.5 | abl_no_decay | 0.06791 | [0.06276, 0.07367] | 0.06417 | 0.7446 |
| favorable_hmm_coupled | 3.5 | abl_no_propagation | 0.08178 | [0.07648, 0.0868] | 0.08139 | 0.748 |
| favorable_hmm_coupled | 3.5 | abl_no_stability | 0.06934 | [0.06442, 0.07448] | 0.06493 | 0.7534 |
| favorable_hmm_coupled | 3.5 | rova_single | 0.01841 | [0.01662, 0.02016] | 0.01944 | 0.7584 |
| favorable_hmm_coupled | 3.5 | static_tpe | 0.009662 | [0.009064, 0.01035] | 0.008914 | 0.7577 |
| favorable_hmm_coupled | 3.5 | ewma_tpe | 0.04922 | [0.04112, 0.05796] | 0.04136 | 0.7456 |
| favorable_hmm_coupled | 3.5 | rova_tpe | 0.04256 | [0.03724, 0.0486] | 0.03967 | 0.7542 |
| favorable_hmm_coupled | 3.5 | fx_decay-propagation | 0.0701 | [0.06428, 0.0764] | 0.06709 | 0.7496 |
| favorable_hmm_coupled | 3.5 | fx_decay-stability | 0.07512 | [0.06929, 0.0815] | 0.07146 | 0.7419 |
| favorable_hmm_coupled | 3.5 | fx_propagation-stability | 0.08076 | [0.07501, 0.08595] | 0.08072 | 0.7517 |
| favorable_hmm_coupled | 3.5 | fx_memory-decay-propagation | 0.052 | [0.0487, 0.0549] | 0.054 | 0.759 |
| favorable_hmm_coupled | 3.5 | fx_memory-decay-stability | 0.04915 | [0.04602, 0.05279] | 0.04478 | 0.7554 |
| favorable_hmm_coupled | 3.5 | fx_decay-propagation-stability | 0.07258 | [0.06685, 0.07836] | 0.07029 | 0.746 |
| favorable_hmm_coupled | 3.5 | fx_memory-decay-propagation-stability | 0.05428 | [0.05126, 0.05742] | 0.05301 | 0.7531 |
| favorable_hmm_coupled | 3.5 | ewma_out | 0.1272 | [0.1135, 0.1417] | 0.1136 | 0.7844 |
| favorable_hmm_coupled | 3.5 | rova_out | 0.07693 | [0.07183, 0.08151] | 0.07825 | 0.7603 |
| favorable_hmm_coupled | 3.5 | static_pb | 0.05681 | [0.0494, 0.06485] | 0.04245 | 0.7659 |
| favorable_hmm_coupled | 3.5 | ewma_pb | 0.08617 | [0.07668, 0.09657] | 0.0709 | 0.7616 |
| favorable_hmm_coupled | 3.5 | rova_pb | 0.06693 | [0.06231, 0.0719] | 0.0632 | 0.7512 |
| favorable_hmm_coupled | 8.0 | static | 0.3847 | [0.3486, 0.427] | 0.3535 | 0.9481 |
| favorable_hmm_coupled | 8.0 | ewma | 0.4329 | [0.3981, 0.4624] | 0.4641 | 0.9459 |
| favorable_hmm_coupled | 8.0 | rova | 0.01828 | [0.01567, 0.02118] | 0.01659 | 0.936 |
| favorable_hmm_coupled | 8.0 | A0 | 0.01865 | [0.01602, 0.02178] | 0.01685 | 0.936 |
| favorable_hmm_coupled | 8.0 | A5 | 3.911 | [3.753, 4.062] | 3.931 | 0.966 |
| favorable_hmm_coupled | 8.0 | learned | 0.002965 | [0.002653, 0.003321] | 0.00283 | 0.9368 |
| favorable_hmm_coupled | 8.0 | qlearn | 0.009842 | [0.008669, 0.0112] | 0.008916 | 0.9365 |
| favorable_hmm_coupled | 8.0 | static_ext | 0.01865 | [0.01602, 0.02178] | 0.01685 | 0.936 |
| favorable_hmm_coupled | 8.0 | ewma_ext | 0.01865 | [0.01602, 0.02178] | 0.01685 | 0.936 |
| favorable_hmm_coupled | 8.0 | clairvoyant | 0.4205 | [0.3812, 0.4651] | 0.3998 | 0.9489 |
| favorable_hmm_coupled | 8.0 | abl_full | 0.01826 | [0.01566, 0.02117] | 0.01659 | 0.936 |
| favorable_hmm_coupled | 8.0 | abl_no_memory | 0.02903 | [0.02327, 0.03624] | 0.0209 | 0.9367 |
| favorable_hmm_coupled | 8.0 | abl_no_decay | 0.0324 | [0.02628, 0.04] | 0.02215 | 0.9367 |
| favorable_hmm_coupled | 8.0 | abl_no_propagation | 0.04987 | [0.03898, 0.06201] | 0.02596 | 0.9375 |
| favorable_hmm_coupled | 8.0 | abl_no_stability | 0.05394 | [0.04129, 0.07019] | 0.02753 | 0.9374 |
| favorable_hmm_coupled | 8.0 | rova_single | 0.01587 | [0.01331, 0.01917] | 0.0138 | 0.9365 |
| favorable_hmm_coupled | 8.0 | static_tpe | 0.008399 | [0.007446, 0.009488] | 0.008067 | 0.9365 |
| favorable_hmm_coupled | 8.0 | ewma_tpe | 0.01587 | [0.01351, 0.01838] | 0.01405 | 0.9363 |
| favorable_hmm_coupled | 8.0 | rova_tpe | 0.01828 | [0.01567, 0.02118] | 0.01659 | 0.936 |
| favorable_hmm_coupled | 8.0 | fx_decay-propagation | 0.04445 | [0.0337, 0.05864] | 0.0251 | 0.9371 |
| favorable_hmm_coupled | 8.0 | fx_decay-stability | 0.05066 | [0.03658, 0.0684] | 0.02315 | 0.9376 |
| favorable_hmm_coupled | 8.0 | fx_propagation-stability | 0.02915 | [0.0253, 0.03362] | 0.03019 | 0.9364 |
| favorable_hmm_coupled | 8.0 | fx_memory-decay-propagation | 0.06026 | [0.04731, 0.07642] | 0.04587 | 0.9385 |
| favorable_hmm_coupled | 8.0 | fx_memory-decay-stability | 0.02384 | [0.02063, 0.02755] | 0.02078 | 0.9367 |
| favorable_hmm_coupled | 8.0 | fx_decay-propagation-stability | 0.03701 | [0.03143, 0.04373] | 0.03078 | 0.9369 |
| favorable_hmm_coupled | 8.0 | fx_memory-decay-propagation-stability | 0.06861 | [0.05305, 0.08749] | 0.02838 | 0.9391 |
| favorable_hmm_coupled | 8.0 | ewma_out | 0.4009 | [0.3609, 0.4431] | 0.3641 | 0.9472 |
| favorable_hmm_coupled | 8.0 | rova_out | 0.1551 | [0.127, 0.1858] | 0.094 | 0.9417 |
| favorable_hmm_coupled | 8.0 | static_pb | 0.2148 | [0.1842, 0.243] | 0.215 | 0.9441 |
| favorable_hmm_coupled | 8.0 | ewma_pb | 0.2071 | [0.1737, 0.2422] | 0.207 | 0.9419 |
| favorable_hmm_coupled | 8.0 | rova_pb | 0.01863 | [0.016, 0.02176] | 0.01685 | 0.936 |
| favorable_hmm_coupled | 20.0 | static | 1.272 | [1.171, 1.376] | 1.27 | 0.9923 |
| favorable_hmm_coupled | 20.0 | ewma | 1.262 | [1.181, 1.332] | 1.355 | 0.992 |
| favorable_hmm_coupled | 20.0 | rova | 0.00339 | [0.002738, 0.004283] | 0.003062 | 0.9908 |
| favorable_hmm_coupled | 20.0 | A0 | 0.003191 | [0.002529, 0.004082] | 0.002888 | 0.9908 |
| favorable_hmm_coupled | 20.0 | A5 | 10.7 | [10.37, 11.06] | 10.56 | 0.9944 |
| favorable_hmm_coupled | 20.0 | learned | 0.002187 | [0.001737, 0.002753] | 0.001841 | 0.9908 |
| favorable_hmm_coupled | 20.0 | qlearn | 0.005576 | [0.004247, 0.007345] | 0.003165 | 0.9908 |
| favorable_hmm_coupled | 20.0 | static_ext | 0.003191 | [0.002529, 0.004082] | 0.002888 | 0.9908 |
| favorable_hmm_coupled | 20.0 | ewma_ext | 0.003191 | [0.002529, 0.004082] | 0.002888 | 0.9908 |
| favorable_hmm_coupled | 20.0 | clairvoyant | 1.412 | [1.299, 1.528] | 1.41 | 0.9924 |
| favorable_hmm_coupled | 20.0 | abl_full | 0.00339 | [0.002738, 0.004283] | 0.003062 | 0.9908 |
| favorable_hmm_coupled | 20.0 | abl_no_memory | 0.05846 | [0.03318, 0.09113] | 0.003673 | 0.9909 |
| favorable_hmm_coupled | 20.0 | abl_no_decay | 0.0676 | [0.04438, 0.09735] | 0.007508 | 0.9909 |
| favorable_hmm_coupled | 20.0 | abl_no_propagation | 0.09614 | [0.06724, 0.1284] | 0.005367 | 0.991 |
| favorable_hmm_coupled | 20.0 | abl_no_stability | 0.1203 | [0.08194, 0.1682] | 0.005828 | 0.991 |
| favorable_hmm_coupled | 20.0 | rova_single | 0.003191 | [0.002529, 0.004082] | 0.002888 | 0.9908 |
| favorable_hmm_coupled | 20.0 | static_tpe | 0.002996 | [0.002447, 0.003734] | 0.002754 | 0.9908 |
| favorable_hmm_coupled | 20.0 | ewma_tpe | 0.004764 | [0.003701, 0.006225] | 0.003489 | 0.9908 |
| favorable_hmm_coupled | 20.0 | rova_tpe | 0.003191 | [0.002529, 0.004082] | 0.002888 | 0.9908 |
| favorable_hmm_coupled | 20.0 | fx_decay-propagation | 0.1144 | [0.07307, 0.1732] | 0.02072 | 0.9909 |
| favorable_hmm_coupled | 20.0 | fx_decay-stability | 0.1293 | [0.07458, 0.2] | 0.005972 | 0.9911 |
| favorable_hmm_coupled | 20.0 | fx_propagation-stability | 0.04229 | [0.03168, 0.05689] | 0.0258 | 0.9908 |
| favorable_hmm_coupled | 20.0 | fx_memory-decay-propagation | 0.1944 | [0.1423, 0.2591] | 0.1356 | 0.9911 |
| favorable_hmm_coupled | 20.0 | fx_memory-decay-stability | 0.04493 | [0.03039, 0.06513] | 0.0128 | 0.9909 |
| favorable_hmm_coupled | 20.0 | fx_decay-propagation-stability | 0.07957 | [0.05955, 0.1069] | 0.04985 | 0.9909 |
| favorable_hmm_coupled | 20.0 | fx_memory-decay-propagation-stability | 0.2258 | [0.1678, 0.2971] | 0.0983 | 0.9911 |
| favorable_hmm_coupled | 20.0 | ewma_out | 1.273 | [1.166, 1.384] | 1.236 | 0.9923 |
| favorable_hmm_coupled | 20.0 | rova_out | 0.4898 | [0.4023, 0.5834] | 0.318 | 0.9915 |
| favorable_hmm_coupled | 20.0 | static_pb | 0.7935 | [0.6875, 0.8877] | 0.7727 | 0.9918 |
| favorable_hmm_coupled | 20.0 | ewma_pb | 0.637 | [0.5271, 0.756] | 0.6343 | 0.9915 |
| favorable_hmm_coupled | 20.0 | rova_pb | 0.003191 | [0.002529, 0.004082] | 0.002888 | 0.9908 |
| unfavorable_oscillation_uncoupled | 0.5 | static | 0.003579 | [0.002728, 0.004489] | 0.001761 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | ewma | 0.001072 | [0.00081, 0.001407] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | rova | 0.01 | [0.005402, 0.01645] | 0.00137 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | A0 | 0.4285 | [0.4175, 0.4395] | 0.4261 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | A5 | 0.001072 | [0.00081, 0.001407] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | learned | 0.0004 | [0.0002712, 0.0005704] | 0.0001483 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | qlearn | 0.000748 | [0.0005748, 0.0009534] | 0.0003985 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | static_ext | 0.003614 | [0.002754, 0.004646] | 0.00182 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | ewma_ext | 0.001072 | [0.00081, 0.001407] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | clairvoyant | 0.01299 | [0.01082, 0.01533] | 0.01382 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | abl_full | 0.01 | [0.005402, 0.01645] | 0.00137 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | abl_no_memory | 0.005623 | [0.004293, 0.007008] | 0.002885 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | abl_no_decay | 0.0176 | [0.01046, 0.02739] | 0.0008518 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | abl_no_propagation | 0.001379 | [0.001002, 0.002154] | 0.0007455 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | abl_no_stability | 0.002874 | [0.001213, 0.007133] | 0.0007455 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | rova_single | 0.000846 | [0.0006402, 0.001104] | 0.0004755 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | static_tpe | 0.0007339 | [0.0005545, 0.0009593] | 0.0004022 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | ewma_tpe | 0.001014 | [0.0007658, 0.001345] | 0.0006633 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | rova_tpe | 0.001081 | [0.0008154, 0.001427] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_decay-propagation | 0.006413 | [0.003297, 0.01154] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_decay-stability | 0.001072 | [0.00081, 0.001407] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_propagation-stability | 0.001073 | [0.0008105, 0.00141] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_memory-decay-propagation | 0.006075 | [0.005282, 0.006871] | 0.006517 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_memory-decay-stability | 0.004928 | [0.003808, 0.006376] | 0.003014 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_decay-propagation-stability | 0.008181 | [0.00454, 0.01371] | 0.0009209 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | fx_memory-decay-propagation-stability | 0.009584 | [0.007417, 0.01195] | 0.005635 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | ewma_out | 0.001516 | [0.001097, 0.002218] | 0.0007848 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | rova_out | 0.01643 | [0.01146, 0.02203] | 0.002775 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | static_pb | 0.001022 | [0.0008028, 0.001292] | 0.0007211 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | ewma_pb | 0.001072 | [0.00081, 0.001407] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 0.5 | rova_pb | 0.001322 | [0.0009244, 0.002394] | 0.0007126 | 0.02447 |
| unfavorable_oscillation_uncoupled | 1.5 | static | 0.03218 | [0.02941, 0.03504] | 0.0319 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | ewma | 0.06917 | [0.06368, 0.07444] | 0.0648 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | rova | 0.08907 | [0.08293, 0.09495] | 0.08696 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | A0 | 0.2126 | [0.1963, 0.2305] | 0.2042 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | A5 | 0.1438 | [0.1289, 0.1578] | 0.1471 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | learned | 0.00229 | [0.00207, 0.002551] | 0.002186 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | qlearn | 0.007077 | [0.005735, 0.008878] | 0.004928 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | static_ext | 0.02929 | [0.02681, 0.03209] | 0.02781 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | ewma_ext | 0.06191 | [0.05766, 0.06651] | 0.05788 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | clairvoyant | 0.02159 | [0.01949, 0.02385] | 0.02035 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | abl_full | 0.08965 | [0.08406, 0.09519] | 0.08696 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | abl_no_memory | 0.03335 | [0.03075, 0.03672] | 0.0312 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | abl_no_decay | 0.08595 | [0.08182, 0.09018] | 0.08529 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | abl_no_propagation | 0.08408 | [0.07847, 0.09056] | 0.0764 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | abl_no_stability | 0.1017 | [0.09593, 0.1071] | 0.09885 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | rova_single | 0.01473 | [0.012, 0.01795] | 0.01134 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | static_tpe | 0.00291 | [0.00266, 0.003197] | 0.002756 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | ewma_tpe | 0.04676 | [0.03779, 0.05754] | 0.04903 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | rova_tpe | 0.03957 | [0.03207, 0.04949] | 0.02827 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_decay-propagation | 0.06754 | [0.06034, 0.07554] | 0.05823 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_decay-stability | 0.08296 | [0.07778, 0.08813] | 0.08134 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_propagation-stability | 0.08738 | [0.08267, 0.09264] | 0.08894 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_memory-decay-propagation | 0.03295 | [0.02883, 0.03728] | 0.032 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_memory-decay-stability | 0.04189 | [0.03812, 0.04616] | 0.03667 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_decay-propagation-stability | 0.09658 | [0.09009, 0.1024] | 0.09957 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | fx_memory-decay-propagation-stability | 0.04028 | [0.03682, 0.044] | 0.04002 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | ewma_out | 0.09784 | [0.09091, 0.1046] | 0.09653 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | rova_out | 0.1028 | [0.09607, 0.1097] | 0.107 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | static_pb | 0.02759 | [0.02555, 0.02958] | 0.02969 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | ewma_pb | 0.06391 | [0.06069, 0.06709] | 0.06408 | 0.4584 |
| unfavorable_oscillation_uncoupled | 1.5 | rova_pb | 0.07459 | [0.07002, 0.07949] | 0.0743 | 0.4584 |
| unfavorable_oscillation_uncoupled | 3.5 | static | 0.1118 | [0.09622, 0.1295] | 0.09874 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | ewma | 0.1638 | [0.1464, 0.1785] | 0.1799 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | rova | 0.05863 | [0.0428, 0.07706] | 0.02654 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | A0 | 0.05338 | [0.03847, 0.07104] | 0.02383 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | A5 | 0.7596 | [0.7003, 0.8211] | 0.7728 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | learned | 0.005167 | [0.004507, 0.005897] | 0.004592 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | qlearn | 0.01814 | [0.01454, 0.02306] | 0.01294 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | static_ext | 0.05419 | [0.03996, 0.07079] | 0.03728 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | ewma_ext | 0.05338 | [0.03847, 0.07104] | 0.02383 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | clairvoyant | 0.1089 | [0.09455, 0.1251] | 0.09195 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | abl_full | 0.0537 | [0.03915, 0.07095] | 0.0232 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | abl_no_memory | 0.03999 | [0.03376, 0.04668] | 0.03444 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | abl_no_decay | 0.05802 | [0.04244, 0.07655] | 0.02971 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | abl_no_propagation | 0.0569 | [0.0412, 0.07623] | 0.02516 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | abl_no_stability | 0.05274 | [0.03953, 0.06809] | 0.02862 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | rova_single | 0.03205 | [0.02167, 0.04852] | 0.01237 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | static_tpe | 0.01385 | [0.01217, 0.01608] | 0.01211 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | ewma_tpe | 0.02539 | [0.01665, 0.0418] | 0.01406 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | rova_tpe | 0.05326 | [0.03845, 0.07099] | 0.0239 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_decay-propagation | 0.0462 | [0.03354, 0.0618] | 0.02383 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_decay-stability | 0.05473 | [0.04109, 0.07043] | 0.04159 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_propagation-stability | 0.05203 | [0.0387, 0.06759] | 0.02422 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_memory-decay-propagation | 0.04617 | [0.03781, 0.05676] | 0.03866 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_memory-decay-stability | 0.0426 | [0.03514, 0.05276] | 0.03522 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_decay-propagation-stability | 0.05358 | [0.03868, 0.07123] | 0.02422 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | fx_memory-decay-propagation-stability | 0.03974 | [0.03297, 0.04698] | 0.03632 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | ewma_out | 0.1414 | [0.1242, 0.1565] | 0.1636 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | rova_out | 0.07598 | [0.06279, 0.09055] | 0.07575 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | static_pb | 0.0531 | [0.04396, 0.06305] | 0.03772 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | ewma_pb | 0.07187 | [0.05752, 0.08806] | 0.06135 | 0.8197 |
| unfavorable_oscillation_uncoupled | 3.5 | rova_pb | 0.05023 | [0.03768, 0.06524] | 0.02383 | 0.8197 |
| unfavorable_oscillation_uncoupled | 8.0 | static | 0.3875 | [0.3452, 0.4355] | 0.3693 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | ewma | 0.4193 | [0.3764, 0.4618] | 0.4445 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | rova | 0.01301 | [0.008274, 0.01998] | 0.001157 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | A0 | 0.01239 | [0.007742, 0.0194] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | A5 | 2.354 | [2.192, 2.531] | 2.366 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | learned | 0.005495 | [0.003719, 0.007833] | 0.0007068 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | qlearn | 0.01319 | [0.008183, 0.02057] | 0.0009606 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | static_ext | 0.01239 | [0.007742, 0.0194] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | ewma_ext | 0.01239 | [0.007742, 0.0194] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | clairvoyant | 0.4148 | [0.3601, 0.4783] | 0.3913 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | abl_full | 0.01301 | [0.008274, 0.01998] | 0.001157 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | abl_no_memory | 0.02094 | [0.01475, 0.02772] | 0.004453 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | abl_no_decay | 0.01239 | [0.007742, 0.0194] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | abl_no_propagation | 0.02325 | [0.01643, 0.03552] | 0.01247 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | abl_no_stability | 0.0203 | [0.01373, 0.02995] | 0.007802 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | rova_single | 0.01239 | [0.007742, 0.0194] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | static_tpe | 0.01014 | [0.007607, 0.01364] | 0.006576 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | ewma_tpe | 0.0123 | [0.007682, 0.01925] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | rova_tpe | 0.01252 | [0.007835, 0.01959] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_decay-propagation | 0.03081 | [0.02111, 0.04268] | 0.005819 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_decay-stability | 0.04503 | [0.02982, 0.0633] | 0.004235 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_propagation-stability | 0.01326 | [0.008559, 0.0202] | 0.003185 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_memory-decay-propagation | 0.0492 | [0.03762, 0.06273] | 0.03361 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_memory-decay-stability | 0.01769 | [0.01325, 0.0231] | 0.00789 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_decay-propagation-stability | 0.01315 | [0.008313, 0.02037] | 0.001157 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | fx_memory-decay-propagation-stability | 0.06556 | [0.05024, 0.08475] | 0.02604 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | ewma_out | 0.3854 | [0.3383, 0.4288] | 0.3905 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | rova_out | 0.1477 | [0.1124, 0.1868] | 0.05672 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | static_pb | 0.2183 | [0.1813, 0.2565] | 0.1875 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | ewma_pb | 0.1783 | [0.1349, 0.2317] | 0.1392 | 0.9606 |
| unfavorable_oscillation_uncoupled | 8.0 | rova_pb | 0.01239 | [0.007742, 0.0194] | 0.0006817 | 0.9606 |
| unfavorable_oscillation_uncoupled | 20.0 | static | 1.239 | [1.12, 1.371] | 1.181 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | ewma | 1.174 | [1.054, 1.288] | 1.143 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | rova | 0.004695 | [0.002647, 0.008283] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | A0 | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | A5 | 6.637 | [6.184, 7.101] | 6.358 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | learned | 0.004647 | [0.002629, 0.00818] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | qlearn | 0.00572 | [0.003342, 0.009576] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | static_ext | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | ewma_ext | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | clairvoyant | 1.302 | [1.139, 1.488] | 1.276 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | abl_full | 0.004854 | [0.002778, 0.008473] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | abl_no_memory | 0.03466 | [0.02036, 0.0528] | 0.0009857 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | abl_no_decay | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | abl_no_propagation | 0.04544 | [0.03028, 0.07205] | 0.006159 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | abl_no_stability | 0.03578 | [0.01595, 0.07853] | 8.988e-05 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | rova_single | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | static_tpe | 0.004353 | [0.002543, 0.007474] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | ewma_tpe | 0.004795 | [0.002673, 0.008764] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | rova_tpe | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_decay-propagation | 0.05692 | [0.03384, 0.09088] | 0.0003686 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_decay-stability | 0.1 | [0.04554, 0.1952] | 8.988e-05 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_propagation-stability | 0.00601 | [0.003707, 0.009465] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_memory-decay-propagation | 0.1319 | [0.09718, 0.1739] | 0.09991 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_memory-decay-stability | 0.03421 | [0.02388, 0.04828] | 0.01111 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_decay-propagation-stability | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | fx_memory-decay-propagation-stability | 0.2056 | [0.1493, 0.2728] | 0.07337 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | ewma_out | 1.094 | [0.961, 1.215] | 1.128 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | rova_out | 0.4471 | [0.3339, 0.5745] | 0.1723 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | static_pb | 0.7311 | [0.6249, 0.8317] | 0.7264 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | ewma_pb | 0.5311 | [0.4017, 0.6771] | 0.5432 | 0.9905 |
| unfavorable_oscillation_uncoupled | 20.0 | rova_pb | 0.00467 | [0.002634, 0.008281] | 0 | 0.9905 |
| collapse_moderate_coupled | 0.5 | static | 0.008642 | [0.007402, 0.01012] | 0.00765 | 0.4345 |
| collapse_moderate_coupled | 0.5 | ewma | 0.01339 | [0.01173, 0.01544] | 0.01273 | 0.4345 |
| collapse_moderate_coupled | 0.5 | rova | 0.01549 | [0.01308, 0.01814] | 0.01429 | 0.4354 |
| collapse_moderate_coupled | 0.5 | A0 | 0.382 | [0.3703, 0.3944] | 0.3786 | 0.4303 |
| collapse_moderate_coupled | 0.5 | A5 | 0.0683 | [0.06277, 0.07445] | 0.06776 | 0.4369 |
| collapse_moderate_coupled | 0.5 | learned | 0.0004289 | [0.0003588, 0.0005054] | 0.0003828 | 0.4356 |
| collapse_moderate_coupled | 0.5 | qlearn | 0.003802 | [0.002876, 0.005111] | 0.001923 | 0.4353 |
| collapse_moderate_coupled | 0.5 | static_ext | 0.009654 | [0.008278, 0.01135] | 0.007939 | 0.435 |
| collapse_moderate_coupled | 0.5 | ewma_ext | 0.01938 | [0.018, 0.02119] | 0.01942 | 0.4353 |
| collapse_moderate_coupled | 0.5 | clairvoyant | 0.003271 | [0.002531, 0.004103] | 0.002387 | 0.434 |
| collapse_moderate_coupled | 0.5 | abl_full | 0.01549 | [0.01308, 0.01814] | 0.01429 | 0.4354 |
| collapse_moderate_coupled | 0.5 | abl_no_memory | 0.01041 | [0.009421, 0.01156] | 0.009868 | 0.4347 |
| collapse_moderate_coupled | 0.5 | abl_no_decay | 0.02421 | [0.01998, 0.02924] | 0.0143 | 0.435 |
| collapse_moderate_coupled | 0.5 | abl_no_propagation | 0.007765 | [0.006046, 0.0103] | 0.004652 | 0.4344 |
| collapse_moderate_coupled | 0.5 | abl_no_stability | 0.005658 | [0.004955, 0.006566] | 0.004897 | 0.4335 |
| collapse_moderate_coupled | 0.5 | rova_single | 0.002179 | [0.001823, 0.002601] | 0.001923 | 0.4346 |
| collapse_moderate_coupled | 0.5 | static_tpe | 0.001201 | [0.001005, 0.001486] | 0.000983 | 0.4348 |
| collapse_moderate_coupled | 0.5 | ewma_tpe | 0.002 | [0.001695, 0.002395] | 0.001742 | 0.4346 |
| collapse_moderate_coupled | 0.5 | rova_tpe | 0.002453 | [0.002161, 0.002901] | 0.002055 | 0.4353 |
| collapse_moderate_coupled | 0.5 | fx_decay-propagation | 0.01854 | [0.01582, 0.02154] | 0.01808 | 0.4349 |
| collapse_moderate_coupled | 0.5 | fx_decay-stability | 0.02463 | [0.02234, 0.02729] | 0.02225 | 0.4359 |
| collapse_moderate_coupled | 0.5 | fx_propagation-stability | 0.004305 | [0.003803, 0.004914] | 0.003878 | 0.4341 |
| collapse_moderate_coupled | 0.5 | fx_memory-decay-propagation | 0.01638 | [0.01444, 0.01944] | 0.01458 | 0.4347 |
| collapse_moderate_coupled | 0.5 | fx_memory-decay-stability | 0.008453 | [0.007315, 0.009688] | 0.008879 | 0.4345 |
| collapse_moderate_coupled | 0.5 | fx_decay-propagation-stability | 0.01265 | [0.01086, 0.01469] | 0.01207 | 0.435 |
| collapse_moderate_coupled | 0.5 | fx_memory-decay-propagation-stability | 0.01351 | [0.01216, 0.01525] | 0.0124 | 0.4349 |
| collapse_moderate_coupled | 0.5 | ewma_out | 0.00739 | [0.006189, 0.008835] | 0.006233 | 0.4346 |
| collapse_moderate_coupled | 0.5 | rova_out | 0.02053 | [0.01809, 0.02322] | 0.01901 | 0.434 |
| collapse_moderate_coupled | 0.5 | static_pb | 0.006944 | [0.005763, 0.008357] | 0.005672 | 0.4348 |
| collapse_moderate_coupled | 0.5 | ewma_pb | 0.01072 | [0.008977, 0.01254] | 0.01142 | 0.4344 |
| collapse_moderate_coupled | 0.5 | rova_pb | 0.00599 | [0.005263, 0.00687] | 0.005299 | 0.4345 |
| collapse_moderate_coupled | 1.5 | static | 0.01107 | [0.009331, 0.01299] | 0.01002 | 0.526 |
| collapse_moderate_coupled | 1.5 | ewma | 0.04305 | [0.03476, 0.05209] | 0.02587 | 0.5234 |
| collapse_moderate_coupled | 1.5 | rova | 0.02879 | [0.02473, 0.03363] | 0.02306 | 0.525 |
| collapse_moderate_coupled | 1.5 | A0 | 0.2656 | [0.2549, 0.2758] | 0.2634 | 0.5095 |
| collapse_moderate_coupled | 1.5 | A5 | 0.3743 | [0.3581, 0.3917] | 0.3675 | 0.5273 |
| collapse_moderate_coupled | 1.5 | learned | 0.0002884 | [0.0002245, 0.0003598] | 0.0001809 | 0.5255 |
| collapse_moderate_coupled | 1.5 | qlearn | 0.009425 | [0.006699, 0.01342] | 0.003264 | 0.5249 |
| collapse_moderate_coupled | 1.5 | static_ext | 0.0169 | [0.01384, 0.02043] | 0.01412 | 0.5248 |
| collapse_moderate_coupled | 1.5 | ewma_ext | 0.04536 | [0.03977, 0.05136] | 0.04634 | 0.5238 |
| collapse_moderate_coupled | 1.5 | clairvoyant | 0.004569 | [0.003695, 0.005792] | 0.003291 | 0.5265 |
| collapse_moderate_coupled | 1.5 | abl_full | 0.02879 | [0.02473, 0.03363] | 0.02306 | 0.525 |
| collapse_moderate_coupled | 1.5 | abl_no_memory | 0.01493 | [0.01241, 0.01763] | 0.01375 | 0.525 |
| collapse_moderate_coupled | 1.5 | abl_no_decay | 0.04299 | [0.03794, 0.04853] | 0.04446 | 0.5237 |
| collapse_moderate_coupled | 1.5 | abl_no_propagation | 0.01619 | [0.01367, 0.01895] | 0.01274 | 0.5257 |
| collapse_moderate_coupled | 1.5 | abl_no_stability | 0.02222 | [0.01861, 0.0273] | 0.01471 | 0.5269 |
| collapse_moderate_coupled | 1.5 | rova_single | 0.002154 | [0.001679, 0.002883] | 0.001435 | 0.5256 |
| collapse_moderate_coupled | 1.5 | static_tpe | 0.0004775 | [0.0003993, 0.00058] | 0.000414 | 0.5254 |
| collapse_moderate_coupled | 1.5 | ewma_tpe | 0.001819 | [0.001535, 0.002186] | 0.001497 | 0.526 |
| collapse_moderate_coupled | 1.5 | rova_tpe | 0.004292 | [0.003649, 0.005095] | 0.003458 | 0.5261 |
| collapse_moderate_coupled | 1.5 | fx_decay-propagation | 0.0364 | [0.03146, 0.04146] | 0.03529 | 0.5247 |
| collapse_moderate_coupled | 1.5 | fx_decay-stability | 0.05738 | [0.05183, 0.06551] | 0.05263 | 0.5238 |
| collapse_moderate_coupled | 1.5 | fx_propagation-stability | 0.01771 | [0.01545, 0.02119] | 0.01351 | 0.5262 |
| collapse_moderate_coupled | 1.5 | fx_memory-decay-propagation | 0.01786 | [0.01421, 0.02258] | 0.01193 | 0.524 |
| collapse_moderate_coupled | 1.5 | fx_memory-decay-stability | 0.01961 | [0.01537, 0.02469] | 0.01116 | 0.5249 |
| collapse_moderate_coupled | 1.5 | fx_decay-propagation-stability | 0.043 | [0.03719, 0.05064] | 0.03272 | 0.5257 |
| collapse_moderate_coupled | 1.5 | fx_memory-decay-propagation-stability | 0.02751 | [0.022, 0.03344] | 0.02065 | 0.5235 |
| collapse_moderate_coupled | 1.5 | ewma_out | 0.01685 | [0.01502, 0.01892] | 0.01594 | 0.5264 |
| collapse_moderate_coupled | 1.5 | rova_out | 0.02166 | [0.01929, 0.02461] | 0.02064 | 0.526 |
| collapse_moderate_coupled | 1.5 | static_pb | 0.009691 | [0.008251, 0.01135] | 0.009043 | 0.5249 |
| collapse_moderate_coupled | 1.5 | ewma_pb | 0.02052 | [0.01765, 0.024] | 0.01913 | 0.5255 |
| collapse_moderate_coupled | 1.5 | rova_pb | 0.01066 | [0.008749, 0.01305] | 0.009031 | 0.5261 |
| collapse_moderate_coupled | 3.5 | static | 0.05057 | [0.04524, 0.05685] | 0.04693 | 0.7457 |
| collapse_moderate_coupled | 3.5 | ewma | 0.09196 | [0.08185, 0.1048] | 0.07308 | 0.745 |
| collapse_moderate_coupled | 3.5 | rova | 0.06254 | [0.05866, 0.06716] | 0.06094 | 0.743 |
| collapse_moderate_coupled | 3.5 | A0 | 0.0973 | [0.08705, 0.1102] | 0.09201 | 0.7134 |
| collapse_moderate_coupled | 3.5 | A5 | 1.152 | [1.106, 1.2] | 1.169 | 0.7709 |
| collapse_moderate_coupled | 3.5 | learned | 0.002763 | [0.002505, 0.003032] | 0.002677 | 0.738 |
| collapse_moderate_coupled | 3.5 | qlearn | 0.02216 | [0.01695, 0.02875] | 0.01076 | 0.7363 |
| collapse_moderate_coupled | 3.5 | static_ext | 0.05251 | [0.04852, 0.05802] | 0.04841 | 0.7492 |
| collapse_moderate_coupled | 3.5 | ewma_ext | 0.0885 | [0.07835, 0.1016] | 0.07541 | 0.729 |
| collapse_moderate_coupled | 3.5 | clairvoyant | 0.06598 | [0.06078, 0.07262] | 0.06037 | 0.7534 |
| collapse_moderate_coupled | 3.5 | abl_full | 0.06453 | [0.06017, 0.06925] | 0.06361 | 0.7408 |
| collapse_moderate_coupled | 3.5 | abl_no_memory | 0.05211 | [0.04927, 0.05552] | 0.05153 | 0.7418 |
| collapse_moderate_coupled | 3.5 | abl_no_decay | 0.06137 | [0.05629, 0.06864] | 0.05611 | 0.7428 |
| collapse_moderate_coupled | 3.5 | abl_no_propagation | 0.0727 | [0.06747, 0.0803] | 0.06637 | 0.7359 |
| collapse_moderate_coupled | 3.5 | abl_no_stability | 0.06246 | [0.05766, 0.06953] | 0.0587 | 0.7425 |
| collapse_moderate_coupled | 3.5 | rova_single | 0.01301 | [0.01172, 0.01461] | 0.01185 | 0.7419 |
| collapse_moderate_coupled | 3.5 | static_tpe | 0.009663 | [0.008548, 0.01109] | 0.008654 | 0.7413 |
| collapse_moderate_coupled | 3.5 | ewma_tpe | 0.01656 | [0.01448, 0.01891] | 0.01352 | 0.738 |
| collapse_moderate_coupled | 3.5 | rova_tpe | 0.04588 | [0.03989, 0.05337] | 0.03896 | 0.7422 |
| collapse_moderate_coupled | 3.5 | fx_decay-propagation | 0.06782 | [0.0634, 0.07255] | 0.06674 | 0.7399 |
| collapse_moderate_coupled | 3.5 | fx_decay-stability | 0.06673 | [0.06167, 0.07243] | 0.06761 | 0.7408 |
| collapse_moderate_coupled | 3.5 | fx_propagation-stability | 0.06765 | [0.06368, 0.07248] | 0.06542 | 0.7433 |
| collapse_moderate_coupled | 3.5 | fx_memory-decay-propagation | 0.0495 | [0.04563, 0.05371] | 0.04862 | 0.743 |
| collapse_moderate_coupled | 3.5 | fx_memory-decay-stability | 0.05061 | [0.0477, 0.05411] | 0.04909 | 0.7373 |
| collapse_moderate_coupled | 3.5 | fx_decay-propagation-stability | 0.07087 | [0.0656, 0.0766] | 0.06914 | 0.7348 |
| collapse_moderate_coupled | 3.5 | fx_memory-decay-propagation-stability | 0.05694 | [0.05371, 0.06068] | 0.05624 | 0.7402 |
| collapse_moderate_coupled | 3.5 | ewma_out | 0.06457 | [0.059, 0.07078] | 0.06084 | 0.7458 |
| collapse_moderate_coupled | 3.5 | rova_out | 0.06253 | [0.05894, 0.06719] | 0.0597 | 0.7433 |
| collapse_moderate_coupled | 3.5 | static_pb | 0.03862 | [0.03502, 0.04239] | 0.0375 | 0.7432 |
| collapse_moderate_coupled | 3.5 | ewma_pb | 0.06703 | [0.06198, 0.07356] | 0.06005 | 0.7412 |
| collapse_moderate_coupled | 3.5 | rova_pb | 0.05948 | [0.05521, 0.06573] | 0.05575 | 0.7423 |
| collapse_moderate_coupled | 8.0 | static | 0.2592 | [0.2341, 0.2863] | 0.2574 | 0.9231 |
| collapse_moderate_coupled | 8.0 | ewma | 0.3377 | [0.3101, 0.369] | 0.3232 | 0.9241 |
| collapse_moderate_coupled | 8.0 | rova | 0.02828 | [0.02355, 0.03374] | 0.02758 | 0.9171 |
| collapse_moderate_coupled | 8.0 | A0 | 0.02867 | [0.02369, 0.03406] | 0.02761 | 0.9171 |
| collapse_moderate_coupled | 8.0 | A5 | 3.027 | [2.919, 3.134] | 3.064 | 0.9307 |
| collapse_moderate_coupled | 8.0 | learned | 0.004804 | [0.00414, 0.005519] | 0.004683 | 0.9179 |
| collapse_moderate_coupled | 8.0 | qlearn | 0.01708 | [0.01452, 0.02031] | 0.01542 | 0.9177 |
| collapse_moderate_coupled | 8.0 | static_ext | 0.02867 | [0.02369, 0.03406] | 0.02761 | 0.9171 |
| collapse_moderate_coupled | 8.0 | ewma_ext | 0.02867 | [0.02369, 0.03406] | 0.02761 | 0.9171 |
| collapse_moderate_coupled | 8.0 | clairvoyant | 0.2775 | [0.2518, 0.3063] | 0.2548 | 0.9234 |
| collapse_moderate_coupled | 8.0 | abl_full | 0.02828 | [0.02355, 0.03374] | 0.02758 | 0.9171 |
| collapse_moderate_coupled | 8.0 | abl_no_memory | 0.03749 | [0.0306, 0.04576] | 0.02953 | 0.9179 |
| collapse_moderate_coupled | 8.0 | abl_no_decay | 0.05535 | [0.04549, 0.06585] | 0.04024 | 0.9178 |
| collapse_moderate_coupled | 8.0 | abl_no_propagation | 0.06267 | [0.05102, 0.07511] | 0.04811 | 0.9183 |
| collapse_moderate_coupled | 8.0 | abl_no_stability | 0.06493 | [0.05255, 0.07837] | 0.04659 | 0.9183 |
| collapse_moderate_coupled | 8.0 | rova_single | 0.02173 | [0.01821, 0.02602] | 0.02042 | 0.9176 |
| collapse_moderate_coupled | 8.0 | static_tpe | 0.01294 | [0.01104, 0.01512] | 0.01263 | 0.9176 |
| collapse_moderate_coupled | 8.0 | ewma_tpe | 0.0163 | [0.01374, 0.0192] | 0.01534 | 0.9175 |
| collapse_moderate_coupled | 8.0 | rova_tpe | 0.02867 | [0.02369, 0.03406] | 0.02761 | 0.9171 |
| collapse_moderate_coupled | 8.0 | fx_decay-propagation | 0.06258 | [0.05137, 0.07499] | 0.05028 | 0.918 |
| collapse_moderate_coupled | 8.0 | fx_decay-stability | 0.05534 | [0.04504, 0.06904] | 0.04427 | 0.9177 |
| collapse_moderate_coupled | 8.0 | fx_propagation-stability | 0.06887 | [0.05909, 0.07938] | 0.0642 | 0.9182 |
| collapse_moderate_coupled | 8.0 | fx_memory-decay-propagation | 0.06143 | [0.05096, 0.074] | 0.05336 | 0.9182 |
| collapse_moderate_coupled | 8.0 | fx_memory-decay-stability | 0.03355 | [0.02851, 0.03896] | 0.03367 | 0.9176 |
| collapse_moderate_coupled | 8.0 | fx_decay-propagation-stability | 0.08548 | [0.0756, 0.09561] | 0.08265 | 0.9182 |
| collapse_moderate_coupled | 8.0 | fx_memory-decay-propagation-stability | 0.07244 | [0.0589, 0.08802] | 0.04838 | 0.9188 |
| collapse_moderate_coupled | 8.0 | ewma_out | 0.2782 | [0.252, 0.3059] | 0.2795 | 0.9231 |
| collapse_moderate_coupled | 8.0 | rova_out | 0.09771 | [0.08785, 0.1068] | 0.1005 | 0.9197 |
| collapse_moderate_coupled | 8.0 | static_pb | 0.1647 | [0.1443, 0.1832] | 0.1686 | 0.9212 |
| collapse_moderate_coupled | 8.0 | ewma_pb | 0.1869 | [0.1602, 0.2097] | 0.1955 | 0.9211 |
| collapse_moderate_coupled | 8.0 | rova_pb | 0.02867 | [0.02369, 0.03406] | 0.02761 | 0.9171 |
| collapse_moderate_coupled | 20.0 | static | 0.9339 | [0.8557, 1.02] | 0.8363 | 0.9865 |
| collapse_moderate_coupled | 20.0 | ewma | 1.205 | [1.131, 1.279] | 1.217 | 0.9867 |
| collapse_moderate_coupled | 20.0 | rova | 0.008477 | [0.006412, 0.01127] | 0.005026 | 0.9852 |
| collapse_moderate_coupled | 20.0 | A0 | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |
| collapse_moderate_coupled | 20.0 | A5 | 8.327 | [8.073, 8.578] | 8.229 | 0.9879 |
| collapse_moderate_coupled | 20.0 | learned | 0.004428 | [0.003395, 0.005865] | 0.003127 | 0.9852 |
| collapse_moderate_coupled | 20.0 | qlearn | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |
| collapse_moderate_coupled | 20.0 | static_ext | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |
| collapse_moderate_coupled | 20.0 | ewma_ext | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |
| collapse_moderate_coupled | 20.0 | clairvoyant | 1.018 | [0.9384, 1.105] | 0.9499 | 0.9869 |
| collapse_moderate_coupled | 20.0 | abl_full | 0.008477 | [0.006412, 0.01127] | 0.005026 | 0.9852 |
| collapse_moderate_coupled | 20.0 | abl_no_memory | 0.0646 | [0.03837, 0.1008] | 0.006872 | 0.9854 |
| collapse_moderate_coupled | 20.0 | abl_no_decay | 0.1185 | [0.08484, 0.1588] | 0.01982 | 0.9855 |
| collapse_moderate_coupled | 20.0 | abl_no_propagation | 0.1521 | [0.1069, 0.2013] | 0.01627 | 0.9856 |
| collapse_moderate_coupled | 20.0 | abl_no_stability | 0.1537 | [0.1084, 0.2028] | 0.01296 | 0.9857 |
| collapse_moderate_coupled | 20.0 | rova_single | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |
| collapse_moderate_coupled | 20.0 | static_tpe | 0.005514 | [0.004449, 0.006886] | 0.004364 | 0.9852 |
| collapse_moderate_coupled | 20.0 | ewma_tpe | 0.006628 | [0.00504, 0.008718] | 0.004597 | 0.9852 |
| collapse_moderate_coupled | 20.0 | rova_tpe | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |
| collapse_moderate_coupled | 20.0 | fx_decay-propagation | 0.1467 | [0.1089, 0.1907] | 0.06677 | 0.9855 |
| collapse_moderate_coupled | 20.0 | fx_decay-stability | 0.109 | [0.07511, 0.1511] | 0.01418 | 0.9855 |
| collapse_moderate_coupled | 20.0 | fx_propagation-stability | 0.1868 | [0.1459, 0.2274] | 0.2199 | 0.9855 |
| collapse_moderate_coupled | 20.0 | fx_memory-decay-propagation | 0.1858 | [0.1414, 0.2389] | 0.153 | 0.9858 |
| collapse_moderate_coupled | 20.0 | fx_memory-decay-stability | 0.05527 | [0.03945, 0.07797] | 0.01938 | 0.9852 |
| collapse_moderate_coupled | 20.0 | fx_decay-propagation-stability | 0.2198 | [0.1844, 0.2546] | 0.2241 | 0.9855 |
| collapse_moderate_coupled | 20.0 | fx_memory-decay-propagation-stability | 0.2283 | [0.1712, 0.2979] | 0.1174 | 0.9856 |
| collapse_moderate_coupled | 20.0 | ewma_out | 0.9686 | [0.8859, 1.058] | 0.8668 | 0.9865 |
| collapse_moderate_coupled | 20.0 | rova_out | 0.2858 | [0.2497, 0.3197] | 0.3057 | 0.9858 |
| collapse_moderate_coupled | 20.0 | static_pb | 0.6084 | [0.5387, 0.6691] | 0.6422 | 0.9864 |
| collapse_moderate_coupled | 20.0 | ewma_pb | 0.6404 | [0.5444, 0.7235] | 0.7229 | 0.9864 |
| collapse_moderate_coupled | 20.0 | rova_pb | 0.006542 | [0.004936, 0.008572] | 0.004542 | 0.9852 |

## Comparison families on the common evaluation worlds

Holm within family (plan §1 rule) and across the whole reported family (protocol §8, used by DR1–DR8).

| env | c | family | A | B | δ(A,B) | p | Holm (family) | Holm (protocol) | label | ROPE P(A lower / rope / B lower) |
|---|---|---|---|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 0.5 | F1 | rova | static | +0.967 | 1.63e-11 | reject | reject | static lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F1 | rova | ewma | +0.767 | 3.73e-10 | reject | reject | ewma lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F1 | static | ewma | -0.645 | 3.29e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F2 | rova | A0 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F2 | rova | A5 | -0.363 | 1.30e-07 | reject | reject | rova lower-regret | 0.998 / 0.00175 / 0 |
| favorable_hmm_coupled | 0.5 | F2 | static | A0 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F2 | static | A5 | -0.968 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F2 | ewma | A0 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F2 | ewma | A5 | -0.824 | 2.70e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F3 | rova | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F4 | rova | static_ext | +0.942 | 2.10e-11 | reject | reject | static_ext lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F4 | rova | ewma_ext | +0.270 | 4.29e-03 | reject | – | ewma_ext lower-regret | 0 / 0.0508 / 0.949 |
| favorable_hmm_coupled | 0.5 | F4 | static_ext | static | +0.439 | 7.25e-05 | reject | – | static lower-regret | 0 / 0.00125 / 0.999 |
| favorable_hmm_coupled | 0.5 | F4 | ewma_ext | ewma | +0.580 | 9.28e-11 | reject | reject | ewma lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F5 | rova | clairvoyant | +0.934 | 1.63e-11 | reject | reject | clairvoyant lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F5 | rova | rova_single | +0.999 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F6 | rova_tpe | static_tpe | +0.962 | 1.63e-11 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F6 | rova_tpe | ewma_tpe | +0.703 | 9.51e-10 | reject | reject | ewma_tpe lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F6 | static_tpe | ewma_tpe | -0.647 | 1.94e-07 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F7 | rova_tpe | rova | -0.769 | 1.63e-11 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F7 | static_tpe | static | -0.991 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F7 | ewma_tpe | ewma | -0.909 | 1.71e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F8 | abl_no_memory | abl_full | -0.865 | 2.32e-11 | reject | reject | abl_no_memory lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F8 | abl_no_decay | abl_full | +0.363 | 2.61e-04 | reject | – | abl_full lower-regret | 0 / 0.0115 / 0.989 |
| favorable_hmm_coupled | 0.5 | F8 | abl_no_propagation | abl_full | -0.173 | 1.71e-01 | – | – | no detected difference | 0.606 / 0.394 / 0.001 |
| favorable_hmm_coupled | 0.5 | F8 | abl_no_stability | abl_full | -0.363 | 2.99e-05 | reject | reject | abl_no_stability lower-regret | 0.997 / 0.003 / 0 |
| favorable_hmm_coupled | 0.5 | F10 | rova_out | static | +0.990 | 1.63e-11 | reject | reject | static lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F10 | rova_out | ewma_out | +0.939 | 1.63e-11 | reject | reject | ewma_out lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F10 | rova | rova_out | -0.486 | 4.25e-07 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F10 | ewma | ewma_out | +0.149 | 2.48e-01 | – | – | no detected difference | 0 / 0.506 / 0.494 |
| favorable_hmm_coupled | 0.5 | F11 | rova_pb | static_pb | +0.988 | 1.63e-11 | reject | reject | static_pb lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F11 | rova_pb | ewma_pb | +0.687 | 7.20e-10 | reject | reject | ewma_pb lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 0.5 | F11 | static_pb | ewma_pb | -0.914 | 1.63e-11 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 0.5 | F12 | rova_pb | rova | -0.348 | 5.07e-04 | reject | – | rova_pb lower-regret | 0.973 / 0.0275 / 0 |
| favorable_hmm_coupled | 0.5 | F12 | static_pb | static | -0.271 | 8.63e-02 | – | – | no detected difference | 0.811 / 0.189 / 0.0005 |
| favorable_hmm_coupled | 0.5 | F12 | ewma_pb | ewma | -0.140 | 1.29e-01 | – | – | no detected difference | 0.47 / 0.525 / 0.0045 |
| favorable_hmm_coupled | 0.5 | F13 | abl_full | rova | +0.004 | 8.14e-01 | – | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 1.5 | F1 | rova | static | +1.000 | 1.63e-11 | reject | reject | static lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F1 | rova | ewma | +0.411 | 5.19e-06 | reject | reject | ewma lower-regret | 0 / 0.0015 / 0.999 |
| favorable_hmm_coupled | 1.5 | F1 | static | ewma | -0.937 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F2 | rova | A0 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F2 | static | A0 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F2 | ewma | A0 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F3 | rova | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F3 | static | qlearn | +0.994 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F4 | rova | static_ext | +0.996 | 1.63e-11 | reject | reject | static_ext lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F4 | rova | ewma_ext | +0.362 | 1.31e-05 | reject | reject | ewma_ext lower-regret | 0 / 0.00475 / 0.995 |
| favorable_hmm_coupled | 1.5 | F4 | static_ext | static | -0.209 | 4.60e-01 | – | – | no detected difference | 0.761 / 0.239 / 0 |
| favorable_hmm_coupled | 1.5 | F4 | ewma_ext | ewma | +0.153 | 9.71e-01 | – | – | no detected difference | 0.0015 / 0.504 / 0.495 |
| favorable_hmm_coupled | 1.5 | F5 | rova | clairvoyant | +0.973 | 1.63e-11 | reject | reject | clairvoyant lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F5 | rova | rova_single | +1.000 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F6 | rova_tpe | static_tpe | +0.886 | 1.13e-10 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F6 | rova_tpe | ewma_tpe | +0.192 | 3.39e-03 | reject | – | ewma_tpe lower-regret | 0.00025 / 0.288 / 0.712 |
| favorable_hmm_coupled | 1.5 | F6 | static_tpe | ewma_tpe | -0.589 | 8.44e-07 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F7 | rova_tpe | rova | -0.967 | 1.63e-11 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F8 | abl_no_memory | abl_full | -0.996 | 1.63e-11 | reject | reject | abl_no_memory lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F8 | abl_no_decay | abl_full | -0.047 | 9.88e-01 | – | – | no detected difference | 0.141 / 0.842 / 0.0165 |
| favorable_hmm_coupled | 1.5 | F8 | abl_no_propagation | abl_full | -0.429 | 1.10e-04 | reject | – | abl_no_propagation lower-regret | 1 / 0.00025 / 0 |
| favorable_hmm_coupled | 1.5 | F8 | abl_no_stability | abl_full | -0.114 | 2.73e-01 | – | – | no detected difference | 0.416 / 0.56 / 0.024 |
| favorable_hmm_coupled | 1.5 | F10 | rova_out | static | +1.000 | 1.63e-11 | reject | reject | static lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F10 | rova_out | ewma_out | +0.515 | 7.39e-08 | reject | reject | ewma_out lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F10 | rova | rova_out | +0.329 | 4.92e-03 | reject | – | rova_out lower-regret | 0 / 0.0542 / 0.946 |
| favorable_hmm_coupled | 1.5 | F10 | ewma | ewma_out | -0.074 | 3.50e-01 | – | – | no detected difference | 0.243 / 0.735 / 0.0213 |
| favorable_hmm_coupled | 1.5 | F11 | rova_pb | static_pb | +0.958 | 6.27e-11 | reject | reject | static_pb lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 1.5 | F11 | rova_pb | ewma_pb | +0.144 | 3.77e-01 | – | – | no detected difference | 0.00675 / 0.514 / 0.479 |
| favorable_hmm_coupled | 1.5 | F11 | static_pb | ewma_pb | -0.999 | 1.63e-11 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F12 | rova_pb | rova | -0.677 | 5.97e-06 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 1.5 | F12 | static_pb | static | -0.418 | 1.17e-03 | reject | – | static_pb lower-regret | 0.988 / 0.012 / 0 |
| favorable_hmm_coupled | 1.5 | F12 | ewma_pb | ewma | -0.209 | 2.51e-04 | reject | – | ewma_pb lower-regret | 0.807 / 0.193 / 0 |
| favorable_hmm_coupled | 1.5 | F13 | abl_full | rova | -0.003 | 8.75e-01 | – | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 3.5 | F1 | rova | static | -0.202 | 3.59e-02 | reject | – | rova lower-regret | 0.684 / 0.314 / 0.00225 |
| favorable_hmm_coupled | 3.5 | F1 | rova | ewma | -0.702 | 1.14e-09 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F1 | static | ewma | -0.596 | 1.30e-10 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F2 | rova | A0 | -0.228 | 1.51e-06 | reject | reject | rova lower-regret | 0.986 / 0.0145 / 0 |
| favorable_hmm_coupled | 3.5 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F2 | static | A0 | +0.102 | 3.31e-01 | – | – | no detected difference | 0.0155 / 0.631 / 0.353 |
| favorable_hmm_coupled | 3.5 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F2 | ewma | A0 | +0.669 | 8.57e-09 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F3 | rova | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F4 | rova | static_ext | +0.164 | 6.01e-01 | – | – | no detected difference | 0 / 0.451 / 0.549 |
| favorable_hmm_coupled | 3.5 | F4 | rova | ewma_ext | -0.211 | 1.47e-03 | reject | – | rova lower-regret | 0.909 / 0.091 / 0 |
| favorable_hmm_coupled | 3.5 | F4 | static_ext | static | -0.292 | 8.27e-04 | reject | – | static_ext lower-regret | 0.954 / 0.046 / 0 |
| favorable_hmm_coupled | 3.5 | F4 | ewma_ext | ewma | -0.665 | 1.25e-09 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F5 | rova | clairvoyant | -0.361 | 9.00e-04 | reject | – | rova lower-regret | 0.963 / 0.0375 / 0 |
| favorable_hmm_coupled | 3.5 | F5 | rova | rova_single | +1.000 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F6 | rova_tpe | static_tpe | +0.994 | 1.63e-11 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 3.5 | F6 | rova_tpe | ewma_tpe | -0.021 | 8.23e-02 | – | – | no detected difference | 0.142 / 0.788 / 0.0693 |
| favorable_hmm_coupled | 3.5 | F6 | static_tpe | ewma_tpe | -0.961 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F7 | rova_tpe | rova | -0.718 | 1.63e-11 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F7 | ewma_tpe | ewma | -0.861 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F8 | abl_no_memory | abl_full | -0.629 | 1.63e-11 | reject | reject | abl_no_memory lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F8 | abl_no_decay | abl_full | -0.247 | 1.40e-03 | reject | – | abl_no_decay lower-regret | 0.962 / 0.038 / 0 |
| favorable_hmm_coupled | 3.5 | F8 | abl_no_propagation | abl_full | +0.129 | 1.85e-02 | reject | – | no detected difference | 0 / 0.568 / 0.432 |
| favorable_hmm_coupled | 3.5 | F8 | abl_no_stability | abl_full | -0.212 | 2.29e-02 | reject | – | abl_no_stability lower-regret | 0.835 / 0.165 / 0 |
| favorable_hmm_coupled | 3.5 | F10 | rova_out | static | -0.187 | 1.59e-03 | reject | – | rova_out lower-regret | 0.692 / 0.307 / 0.0005 |
| favorable_hmm_coupled | 3.5 | F10 | rova_out | ewma_out | -0.524 | 8.57e-09 | reject | reject | rova_out lower-regret | 1 / 0.0005 / 0 |
| favorable_hmm_coupled | 3.5 | F10 | rova | rova_out | -0.048 | 7.74e-01 | – | – | no detected difference | 0.118 / 0.875 / 0.0065 |
| favorable_hmm_coupled | 3.5 | F10 | ewma | ewma_out | +0.197 | 1.96e-02 | reject | – | ewma_out lower-regret | 0.00025 / 0.306 / 0.694 |
| favorable_hmm_coupled | 3.5 | F11 | rova_pb | static_pb | +0.246 | 3.46e-02 | reject | – | static_pb lower-regret | 0.001 / 0.177 / 0.822 |
| favorable_hmm_coupled | 3.5 | F11 | rova_pb | ewma_pb | -0.213 | 7.37e-03 | reject | – | rova_pb lower-regret | 0.729 / 0.271 / 0.00025 |
| favorable_hmm_coupled | 3.5 | F11 | static_pb | ewma_pb | -0.433 | 1.14e-09 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F12 | rova_pb | rova | -0.253 | 2.66e-07 | reject | reject | rova_pb lower-regret | 0.983 / 0.0175 / 0 |
| favorable_hmm_coupled | 3.5 | F12 | static_pb | static | -0.447 | 1.15e-03 | reject | – | static_pb lower-regret | 0.999 / 0.001 / 0 |
| favorable_hmm_coupled | 3.5 | F12 | ewma_pb | ewma | -0.684 | 1.63e-09 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 3.5 | F13 | abl_full | rova | +0.010 | 4.80e-01 | – | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 8.0 | F1 | rova | static | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F1 | rova | ewma | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F1 | static | ewma | -0.196 | 5.56e-02 | – | – | no detected difference | 0.706 / 0.294 / 0 |
| favorable_hmm_coupled | 8.0 | F2 | rova | A0 | -0.016 | 2.87e-03 | reject | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 8.0 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F2 | static | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F2 | ewma | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F3 | rova | learned | +0.836 | 1.99e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F3 | rova | qlearn | +0.496 | 1.66e-10 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F4 | rova | static_ext | -0.016 | 2.87e-03 | reject | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 8.0 | F4 | rova | ewma_ext | -0.016 | 2.87e-03 | reject | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 8.0 | F4 | static_ext | static | -1.000 | 1.63e-11 | reject | reject | static_ext lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F4 | ewma_ext | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F5 | rova | clairvoyant | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F5 | rova | rova_single | +0.163 | 9.98e-03 | reject | – | rova_single lower-regret | 0 / 0.399 / 0.601 |
| favorable_hmm_coupled | 8.0 | F6 | rova_tpe | static_tpe | +0.586 | 4.44e-11 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F6 | rova_tpe | ewma_tpe | +0.141 | 6.72e-02 | – | – | no detected difference | 0 / 0.576 / 0.424 |
| favorable_hmm_coupled | 8.0 | F6 | static_tpe | ewma_tpe | -0.460 | 3.24e-09 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F7 | rova_tpe | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 8.0 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F8 | abl_no_memory | abl_full | +0.181 | 1.88e-02 | reject | – | abl_full lower-regret | 0 / 0.303 / 0.697 |
| favorable_hmm_coupled | 8.0 | F8 | abl_no_decay | abl_full | +0.277 | 1.12e-04 | reject | – | abl_full lower-regret | 0 / 0.00475 / 0.995 |
| favorable_hmm_coupled | 8.0 | F8 | abl_no_propagation | abl_full | +0.350 | 1.83e-07 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F8 | abl_no_stability | abl_full | +0.386 | 4.84e-06 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 8.0 | F10 | rova_out | static | -0.699 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F10 | rova_out | ewma_out | -0.758 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F10 | rova | rova_out | -0.779 | 2.21e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F10 | ewma | ewma_out | +0.134 | 7.25e-02 | – | – | no detected difference | 0.0005 / 0.557 / 0.442 |
| favorable_hmm_coupled | 8.0 | F11 | rova_pb | static_pb | -0.947 | 1.80e-11 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F11 | rova_pb | ewma_pb | -0.797 | 1.63e-09 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F11 | static_pb | ewma_pb | +0.066 | 9.94e-01 | – | – | no detected difference | 0.00025 / 0.888 / 0.112 |
| favorable_hmm_coupled | 8.0 | F12 | rova_pb | rova | +0.015 | 5.21e-03 | reject | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 8.0 | F12 | static_pb | static | -0.572 | 4.46e-04 | reject | – | static_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F12 | ewma_pb | ewma | -0.757 | 1.63e-09 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 8.0 | F13 | abl_full | rova | -0.001 | 1.80e-01 | – | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 20.0 | F1 | rova | static | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F1 | rova | ewma | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F1 | static | ewma | +0.008 | 7.35e-01 | – | – | no detected difference | 0.0305 / 0.911 / 0.058 |
| favorable_hmm_coupled | 20.0 | F2 | rova | A0 | +0.052 | 1.47e-03 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| favorable_hmm_coupled | 20.0 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F2 | static | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F2 | ewma | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F3 | rova | learned | +0.239 | 3.86e-09 | reject | reject | learned lower-regret | 0 / 0.0168 / 0.983 |
| favorable_hmm_coupled | 20.0 | F3 | rova | qlearn | -0.141 | 5.44e-02 | – | – | no detected difference | 0.426 / 0.574 / 0 |
| favorable_hmm_coupled | 20.0 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F4 | rova | static_ext | +0.052 | 1.47e-03 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| favorable_hmm_coupled | 20.0 | F4 | rova | ewma_ext | +0.052 | 1.47e-03 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| favorable_hmm_coupled | 20.0 | F4 | static_ext | static | -1.000 | 1.63e-11 | reject | reject | static_ext lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F4 | ewma_ext | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F5 | rova | clairvoyant | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F5 | rova | rova_single | +0.052 | 1.47e-03 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| favorable_hmm_coupled | 20.0 | F6 | rova_tpe | static_tpe | -0.001 | 5.42e-02 | – | – | no detected difference | 0 / 1 / 0 |
| favorable_hmm_coupled | 20.0 | F6 | rova_tpe | ewma_tpe | -0.154 | 3.34e-04 | reject | – | rova_tpe lower-regret | 0.527 / 0.473 / 0 |
| favorable_hmm_coupled | 20.0 | F6 | static_tpe | ewma_tpe | -0.158 | 1.60e-05 | reject | reject | static_tpe lower-regret | 0.607 / 0.393 / 0 |
| favorable_hmm_coupled | 20.0 | F7 | rova_tpe | rova | -0.052 | 1.47e-03 | reject | – | no detected difference | 0.0005 / 1 / 0 |
| favorable_hmm_coupled | 20.0 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F8 | abl_no_memory | abl_full | +0.224 | 2.26e-05 | reject | reject | abl_full lower-regret | 0 / 0.06 / 0.94 |
| favorable_hmm_coupled | 20.0 | F8 | abl_no_decay | abl_full | +0.507 | 2.73e-08 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F8 | abl_no_propagation | abl_full | +0.325 | 1.10e-04 | reject | – | abl_full lower-regret | 0 / 0.0107 / 0.989 |
| favorable_hmm_coupled | 20.0 | F8 | abl_no_stability | abl_full | +0.412 | 5.86e-06 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| favorable_hmm_coupled | 20.0 | F10 | rova_out | static | -0.801 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F10 | rova_out | ewma_out | -0.799 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F10 | rova | rova_out | -0.999 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F10 | ewma | ewma_out | +0.012 | 9.82e-01 | – | – | no detected difference | 0.04 / 0.903 / 0.0565 |
| favorable_hmm_coupled | 20.0 | F11 | rova_pb | static_pb | -1.000 | 1.63e-11 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F11 | rova_pb | ewma_pb | -0.808 | 1.63e-09 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F11 | static_pb | ewma_pb | +0.251 | 1.89e-05 | reject | reject | ewma_pb lower-regret | 0 / 0.0307 / 0.969 |
| favorable_hmm_coupled | 20.0 | F12 | rova_pb | rova | -0.052 | 1.47e-03 | reject | – | no detected difference | 0.0005 / 1 / 0 |
| favorable_hmm_coupled | 20.0 | F12 | static_pb | static | -0.568 | 1.74e-04 | reject | – | static_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F12 | ewma_pb | ewma | -0.706 | 7.26e-09 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| favorable_hmm_coupled | 20.0 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F1 | rova | static | -0.126 | 2.30e-01 | – | – | no detected difference | 0.348 / 0.652 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F1 | rova | ewma | +0.211 | 2.22e-03 | reject | – | ewma lower-regret | 0 / 0.136 / 0.864 |
| unfavorable_oscillation_uncoupled | 0.5 | F1 | static | ewma | +0.420 | 1.24e-04 | reject | – | ewma lower-regret | 0 / 0.0005 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F2 | rova | A0 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F2 | rova | A5 | +0.211 | 2.22e-03 | reject | – | A5 lower-regret | 0 / 0.136 / 0.864 |
| unfavorable_oscillation_uncoupled | 0.5 | F2 | static | A0 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F2 | static | A5 | +0.420 | 1.24e-04 | reject | – | A5 lower-regret | 0 / 0.0005 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F2 | ewma | A0 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F2 | ewma | A5 | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F3 | rova | learned | +0.525 | 1.56e-09 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F3 | rova | qlearn | +0.301 | 1.40e-07 | reject | reject | qlearn lower-regret | 0 / 0.00875 / 0.991 |
| unfavorable_oscillation_uncoupled | 0.5 | F3 | static | learned | +0.697 | 7.97e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F3 | static | qlearn | +0.501 | 2.42e-07 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F3 | ewma | learned | +0.400 | 1.65e-08 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F3 | ewma | qlearn | +0.118 | 8.27e-06 | reject | reject | no detected difference | 0 / 0.729 / 0.271 |
| unfavorable_oscillation_uncoupled | 0.5 | F4 | rova | static_ext | -0.084 | 9.93e-01 | – | – | no detected difference | 0.293 / 0.681 / 0.0253 |
| unfavorable_oscillation_uncoupled | 0.5 | F4 | rova | ewma_ext | +0.211 | 2.22e-03 | reject | – | ewma_ext lower-regret | 0 / 0.136 / 0.864 |
| unfavorable_oscillation_uncoupled | 0.5 | F4 | static_ext | static | -0.018 | 9.24e-01 | – | – | no detected difference | 0.0757 / 0.896 / 0.028 |
| unfavorable_oscillation_uncoupled | 0.5 | F4 | ewma_ext | ewma | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F5 | rova | clairvoyant | -0.529 | 8.65e-03 | reject | – | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F5 | rova | rova_single | +0.286 | 3.22e-06 | reject | reject | rova_single lower-regret | 0 / 0.00425 / 0.996 |
| unfavorable_oscillation_uncoupled | 0.5 | F6 | rova_tpe | static_tpe | +0.125 | 5.89e-07 | reject | reject | no detected difference | 0 / 0.628 / 0.371 |
| unfavorable_oscillation_uncoupled | 0.5 | F6 | rova_tpe | ewma_tpe | +0.021 | 5.06e-02 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F6 | static_tpe | ewma_tpe | -0.104 | 8.27e-06 | reject | reject | no detected difference | 0.188 / 0.812 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F7 | rova_tpe | rova | -0.210 | 1.87e-03 | reject | – | rova_tpe lower-regret | 0.86 / 0.14 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F7 | static_tpe | static | -0.514 | 5.11e-09 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F7 | ewma_tpe | ewma | -0.020 | 5.06e-02 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F8 | abl_no_memory | abl_full | +0.183 | 9.40e-01 | – | – | no detected difference | 0.00025 / 0.353 / 0.647 |
| unfavorable_oscillation_uncoupled | 0.5 | F8 | abl_no_decay | abl_full | -0.012 | 5.20e-02 | – | – | no detected difference | 0.0457 / 0.923 / 0.0307 |
| unfavorable_oscillation_uncoupled | 0.5 | F8 | abl_no_propagation | abl_full | -0.180 | 3.60e-03 | reject | – | abl_no_propagation lower-regret | 0.681 / 0.319 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F8 | abl_no_stability | abl_full | -0.177 | 1.51e-02 | reject | – | abl_no_stability lower-regret | 0.664 / 0.336 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F10 | rova_out | static | +0.231 | 3.63e-09 | reject | reject | static lower-regret | 0 / 0.0255 / 0.975 |
| unfavorable_oscillation_uncoupled | 0.5 | F10 | rova_out | ewma_out | +0.456 | 7.18e-08 | reject | reject | ewma_out lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 0.5 | F10 | rova | rova_out | -0.266 | 2.97e-04 | reject | – | rova lower-regret | 0.984 / 0.0158 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F10 | ewma | ewma_out | -0.079 | 2.90e-03 | reject | – | no detected difference | 0.0338 / 0.966 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F11 | rova_pb | static_pb | -0.035 | 4.04e-01 | – | – | no detected difference | 0.0192 / 0.981 / 0.00025 |
| unfavorable_oscillation_uncoupled | 0.5 | F11 | rova_pb | ewma_pb | +0.005 | 3.17e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F11 | static_pb | ewma_pb | +0.039 | 4.54e-01 | – | – | no detected difference | 0.00025 / 0.979 / 0.0208 |
| unfavorable_oscillation_uncoupled | 0.5 | F12 | rova_pb | rova | -0.205 | 3.73e-03 | reject | – | rova_pb lower-regret | 0.829 / 0.171 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F12 | static_pb | static | -0.397 | 7.46e-09 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F12 | ewma_pb | ewma | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 0.5 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F1 | rova | static | +0.956 | 1.63e-11 | reject | reject | static lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F1 | rova | ewma | +0.472 | 3.64e-07 | reject | reject | ewma lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F1 | static | ewma | -0.885 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F2 | rova | A0 | -0.972 | 1.71e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F2 | rova | A5 | -0.549 | 1.07e-08 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F2 | static | A0 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F2 | static | A5 | -0.998 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F2 | ewma | A0 | -0.999 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F2 | ewma | A5 | -0.752 | 2.70e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F3 | rova | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F3 | static | qlearn | +0.944 | 6.27e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F4 | rova | static_ext | +0.973 | 1.63e-11 | reject | reject | static_ext lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F4 | rova | ewma_ext | +0.623 | 1.16e-08 | reject | reject | ewma_ext lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F4 | static_ext | static | -0.171 | 3.14e-03 | reject | – | static_ext lower-regret | 0.685 / 0.315 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F4 | ewma_ext | ewma | -0.229 | 1.31e-02 | reject | – | ewma_ext lower-regret | 0.857 / 0.143 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F5 | rova | clairvoyant | +0.994 | 1.63e-11 | reject | reject | clairvoyant lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F5 | rova | rova_single | +0.994 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F6 | rova_tpe | static_tpe | +1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F6 | rova_tpe | ewma_tpe | -0.106 | 2.08e-01 | – | – | no detected difference | 0.408 / 0.566 / 0.0262 |
| unfavorable_oscillation_uncoupled | 1.5 | F6 | static_tpe | ewma_tpe | -0.945 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F7 | rova_tpe | rova | -0.758 | 1.16e-08 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F7 | ewma_tpe | ewma | -0.457 | 8.72e-05 | reject | – | ewma_tpe lower-regret | 0.998 / 0.002 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F8 | abl_no_memory | abl_full | -0.971 | 4.02e-11 | reject | reject | abl_no_memory lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F8 | abl_no_decay | abl_full | -0.089 | 6.48e-01 | – | – | no detected difference | 0.279 / 0.705 / 0.0158 |
| unfavorable_oscillation_uncoupled | 1.5 | F8 | abl_no_propagation | abl_full | -0.229 | 1.49e-01 | – | – | no detected difference | 0.767 / 0.232 / 0.001 |
| unfavorable_oscillation_uncoupled | 1.5 | F8 | abl_no_stability | abl_full | +0.304 | 2.42e-03 | reject | – | abl_full lower-regret | 0 / 0.0755 / 0.924 |
| unfavorable_oscillation_uncoupled | 1.5 | F10 | rova_out | static | +0.997 | 1.63e-11 | reject | reject | static lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F10 | rova_out | ewma_out | +0.102 | 3.31e-01 | – | – | no detected difference | 0 / 0.766 / 0.234 |
| unfavorable_oscillation_uncoupled | 1.5 | F10 | rova | rova_out | -0.263 | 2.54e-03 | reject | – | rova lower-regret | 0.898 / 0.102 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F10 | ewma | ewma_out | -0.572 | 6.27e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F11 | rova_pb | static_pb | +1.000 | 1.63e-11 | reject | reject | static_pb lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 1.5 | F11 | rova_pb | ewma_pb | +0.324 | 2.84e-04 | reject | – | ewma_pb lower-regret | 0 / 0.0288 / 0.971 |
| unfavorable_oscillation_uncoupled | 1.5 | F11 | static_pb | ewma_pb | -0.977 | 1.63e-11 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F12 | rova_pb | rova | -0.378 | 9.49e-04 | reject | – | rova_pb lower-regret | 0.982 / 0.0182 / 0 |
| unfavorable_oscillation_uncoupled | 1.5 | F12 | static_pb | static | -0.186 | 3.72e-02 | – | – | no detected difference | 0.649 / 0.348 / 0.0025 |
| unfavorable_oscillation_uncoupled | 1.5 | F12 | ewma_pb | ewma | -0.124 | 1.14e-01 | – | – | no detected difference | 0.394 / 0.606 / 0.0005 |
| unfavorable_oscillation_uncoupled | 1.5 | F13 | abl_full | rova | +0.001 | 1.17e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F1 | rova | static | -0.509 | 1.63e-03 | reject | – | rova lower-regret | 1 / 0.00025 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F1 | rova | ewma | -0.719 | 1.37e-09 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F1 | static | ewma | -0.421 | 1.44e-09 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F2 | rova | A0 | +0.086 | 1.11e-07 | reject | reject | no detected difference | 0 / 0.971 / 0.029 |
| unfavorable_oscillation_uncoupled | 3.5 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F2 | static | A0 | +0.549 | 3.99e-04 | reject | – | A0 lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F2 | ewma | A0 | +0.764 | 3.56e-10 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F3 | rova | learned | +0.667 | 2.68e-10 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F3 | rova | qlearn | +0.268 | 3.24e-07 | reject | reject | qlearn lower-regret | 0 / 0.0575 / 0.943 |
| unfavorable_oscillation_uncoupled | 3.5 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F3 | static | qlearn | +0.925 | 1.99e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F3 | ewma | qlearn | +0.964 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 3.5 | F4 | rova | static_ext | +0.021 | 2.10e-04 | reject | – | no detected difference | 0.00075 / 0.998 / 0.00175 |
| unfavorable_oscillation_uncoupled | 3.5 | F4 | rova | ewma_ext | +0.086 | 1.11e-07 | reject | reject | no detected difference | 0 / 0.971 / 0.029 |
| unfavorable_oscillation_uncoupled | 3.5 | F4 | static_ext | static | -0.539 | 9.00e-04 | reject | – | static_ext lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F4 | ewma_ext | ewma | -0.764 | 3.56e-10 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F5 | rova | clairvoyant | -0.500 | 1.99e-03 | reject | – | rova lower-regret | 0.999 / 0.00125 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F5 | rova | rova_single | +0.247 | 1.35e-07 | reject | reject | rova_single lower-regret | 0 / 0.0112 / 0.989 |
| unfavorable_oscillation_uncoupled | 3.5 | F6 | rova_tpe | static_tpe | +0.225 | 6.61e-05 | reject | – | static_tpe lower-regret | 0.00025 / 0.242 / 0.758 |
| unfavorable_oscillation_uncoupled | 3.5 | F6 | rova_tpe | ewma_tpe | +0.171 | 8.20e-05 | reject | – | ewma_tpe lower-regret | 0 / 0.387 / 0.614 |
| unfavorable_oscillation_uncoupled | 3.5 | F6 | static_tpe | ewma_tpe | -0.044 | 1.60e-01 | – | – | no detected difference | 0.107 / 0.885 / 0.00725 |
| unfavorable_oscillation_uncoupled | 3.5 | F7 | rova_tpe | rova | -0.086 | 3.78e-08 | reject | reject | no detected difference | 0.0293 / 0.971 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F7 | static_tpe | static | -0.981 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F7 | ewma_tpe | ewma | -0.916 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F8 | abl_no_memory | abl_full | +0.078 | 1.19e-01 | – | – | no detected difference | 0.00125 / 0.818 / 0.181 |
| unfavorable_oscillation_uncoupled | 3.5 | F8 | abl_no_decay | abl_full | +0.039 | 1.04e-02 | reject | – | no detected difference | 0 / 0.999 / 0.00125 |
| unfavorable_oscillation_uncoupled | 3.5 | F8 | abl_no_propagation | abl_full | +0.007 | 4.50e-03 | reject | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F8 | abl_no_stability | abl_full | +0.042 | 8.06e-01 | – | – | no detected difference | 0.00025 / 0.982 / 0.018 |
| unfavorable_oscillation_uncoupled | 3.5 | F10 | rova_out | static | -0.314 | 1.59e-03 | reject | – | rova_out lower-regret | 0.979 / 0.0208 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F10 | rova_out | ewma_out | -0.555 | 6.87e-10 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F10 | rova | rova_out | -0.254 | 3.73e-03 | reject | – | rova lower-regret | 0.967 / 0.0328 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F10 | ewma | ewma_out | +0.218 | 3.52e-05 | reject | reject | ewma_out lower-regret | 0 / 0.0943 / 0.906 |
| unfavorable_oscillation_uncoupled | 3.5 | F11 | rova_pb | static_pb | -0.159 | 5.81e-01 | – | – | no detected difference | 0.565 / 0.435 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F11 | rova_pb | ewma_pb | -0.240 | 7.40e-04 | reject | – | rova_pb lower-regret | 0.968 / 0.0323 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F11 | static_pb | ewma_pb | -0.126 | 9.74e-04 | reject | – | no detected difference | 0.435 / 0.564 / 0.0005 |
| unfavorable_oscillation_uncoupled | 3.5 | F12 | rova_pb | rova | -0.021 | 6.95e-03 | reject | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F12 | static_pb | static | -0.537 | 3.57e-05 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F12 | ewma_pb | ewma | -0.713 | 8.72e-09 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 3.5 | F13 | abl_full | rova | -0.023 | 3.95e-03 | reject | – | no detected difference | 0.0005 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F1 | rova | static | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F1 | rova | ewma | -0.999 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F1 | static | ewma | -0.137 | 2.03e-01 | – | – | no detected difference | 0.404 / 0.596 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F2 | rova | A0 | +0.031 | 1.17e-02 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| unfavorable_oscillation_uncoupled | 8.0 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F2 | static | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 8.0 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F2 | ewma | A0 | +0.999 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 8.0 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F3 | rova | learned | +0.087 | 5.31e-05 | reject | – | no detected difference | 0 / 0.959 / 0.0413 |
| unfavorable_oscillation_uncoupled | 8.0 | F3 | rova | qlearn | +0.013 | 8.07e-01 | – | – | no detected difference | 0.00025 / 1 / 0.00025 |
| unfavorable_oscillation_uncoupled | 8.0 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 8.0 | F3 | static | qlearn | +0.999 | 1.71e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 8.0 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 8.0 | F3 | ewma | qlearn | +0.999 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 8.0 | F4 | rova | static_ext | +0.031 | 1.17e-02 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| unfavorable_oscillation_uncoupled | 8.0 | F4 | rova | ewma_ext | +0.031 | 1.17e-02 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| unfavorable_oscillation_uncoupled | 8.0 | F4 | static_ext | static | -1.000 | 1.63e-11 | reject | reject | static_ext lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F4 | ewma_ext | ewma | -0.999 | 1.63e-11 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F5 | rova | clairvoyant | -0.997 | 1.71e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F5 | rova | rova_single | +0.031 | 1.17e-02 | reject | – | no detected difference | 0 / 1 / 0.0005 |
| unfavorable_oscillation_uncoupled | 8.0 | F6 | rova_tpe | static_tpe | -0.254 | 4.89e-01 | – | – | no detected difference | 0.941 / 0.0587 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F6 | rova_tpe | ewma_tpe | +0.004 | 7.47e-02 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F6 | static_tpe | ewma_tpe | +0.262 | 4.77e-01 | – | – | no detected difference | 0 / 0.0525 / 0.948 |
| unfavorable_oscillation_uncoupled | 8.0 | F7 | rova_tpe | rova | -0.027 | 1.17e-02 | reject | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F7 | ewma_tpe | ewma | -0.999 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F8 | abl_no_memory | abl_full | +0.165 | 1.00e-02 | reject | – | abl_full lower-regret | 0 / 0.408 / 0.592 |
| unfavorable_oscillation_uncoupled | 8.0 | F8 | abl_no_decay | abl_full | -0.031 | 1.17e-02 | reject | – | no detected difference | 0.0005 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F8 | abl_no_propagation | abl_full | +0.268 | 1.02e-04 | reject | – | abl_full lower-regret | 0 / 0.0192 / 0.981 |
| unfavorable_oscillation_uncoupled | 8.0 | F8 | abl_no_stability | abl_full | +0.200 | 6.91e-04 | reject | – | abl_full lower-regret | 0 / 0.148 / 0.852 |
| unfavorable_oscillation_uncoupled | 8.0 | F10 | rova_out | static | -0.646 | 3.46e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F10 | rova_out | ewma_out | -0.709 | 2.32e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F10 | rova | rova_out | -0.591 | 7.62e-09 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F10 | ewma | ewma_out | +0.112 | 3.21e-02 | reject | – | no detected difference | 0 / 0.78 / 0.22 |
| unfavorable_oscillation_uncoupled | 8.0 | F11 | rova_pb | static_pb | -0.930 | 4.90e-11 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F11 | rova_pb | ewma_pb | -0.504 | 1.14e-07 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F11 | static_pb | ewma_pb | +0.244 | 3.17e-01 | – | – | no detected difference | 0 / 0.132 / 0.868 |
| unfavorable_oscillation_uncoupled | 8.0 | F12 | rova_pb | rova | -0.031 | 1.17e-02 | reject | – | no detected difference | 0.0005 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F12 | static_pb | static | -0.514 | 7.71e-05 | reject | – | static_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F12 | ewma_pb | ewma | -0.637 | 1.68e-07 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 8.0 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F1 | rova | static | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F1 | rova | ewma | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F1 | static | ewma | +0.044 | 1.20e-01 | – | – | no detected difference | 0.0015 / 0.957 / 0.042 |
| unfavorable_oscillation_uncoupled | 20.0 | F2 | rova | A0 | +0.002 | 2.85e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F2 | static | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F2 | ewma | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F3 | rova | learned | +0.001 | 5.00e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F3 | rova | qlearn | -0.039 | 5.00e-01 | – | – | no detected difference | 0.00375 / 0.996 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F4 | rova | static_ext | +0.002 | 2.85e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F4 | rova | ewma_ext | +0.002 | 2.85e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F4 | static_ext | static | -1.000 | 1.63e-11 | reject | reject | static_ext lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F4 | ewma_ext | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F5 | rova | clairvoyant | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F5 | rova | rova_single | +0.002 | 2.85e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F6 | rova_tpe | static_tpe | -0.014 | 2.12e-01 | – | – | no detected difference | 0.00025 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F6 | rova_tpe | ewma_tpe | -0.000 | 3.17e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F6 | static_tpe | ewma_tpe | +0.014 | 2.12e-01 | – | – | no detected difference | 0 / 1 / 0.00025 |
| unfavorable_oscillation_uncoupled | 20.0 | F7 | rova_tpe | rova | -0.002 | 2.85e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F8 | abl_no_memory | abl_full | +0.214 | 3.27e-04 | reject | – | abl_full lower-regret | 0 / 0.117 / 0.883 |
| unfavorable_oscillation_uncoupled | 20.0 | F8 | abl_no_decay | abl_full | -0.004 | 7.96e-02 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F8 | abl_no_propagation | abl_full | +0.383 | 9.84e-06 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| unfavorable_oscillation_uncoupled | 20.0 | F8 | abl_no_stability | abl_full | +0.165 | 1.79e-03 | reject | – | abl_full lower-regret | 0 / 0.401 / 0.599 |
| unfavorable_oscillation_uncoupled | 20.0 | F10 | rova_out | static | -0.682 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F10 | rova_out | ewma_out | -0.648 | 1.51e-10 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F10 | rova | rova_out | -0.714 | 5.18e-09 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F10 | ewma | ewma_out | +0.072 | 1.51e-01 | – | – | no detected difference | 0.00025 / 0.918 / 0.0818 |
| unfavorable_oscillation_uncoupled | 20.0 | F11 | rova_pb | static_pb | -0.999 | 1.63e-11 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F11 | rova_pb | ewma_pb | -0.538 | 1.14e-07 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F11 | static_pb | ewma_pb | +0.318 | 7.08e-04 | reject | – | ewma_pb lower-regret | 0 / 0.00875 / 0.991 |
| unfavorable_oscillation_uncoupled | 20.0 | F12 | rova_pb | rova | -0.002 | 2.85e-01 | – | – | no detected difference | 0 / 1 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F12 | static_pb | static | -0.545 | 2.07e-04 | reject | – | static_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F12 | ewma_pb | ewma | -0.611 | 1.68e-07 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| unfavorable_oscillation_uncoupled | 20.0 | F13 | abl_full | rova | +0.002 | 1.80e-01 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 0.5 | F1 | rova | static | +0.383 | 2.19e-07 | reject | reject | static lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F1 | rova | ewma | +0.090 | 1.07e-01 | – | – | no detected difference | 0.00225 / 0.744 / 0.254 |
| collapse_moderate_coupled | 0.5 | F1 | static | ewma | -0.424 | 5.65e-05 | reject | – | static lower-regret | 0.999 / 0.00075 / 0 |
| collapse_moderate_coupled | 0.5 | F2 | rova | A0 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F2 | rova | A5 | -0.976 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F2 | static | A0 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F2 | static | A5 | -0.998 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F2 | ewma | A0 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F2 | ewma | A5 | -0.988 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F3 | rova | qlearn | +0.798 | 1.25e-07 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F3 | static | learned | +0.999 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F3 | static | qlearn | +0.617 | 2.46e-05 | reject | reject | qlearn lower-regret | 0 / 0.00025 / 1 |
| collapse_moderate_coupled | 0.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F3 | ewma | qlearn | +0.784 | 9.77e-09 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F4 | rova | static_ext | +0.304 | 4.06e-06 | reject | reject | static_ext lower-regret | 0 / 0.0152 / 0.985 |
| collapse_moderate_coupled | 0.5 | F4 | rova | ewma_ext | -0.277 | 3.10e-02 | – | – | no detected difference | 0.88 / 0.119 / 0.00025 |
| collapse_moderate_coupled | 0.5 | F4 | static_ext | static | +0.083 | 3.06e-01 | – | – | no detected difference | 0.0095 / 0.729 / 0.261 |
| collapse_moderate_coupled | 0.5 | F4 | ewma_ext | ewma | +0.536 | 2.31e-05 | reject | reject | ewma lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F5 | rova | clairvoyant | +0.796 | 2.98e-11 | reject | reject | clairvoyant lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F5 | rova | rova_single | +0.942 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F6 | rova_tpe | static_tpe | +0.659 | 5.19e-10 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F6 | rova_tpe | ewma_tpe | +0.229 | 1.67e-03 | reject | – | ewma_tpe lower-regret | 0 / 0.123 / 0.877 |
| collapse_moderate_coupled | 0.5 | F6 | static_tpe | ewma_tpe | -0.389 | 1.50e-09 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F7 | rova_tpe | rova | -0.939 | 3.46e-11 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F7 | static_tpe | static | -0.945 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F7 | ewma_tpe | ewma | -0.942 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F8 | abl_no_memory | abl_full | -0.220 | 3.08e-03 | reject | – | abl_no_memory lower-regret | 0.732 / 0.268 / 0.00025 |
| collapse_moderate_coupled | 0.5 | F8 | abl_no_decay | abl_full | +0.303 | 2.26e-04 | reject | – | abl_full lower-regret | 0 / 0.02 / 0.98 |
| collapse_moderate_coupled | 0.5 | F8 | abl_no_propagation | abl_full | -0.533 | 7.68e-04 | reject | – | abl_no_propagation lower-regret | 0.999 / 0.00125 / 0 |
| collapse_moderate_coupled | 0.5 | F8 | abl_no_stability | abl_full | -0.621 | 8.96e-09 | reject | reject | abl_no_stability lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F10 | rova_out | static | +0.707 | 2.59e-09 | reject | reject | static lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F10 | rova_out | ewma_out | +0.770 | 5.70e-10 | reject | reject | ewma_out lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F10 | rova | rova_out | -0.291 | 3.81e-03 | reject | – | rova lower-regret | 0.929 / 0.0712 / 0 |
| collapse_moderate_coupled | 0.5 | F10 | ewma | ewma_out | +0.518 | 1.02e-06 | reject | reject | ewma_out lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 0.5 | F11 | rova_pb | static_pb | -0.011 | 6.91e-01 | – | – | no detected difference | 0.029 / 0.959 / 0.0123 |
| collapse_moderate_coupled | 0.5 | F11 | rova_pb | ewma_pb | -0.356 | 5.01e-06 | reject | reject | rova_pb lower-regret | 0.99 / 0.01 / 0 |
| collapse_moderate_coupled | 0.5 | F11 | static_pb | ewma_pb | -0.284 | 3.64e-07 | reject | reject | static_pb lower-regret | 0.994 / 0.006 / 0 |
| collapse_moderate_coupled | 0.5 | F12 | rova_pb | rova | -0.594 | 4.77e-07 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 0.5 | F12 | static_pb | static | -0.213 | 5.95e-02 | – | – | no detected difference | 0.727 / 0.273 / 0.00075 |
| collapse_moderate_coupled | 0.5 | F12 | ewma_pb | ewma | -0.187 | 1.51e-02 | reject | – | ewma_pb lower-regret | 0.674 / 0.326 / 0.00025 |
| collapse_moderate_coupled | 0.5 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 1.5 | F1 | rova | static | +0.664 | 5.06e-09 | reject | reject | static lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F1 | rova | ewma | -0.149 | 2.11e-01 | – | – | no detected difference | 0.507 / 0.492 / 0.00075 |
| collapse_moderate_coupled | 1.5 | F1 | static | ewma | -0.639 | 3.39e-09 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F2 | rova | A0 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F2 | static | A0 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F2 | ewma | A0 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F3 | rova | qlearn | +0.691 | 1.07e-07 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F3 | static | learned | +0.999 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F3 | static | qlearn | +0.356 | 1.53e-01 | – | – | no detected difference | 0 / 0.0343 / 0.966 |
| collapse_moderate_coupled | 1.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F3 | ewma | qlearn | +0.735 | 9.10e-07 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F4 | rova | static_ext | +0.431 | 1.20e-03 | reject | – | static_ext lower-regret | 0 / 0.008 / 0.992 |
| collapse_moderate_coupled | 1.5 | F4 | rova | ewma_ext | -0.418 | 3.52e-05 | reject | reject | rova lower-regret | 1 / 0.0005 / 0 |
| collapse_moderate_coupled | 1.5 | F4 | static_ext | static | +0.216 | 3.47e-03 | reject | – | static lower-regret | 0 / 0.166 / 0.835 |
| collapse_moderate_coupled | 1.5 | F4 | ewma_ext | ewma | +0.129 | 7.40e-01 | – | – | no detected difference | 0.00325 / 0.583 / 0.414 |
| collapse_moderate_coupled | 1.5 | F5 | rova | clairvoyant | +0.899 | 1.63e-11 | reject | reject | clairvoyant lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F5 | rova | rova_single | +0.973 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F6 | rova_tpe | static_tpe | +0.967 | 1.63e-11 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F6 | rova_tpe | ewma_tpe | +0.592 | 1.02e-08 | reject | reject | ewma_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F6 | static_tpe | ewma_tpe | -0.780 | 4.02e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F7 | rova_tpe | rova | -0.912 | 2.10e-11 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F7 | static_tpe | static | -0.996 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F7 | ewma_tpe | ewma | -0.985 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F8 | abl_no_memory | abl_full | -0.492 | 4.84e-06 | reject | reject | abl_no_memory lower-regret | 1 / 0.00025 / 0 |
| collapse_moderate_coupled | 1.5 | F8 | abl_no_decay | abl_full | +0.391 | 1.36e-03 | reject | – | abl_full lower-regret | 0 / 0.0185 / 0.982 |
| collapse_moderate_coupled | 1.5 | F8 | abl_no_propagation | abl_full | -0.449 | 1.50e-08 | reject | reject | abl_no_propagation lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F8 | abl_no_stability | abl_full | -0.301 | 4.22e-02 | reject | – | abl_no_stability lower-regret | 0.866 / 0.134 / 0.001 |
| collapse_moderate_coupled | 1.5 | F10 | rova_out | static | +0.617 | 1.81e-09 | reject | reject | static lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 1.5 | F10 | rova_out | ewma_out | +0.294 | 5.64e-03 | reject | – | ewma_out lower-regret | 0 / 0.0335 / 0.967 |
| collapse_moderate_coupled | 1.5 | F10 | rova | rova_out | +0.205 | 4.22e-02 | reject | – | rova_out lower-regret | 0.001 / 0.309 / 0.69 |
| collapse_moderate_coupled | 1.5 | F10 | ewma | ewma_out | +0.411 | 3.52e-06 | reject | reject | ewma_out lower-regret | 0 / 0.00375 / 0.996 |
| collapse_moderate_coupled | 1.5 | F11 | rova_pb | static_pb | +0.003 | 4.84e-01 | – | – | no detected difference | 0.0767 / 0.838 / 0.0855 |
| collapse_moderate_coupled | 1.5 | F11 | rova_pb | ewma_pb | -0.503 | 1.84e-04 | reject | – | rova_pb lower-regret | 1 / 0.0005 / 0 |
| collapse_moderate_coupled | 1.5 | F11 | static_pb | ewma_pb | -0.556 | 1.04e-09 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F12 | rova_pb | rova | -0.669 | 8.21e-09 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 1.5 | F12 | static_pb | static | -0.088 | 1.78e-01 | – | – | no detected difference | 0.317 / 0.662 / 0.0213 |
| collapse_moderate_coupled | 1.5 | F12 | ewma_pb | ewma | -0.318 | 1.73e-05 | reject | reject | ewma_pb lower-regret | 0.992 / 0.00825 / 0 |
| collapse_moderate_coupled | 1.5 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 3.5 | F1 | rova | static | +0.378 | 5.51e-03 | reject | – | static lower-regret | 0 / 0.0302 / 0.97 |
| collapse_moderate_coupled | 3.5 | F1 | rova | ewma | -0.413 | 2.13e-06 | reject | reject | rova lower-regret | 0.997 / 0.0035 / 0 |
| collapse_moderate_coupled | 3.5 | F1 | static | ewma | -0.637 | 2.51e-08 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F2 | rova | A0 | -0.524 | 5.32e-08 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F2 | static | A0 | -0.665 | 8.70e-08 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F2 | ewma | A0 | -0.103 | 5.51e-01 | – | – | no detected difference | 0.323 / 0.673 / 0.0045 |
| collapse_moderate_coupled | 3.5 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F3 | rova | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F3 | rova | qlearn | +0.802 | 9.75e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F3 | static | qlearn | +0.675 | 1.14e-06 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F3 | ewma | qlearn | +0.881 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F4 | rova | static_ext | +0.368 | 1.17e-03 | reject | – | static_ext lower-regret | 0.00025 / 0.0253 / 0.975 |
| collapse_moderate_coupled | 3.5 | F4 | rova | ewma_ext | -0.335 | 6.41e-05 | reject | – | rova lower-regret | 0.985 / 0.0152 / 0 |
| collapse_moderate_coupled | 3.5 | F4 | static_ext | static | +0.098 | 1.62e-01 | – | – | no detected difference | 0.00025 / 0.759 / 0.24 |
| collapse_moderate_coupled | 3.5 | F4 | ewma_ext | ewma | -0.068 | 1.53e-01 | – | – | no detected difference | 0.124 / 0.874 / 0.0015 |
| collapse_moderate_coupled | 3.5 | F5 | rova | clairvoyant | -0.031 | 8.08e-01 | – | – | no detected difference | 0.123 / 0.83 / 0.0467 |
| collapse_moderate_coupled | 3.5 | F5 | rova | rova_single | +1.000 | 1.63e-11 | reject | reject | rova_single lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F6 | rova_tpe | static_tpe | +0.939 | 1.63e-11 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F6 | rova_tpe | ewma_tpe | +0.779 | 1.02e-08 | reject | reject | ewma_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F6 | static_tpe | ewma_tpe | -0.486 | 3.00e-07 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F7 | rova_tpe | rova | -0.494 | 1.65e-06 | reject | reject | rova_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F8 | abl_no_memory | abl_full | -0.424 | 4.77e-07 | reject | reject | abl_no_memory lower-regret | 0.997 / 0.00275 / 0 |
| collapse_moderate_coupled | 3.5 | F8 | abl_no_decay | abl_full | -0.171 | 2.24e-01 | – | – | no detected difference | 0.594 / 0.405 / 0.001 |
| collapse_moderate_coupled | 3.5 | F8 | abl_no_propagation | abl_full | +0.186 | 2.76e-01 | – | – | no detected difference | 0.0015 / 0.367 / 0.631 |
| collapse_moderate_coupled | 3.5 | F8 | abl_no_stability | abl_full | -0.136 | 4.94e-01 | – | – | no detected difference | 0.472 / 0.522 / 0.00525 |
| collapse_moderate_coupled | 3.5 | F10 | rova_out | static | +0.378 | 4.12e-05 | reject | reject | static lower-regret | 0 / 0.004 / 0.996 |
| collapse_moderate_coupled | 3.5 | F10 | rova_out | ewma_out | +0.017 | 7.97e-01 | – | – | no detected difference | 0.0345 / 0.9 / 0.0655 |
| collapse_moderate_coupled | 3.5 | F10 | rova | rova_out | +0.013 | 8.25e-01 | – | – | no detected difference | 0.053 / 0.86 / 0.0875 |
| collapse_moderate_coupled | 3.5 | F10 | ewma | ewma_out | +0.404 | 6.02e-04 | reject | – | ewma_out lower-regret | 0 / 0.00275 / 0.997 |
| collapse_moderate_coupled | 3.5 | F11 | rova_pb | static_pb | +0.622 | 1.98e-06 | reject | reject | static_pb lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 3.5 | F11 | rova_pb | ewma_pb | -0.228 | 1.22e-01 | – | – | no detected difference | 0.771 / 0.229 / 0 |
| collapse_moderate_coupled | 3.5 | F11 | static_pb | ewma_pb | -0.749 | 1.44e-10 | reject | reject | static_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 3.5 | F12 | rova_pb | rova | -0.176 | 1.09e-02 | reject | – | rova_pb lower-regret | 0.634 / 0.366 / 0 |
| collapse_moderate_coupled | 3.5 | F12 | static_pb | static | -0.291 | 9.58e-04 | reject | – | static_pb lower-regret | 0.955 / 0.0447 / 0 |
| collapse_moderate_coupled | 3.5 | F12 | ewma_pb | ewma | -0.363 | 2.56e-08 | reject | reject | ewma_pb lower-regret | 0.999 / 0.00125 / 0 |
| collapse_moderate_coupled | 3.5 | F13 | abl_full | rova | +0.062 | 1.50e-02 | reject | – | no detected difference | 0 / 0.99 / 0.00975 |
| collapse_moderate_coupled | 8.0 | F1 | rova | static | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F1 | rova | ewma | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F1 | static | ewma | -0.365 | 1.03e-03 | reject | – | static lower-regret | 0.992 / 0.00775 / 0 |
| collapse_moderate_coupled | 8.0 | F2 | rova | A0 | -0.012 | 4.94e-02 | reject | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 8.0 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F2 | static | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F2 | ewma | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F3 | rova | learned | +0.738 | 5.99e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F3 | rova | qlearn | +0.315 | 5.73e-08 | reject | reject | qlearn lower-regret | 0 / 0.00075 / 0.999 |
| collapse_moderate_coupled | 8.0 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F4 | rova | static_ext | -0.012 | 4.94e-02 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 8.0 | F4 | rova | ewma_ext | -0.012 | 4.94e-02 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 8.0 | F4 | static_ext | static | -1.000 | 1.63e-11 | reject | reject | static_ext lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F4 | ewma_ext | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F5 | rova | clairvoyant | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F5 | rova | rova_single | +0.171 | 1.91e-03 | reject | – | rova_single lower-regret | 0 / 0.33 / 0.67 |
| collapse_moderate_coupled | 8.0 | F6 | rova_tpe | static_tpe | +0.434 | 2.41e-10 | reject | reject | static_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F6 | rova_tpe | ewma_tpe | +0.342 | 6.52e-10 | reject | reject | ewma_tpe lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F6 | static_tpe | ewma_tpe | -0.174 | 6.76e-09 | reject | reject | static_tpe lower-regret | 0.803 / 0.197 / 0 |
| collapse_moderate_coupled | 8.0 | F7 | rova_tpe | rova | +0.012 | 4.94e-02 | reject | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 8.0 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F8 | abl_no_memory | abl_full | +0.150 | 3.82e-01 | – | – | no detected difference | 0 / 0.519 / 0.481 |
| collapse_moderate_coupled | 8.0 | F8 | abl_no_decay | abl_full | +0.373 | 2.50e-05 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F8 | abl_no_propagation | abl_full | +0.407 | 1.05e-05 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F8 | abl_no_stability | abl_full | +0.396 | 9.87e-05 | reject | – | abl_full lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 8.0 | F10 | rova_out | static | -0.919 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F10 | rova_out | ewma_out | -0.949 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F10 | rova | rova_out | -0.876 | 7.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F10 | ewma | ewma_out | +0.280 | 9.36e-03 | reject | – | ewma_out lower-regret | 0 / 0.081 / 0.919 |
| collapse_moderate_coupled | 8.0 | F11 | rova_pb | static_pb | -0.886 | 1.80e-11 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F11 | rova_pb | ewma_pb | -0.749 | 1.63e-09 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F11 | static_pb | ewma_pb | -0.193 | 4.58e-04 | reject | – | static_pb lower-regret | 0.77 / 0.23 / 0 |
| collapse_moderate_coupled | 8.0 | F12 | rova_pb | rova | +0.012 | 4.94e-02 | reject | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 8.0 | F12 | static_pb | static | -0.473 | 1.53e-03 | reject | – | static_pb lower-regret | 1 / 0.0005 / 0 |
| collapse_moderate_coupled | 8.0 | F12 | ewma_pb | ewma | -0.685 | 1.63e-09 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 8.0 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 20.0 | F1 | rova | static | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F1 | rova | ewma | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F1 | static | ewma | -0.473 | 5.48e-05 | reject | – | static lower-regret | 1 / 0.0005 / 0 |
| collapse_moderate_coupled | 20.0 | F2 | rova | A0 | +0.085 | 4.21e-04 | reject | – | no detected difference | 0 / 0.965 / 0.0348 |
| collapse_moderate_coupled | 20.0 | F2 | rova | A5 | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F2 | static | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F2 | static | A5 | -1.000 | 1.63e-11 | reject | reject | static lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F2 | ewma | A0 | +1.000 | 1.63e-11 | reject | reject | A0 lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F2 | ewma | A5 | -1.000 | 1.63e-11 | reject | reject | ewma lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F3 | rova | learned | +0.215 | 6.57e-08 | reject | reject | learned lower-regret | 0 / 0.05 / 0.95 |
| collapse_moderate_coupled | 20.0 | F3 | rova | qlearn | +0.085 | 4.21e-04 | reject | – | no detected difference | 0 / 0.965 / 0.0348 |
| collapse_moderate_coupled | 20.0 | F3 | static | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F3 | static | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F3 | ewma | learned | +1.000 | 1.63e-11 | reject | reject | learned lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F3 | ewma | qlearn | +1.000 | 1.63e-11 | reject | reject | qlearn lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F4 | rova | static_ext | +0.085 | 4.21e-04 | reject | – | no detected difference | 0 / 0.965 / 0.0348 |
| collapse_moderate_coupled | 20.0 | F4 | rova | ewma_ext | +0.085 | 4.21e-04 | reject | – | no detected difference | 0 / 0.965 / 0.0348 |
| collapse_moderate_coupled | 20.0 | F4 | static_ext | static | -1.000 | 1.63e-11 | reject | reject | static_ext lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F4 | ewma_ext | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_ext lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F5 | rova | clairvoyant | -1.000 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F5 | rova | rova_single | +0.085 | 4.21e-04 | reject | – | no detected difference | 0 / 0.965 / 0.0348 |
| collapse_moderate_coupled | 20.0 | F6 | rova_tpe | static_tpe | -0.019 | 9.40e-02 | – | – | no detected difference | 0.0075 / 0.992 / 0.00075 |
| collapse_moderate_coupled | 20.0 | F6 | rova_tpe | ewma_tpe | -0.006 | 6.53e-01 | – | – | no detected difference | 0 / 1 / 0 |
| collapse_moderate_coupled | 20.0 | F6 | static_tpe | ewma_tpe | +0.005 | 7.13e-02 | – | – | no detected difference | 0.00125 / 0.997 / 0.002 |
| collapse_moderate_coupled | 20.0 | F7 | rova_tpe | rova | -0.085 | 4.21e-04 | reject | – | no detected difference | 0.0348 / 0.965 / 0 |
| collapse_moderate_coupled | 20.0 | F7 | static_tpe | static | -1.000 | 1.63e-11 | reject | reject | static_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F7 | ewma_tpe | ewma | -1.000 | 1.63e-11 | reject | reject | ewma_tpe lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F8 | abl_no_memory | abl_full | +0.168 | 4.11e-03 | reject | – | abl_full lower-regret | 0 / 0.377 / 0.623 |
| collapse_moderate_coupled | 20.0 | F8 | abl_no_decay | abl_full | +0.403 | 1.32e-06 | reject | reject | abl_full lower-regret | 0 / 0 / 1 |
| collapse_moderate_coupled | 20.0 | F8 | abl_no_propagation | abl_full | +0.356 | 2.92e-04 | reject | – | abl_full lower-regret | 0 / 0.0035 / 0.997 |
| collapse_moderate_coupled | 20.0 | F8 | abl_no_stability | abl_full | +0.319 | 1.58e-05 | reject | reject | abl_full lower-regret | 0 / 0.00675 / 0.993 |
| collapse_moderate_coupled | 20.0 | F10 | rova_out | static | -0.992 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F10 | rova_out | ewma_out | -0.990 | 1.63e-11 | reject | reject | rova_out lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F10 | rova | rova_out | -0.993 | 1.63e-11 | reject | reject | rova lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F10 | ewma | ewma_out | +0.407 | 2.26e-04 | reject | – | ewma_out lower-regret | 0 / 0.003 / 0.997 |
| collapse_moderate_coupled | 20.0 | F11 | rova_pb | static_pb | -1.000 | 1.63e-11 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F11 | rova_pb | ewma_pb | -0.823 | 1.63e-09 | reject | reject | rova_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F11 | static_pb | ewma_pb | -0.116 | 2.39e-01 | – | – | no detected difference | 0.317 / 0.683 / 0 |
| collapse_moderate_coupled | 20.0 | F12 | rova_pb | rova | -0.085 | 4.21e-04 | reject | – | no detected difference | 0.0348 / 0.965 / 0 |
| collapse_moderate_coupled | 20.0 | F12 | static_pb | static | -0.490 | 4.35e-04 | reject | – | static_pb lower-regret | 0.999 / 0.00075 / 0 |
| collapse_moderate_coupled | 20.0 | F12 | ewma_pb | ewma | -0.799 | 1.63e-09 | reject | reject | ewma_pb lower-regret | 1 / 0 / 0 |
| collapse_moderate_coupled | 20.0 | F13 | abl_full | rova | +0.000 | 1.00e+00 | – | – | no detected difference | 0 / 1 / 0 |

## Protocol decision rules (DR1–DR8, applied mechanically)

| pair | DR2 | DR8 no practically significant difference | DR1 by c |
|---|---|---|---|
| rova_vs_static | operating-condition-dependent advantage | False | c=0.5: static superior; c=1.5: static superior; c=3.5: no superiority claim; c=8.0: rova superior; c=20.0: rova superior |
| rova_vs_ewma | operating-condition-dependent advantage | False | c=0.5: no superiority claim (DR6 env-specific); c=1.5: ewma superior; c=3.5: rova superior; c=8.0: rova superior; c=20.0: rova superior |
| static_vs_ewma | operating-condition-dependent advantage | False | c=0.5: no superiority claim (DR6 env-specific); c=1.5: static superior; c=3.5: static superior; c=8.0: no superiority claim; c=20.0: no superiority claim |
| rova_vs_A0 | operating-condition-dependent advantage | False | c=0.5: rova superior; c=1.5: rova superior; c=3.5: no superiority claim; c=8.0: no superiority claim; c=20.0: no superiority claim |
| rova_vs_A5 | operating-condition-dependent advantage | False | c=0.5: rova superior; c=1.5: rova superior; c=3.5: rova superior; c=8.0: rova superior; c=20.0: rova superior |
| static_vs_A0 | operating-condition-dependent advantage | False | c=0.5: static superior; c=1.5: static superior; c=3.5: no superiority claim (DR6 env-specific); c=8.0: A0 superior; c=20.0: A0 superior |
| static_vs_A5 | operating-condition-dependent advantage | False | c=0.5: static superior; c=1.5: static superior; c=3.5: static superior; c=8.0: static superior; c=20.0: static superior |
| ewma_vs_A0 | operating-condition-dependent advantage | False | c=0.5: ewma superior; c=1.5: ewma superior; c=3.5: A0 superior; c=8.0: A0 superior; c=20.0: A0 superior |
| ewma_vs_A5 | operating-condition-dependent advantage | False | c=0.5: ewma superior; c=1.5: ewma superior; c=3.5: ewma superior; c=8.0: ewma superior; c=20.0: ewma superior |
| rova_vs_learned | operating-condition-dependent advantage | False | c=0.5: learned superior; c=1.5: learned superior; c=3.5: learned superior; c=8.0: learned superior; c=20.0: no superiority claim |
| rova_vs_qlearn | operating-condition-dependent advantage | False | c=0.5: qlearn superior; c=1.5: qlearn superior; c=3.5: qlearn superior; c=8.0: qlearn superior; c=20.0: no superiority claim |
| static_vs_learned | learned generally superior | False | c=0.5: learned superior; c=1.5: learned superior; c=3.5: learned superior; c=8.0: learned superior; c=20.0: learned superior |
| static_vs_qlearn | operating-condition-dependent advantage | False | c=0.5: qlearn superior; c=1.5: qlearn superior; c=3.5: qlearn superior; c=8.0: qlearn superior; c=20.0: qlearn superior |
| ewma_vs_learned | learned generally superior | False | c=0.5: learned superior; c=1.5: learned superior; c=3.5: learned superior; c=8.0: learned superior; c=20.0: learned superior |
| ewma_vs_qlearn | operating-condition-dependent advantage | False | c=0.5: qlearn superior; c=1.5: qlearn superior; c=3.5: qlearn superior; c=8.0: qlearn superior; c=20.0: qlearn superior |
| rova_vs_static_ext | operating-condition-dependent advantage | False | c=0.5: static_ext superior; c=1.5: static_ext superior; c=3.5: no superiority claim; c=8.0: no superiority claim; c=20.0: no superiority claim |
| rova_vs_ewma_ext | no superiority claim | False | c=0.5: no superiority claim; c=1.5: no superiority claim; c=3.5: no superiority claim; c=8.0: no superiority claim; c=20.0: no superiority claim |
| static_ext_vs_static | operating-condition-dependent advantage | False | c=0.5: no superiority claim; c=1.5: no superiority claim; c=3.5: no superiority claim; c=8.0: static_ext superior; c=20.0: static_ext superior |
| ewma_ext_vs_ewma | operating-condition-dependent advantage | False | c=0.5: ewma superior; c=1.5: no superiority claim; c=3.5: ewma_ext superior; c=8.0: ewma_ext superior; c=20.0: ewma_ext superior |
| rova_vs_clairvoyant | operating-condition-dependent advantage | False | c=0.5: clairvoyant superior; c=1.5: clairvoyant superior; c=3.5: no superiority claim; c=8.0: rova superior; c=20.0: rova superior |
| rova_vs_rova_single | operating-condition-dependent advantage | False | c=0.5: rova_single superior; c=1.5: rova_single superior; c=3.5: rova_single superior; c=8.0: no superiority claim; c=20.0: no superiority claim |
| rova_tpe_vs_static_tpe | operating-condition-dependent advantage | False | c=0.5: static_tpe superior; c=1.5: static_tpe superior; c=3.5: static_tpe superior; c=8.0: static_tpe superior; c=20.0: no superiority claim |
| rova_tpe_vs_ewma_tpe | no superiority claim | False | c=0.5: no superiority claim (DR6 env-specific); c=1.5: no superiority claim (DR6 env-specific); c=3.5: no superiority claim (DR6 env-specific); c=8.0: no superiority claim (DR6 env-specific); c=20.0: no superiority claim |
| static_tpe_vs_ewma_tpe | operating-condition-dependent advantage | False | c=0.5: static_tpe superior; c=1.5: static_tpe superior; c=3.5: static_tpe superior; c=8.0: no superiority claim; c=20.0: no superiority claim (DR6 env-specific) |
| rova_out_vs_static | operating-condition-dependent advantage | False | c=0.5: static superior; c=1.5: static superior; c=3.5: no superiority claim (DR6 env-specific); c=8.0: rova_out superior; c=20.0: rova_out superior |
| rova_out_vs_ewma_out | operating-condition-dependent advantage | False | c=0.5: ewma_out superior; c=1.5: no superiority claim (DR6 env-specific); c=3.5: rova_out superior; c=8.0: rova_out superior; c=20.0: rova_out superior |
| rova_vs_rova_out | operating-condition-dependent advantage | False | c=0.5: no superiority claim (DR6 env-specific); c=1.5: no superiority claim; c=3.5: no superiority claim; c=8.0: rova superior; c=20.0: rova superior |
| ewma_vs_ewma_out | no superiority claim | False | c=0.5: no superiority claim (DR6 env-specific); c=1.5: no superiority claim; c=3.5: no superiority claim (DR6 env-specific); c=8.0: no superiority claim; c=20.0: no superiority claim |
| rova_pb_vs_static_pb | operating-condition-dependent advantage | False | c=0.5: no superiority claim (DR6 env-specific); c=1.5: static_pb superior; c=3.5: no superiority claim (DR6 env-specific); c=8.0: rova_pb superior; c=20.0: rova_pb superior |
| rova_pb_vs_ewma_pb | operating-condition-dependent advantage | False | c=0.5: no superiority claim; c=1.5: no superiority claim; c=3.5: no superiority claim; c=8.0: rova_pb superior; c=20.0: rova_pb superior |
| static_pb_vs_ewma_pb | operating-condition-dependent advantage | False | c=0.5: static_pb superior; c=1.5: static_pb superior; c=3.5: static_pb superior; c=8.0: no superiority claim; c=20.0: no superiority claim (DR6 env-specific) |

DR3 (factorial):

- memory: c=0.5: joint/interacting effect (2/8); c=1.5: not detected at this budget (0/8); c=3.5: not detected at this budget (0/8); c=8.0: not detected at this budget (0/8); c=20.0: joint/interacting effect (3/8)
- decay: c=0.5: not detected at this budget (0/8); c=1.5: not detected at this budget (0/8); c=3.5: not detected at this budget (0/8); c=8.0: not detected at this budget (0/8); c=20.0: joint/interacting effect (1/8)
- propagation: c=0.5: joint/interacting effect (2/8); c=1.5: not detected at this budget (0/8); c=3.5: not detected at this budget (0/8); c=8.0: joint/interacting effect (3/8); c=20.0: joint/interacting effect (2/8)
- stability: c=0.5: not detected at this budget (0/8); c=1.5: not detected at this budget (0/8); c=3.5: not detected at this budget (0/8); c=8.0: not detected at this budget (0/8); c=20.0: joint/interacting effect (1/8)

DR4: {'no_component_contributes': True, 'penalties_indistinguishable_from_zero': True, 'rova_weakly_dominates_static': False, 'DR4_fires_vs_static': False, 'rova_weakly_dominates_ewma': False, 'DR4_fires_vs_ewma': False}

DR5: protocol section 8 requires TOST at a pre-registered margin, but no numeric margin was specified; the revision makes no equivalence claims

DR7: {'static_over_rova': {'time_ratio': {1: 0.38215197417371555, 6: 0.3110518477176351, 10: 0.30315736441645286}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_over_static': {'time_ratio': {1: 2.616760000160115, 6: 3.214898118553452, 10: 3.2986168814499965}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'ewma_over_rova': {'time_ratio': {1: 0.45633003406954886, 6: 0.3239099219051738, 10: 0.31242768821293876}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_over_ewma': {'time_ratio': {1: 2.1913964134291253, 6: 3.087278074466502, 10: 3.200740644082858}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'static_over_ewma': {'time_ratio': {1: 0.8374464655891399, 6: 0.9603035494809481, 10: 0.9703280978407791}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_over_A0': {'time_ratio': {1: 13.30926059391911, 6: 71.78571080422421, 10: 117.39007063555847}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_over_A5': {'time_ratio': {1: 13.343490135083831, 6: 71.8326850621243, 10: 118.33634464985812}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'static_over_A0': {'time_ratio': {1: 5.086160210758625, 6: 22.329077985377744, 10: 35.587664422537145}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'A0_over_static': {'time_ratio': {1: 0.19661197417350823, 6: 0.0447846525796924, 10: 0.028099624300343653}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_over_A5': {'time_ratio': {1: 5.099241097489784, 6: 22.343689415092726, 10: 35.874534358728}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'ewma_over_A0': {'time_ratio': {1: 6.073415340263612, 6: 23.252103980503655, 10: 36.675908387821124}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'A0_over_ewma': {'time_ratio': {1: 0.16465200286410772, 6: 0.04300686083454971, 10: 0.02726585499739299}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'ewma_over_A5': {'time_ratio': {1: 6.089035307949493, 6: 23.267319408711625, 10: 36.971550590524735}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'learned_over_rova': {'time_ratio': {1: 1.2643256701323622, 6: 0.2516217653384628, 10: 0.15824982407787183}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'qlearn_over_rova': {'time_ratio': {1: 0.760556175595238, 6: 0.13902403364286772, 10: 0.0863675298978169}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'learned_over_static': {'time_ratio': {1: 3.308436840777997, 6: 0.8089383399737223, 10: 0.5220055411897602}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'qlearn_over_static': {'time_ratio': {1: 1.9901929781723715, 6: 0.4469481041921673, 10: 0.28489339213007614}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'learned_over_ewma': {'time_ratio': {1: 2.770638738934434, 6: 0.7768263591879915, 10: 0.5065166438450065}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'qlearn_over_ewma': {'time_ratio': {1: 1.666680075410777, 6: 0.4292058508895189, 10: 0.2764400632729839}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_ext_over_rova': {'time_ratio': {1: 0.45145334038220547, 6: 0.32251066305405535, 10: 0.31086061029410905}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_ext_over_static': {'time_ratio': {1: 1.1813450430508243, 6: 1.0368389238659088, 10: 1.0254100568939968}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'ewma_over_ewma_ext': {'time_ratio': {1: 0.8677569547022962, 6: 0.9625242767744806, 10: 0.9757694217794012}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'ewma_ext_over_ewma': {'time_ratio': {1: 1.1523964107473765, 6: 1.0389348342995612, 10: 1.0248322786918371}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'clairvoyant_over_rova': {'time_ratio': {1: 0.1934425908521303, 6: 0.1357055325665191, 10: 0.13051626048901502}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_over_clairvoyant': {'time_ratio': {1: 5.169492383217774, 6: 7.368896323440811, 10: 7.661880567626021}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_single_over_rova': {'time_ratio': {1: 1.0, 6: 1.0, 10: 1.0}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_tpe_over_rova_tpe': {'time_ratio': {1: 0.38215197417371555, 6: 0.3110518477176351, 10: 0.30315736441645286}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_tpe_over_ewma_tpe': {'time_ratio': {1: 0.8374464655891399, 6: 0.9603035494809481, 10: 0.9703280978407791}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_over_rova_out': {'time_ratio': {1: 0.38215197417371555, 6: 0.3110518477176351, 10: 0.30315736441645286}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_out_over_static': {'time_ratio': {1: 2.616760000160115, 6: 3.214898118553452, 10: 3.2986168814499965}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'ewma_out_over_rova_out': {'time_ratio': {1: 0.45633003406954886, 6: 0.3239099219051738, 10: 0.31242768821293876}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_out_over_ewma_out': {'time_ratio': {1: 2.1913964134291253, 6: 3.087278074466502, 10: 3.200740644082858}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_over_rova_out': {'time_ratio': {1: 1.0, 6: 1.0, 10: 1.0}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'static_pb_over_rova_pb': {'time_ratio': {1: 0.38215197417371555, 6: 0.3110518477176351, 10: 0.30315736441645286}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_pb_over_static_pb': {'time_ratio': {1: 2.616760000160115, 6: 3.214898118553452, 10: 3.2986168814499965}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'rova_pb_over_ewma_pb': {'time_ratio': {1: 2.1913964134291253, 6: 3.087278074466502, 10: 3.200740644082858}, 'compute_conditional': True, 'timing_note': 'tuned variants timed through their policy class'}, 'static_pb_over_ewma_pb': {'time_ratio': {1: 0.8374464655891399, 6: 0.9603035494809481, 10: 0.9703280978407791}, 'compute_conditional': False, 'timing_note': 'tuned variants timed through their policy class'}}

## Matched-world re-run of the published pipelines

- verdict change unfavorable_oscillation_uncoupled c=3.5: published mixed → matched ROVA_wins

Ablation regime inference (frozen code, matched worlds):

| component | regime | published mean δ | matched mean δ | published option-C p | matched option-C p |
|---|---|---|---|---|---|
| no_memory | low | -0.5814 | -0.5601 | 0.0625 | 0.0625 |
| no_memory | high | 0.2553 | 0.1836 | 0.03125 | 0.03125 |
| no_memory | transition | -0.2948 | -0.3254 | 0.5 | 0.5 |
| no_decay | low | 0.1213 | 0.1517 | 0.25 | 0.25 |
| no_decay | high | 0.2457 | 0.2543 | 0.125 | 0.125 |
| no_decay | transition | -0.08685 | -0.1261 | 0.5 | 0.5 |
| no_propagation | low | -0.383 | -0.332 | 0.03125 | 0.03125 |
| no_propagation | high | 0.3371 | 0.3481 | 0.03125 | 0.03125 |
| no_propagation | transition | 0.2298 | 0.1072 | 0.25 | 0.25 |
| no_stability | low | -0.2217 | -0.2119 | 0.125 | 0.1875 |
| no_stability | high | 0.2721 | 0.3128 | 0.03125 | 0.03125 |
| no_stability | transition | -0.04093 | -0.1019 | 1 | 0.5 |

## Distribution shift (matched worlds)

| method | shifted mean | in-distribution mean | degradation | 95% CI |
|---|---|---|---|---|
| static | 0.1015 | 0.09545 | 0.006077 | [-0.007655, 0.0201] |
| ewma | 0.1772 | 0.1528 | 0.02441 | [0.009043, 0.04048] |
| rova | 0.06949 | 0.07746 | -0.00797 | [-0.01668, 0.0008087] |
| A0 | 0.06814 | 0.08764 | -0.01951 | [-0.03025, -0.008636] |
| A5 | 0.7149 | 1.478 | -0.7629 | [-0.8346, -0.689] |
| learned | 0.007092 | 0.001989 | 0.005104 | [0.004759, 0.005449] |
| qlearn | 0.01279 | 0.00901 | 0.003776 | [0.00257, 0.00502] |
| static_ext | 0.06488 | 0.07197 | -0.007098 | [-0.0161, 0.002062] |
| ewma_ext | 0.07215 | 0.08509 | -0.01294 | [-0.0225, -0.003226] |
| clairvoyant | 0.093 | 0.1052 | -0.01225 | [-0.02523, 0.0006083] |

Published (method-specific worlds): {'rova': -0.008230367661547512, 'ewma': 0.026318934324410247}

## Adversarial scenarios (R5a transfer; R5b re-tuned)

| profile / env / c | R5a verdict (attacked) | R5a verdict (same worlds, clean) | R5b verdict |
|---|---|---|---|
| ramp_defect|favorable_hmm_coupled|0.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| ramp_defect|favorable_hmm_coupled|1.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| ramp_defect|favorable_hmm_coupled|3.5 | ROVA_wins | mixed | ROVA_wins |
| ramp_defect|favorable_hmm_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| ramp_defect|favorable_hmm_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| ramp_defect|unfavorable_oscillation_uncoupled|0.5 | mixed | mixed | mixed |
| ramp_defect|unfavorable_oscillation_uncoupled|1.5 | ROVA_wins | ROVA_loses | ROVA_wins |
| ramp_defect|unfavorable_oscillation_uncoupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| ramp_defect|unfavorable_oscillation_uncoupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| ramp_defect|unfavorable_oscillation_uncoupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| ramp_defect|collapse_moderate_coupled|0.5 | mixed | mixed | mixed |
| ramp_defect|collapse_moderate_coupled|1.5 | mixed | mixed | ROVA_wins |
| ramp_defect|collapse_moderate_coupled|3.5 | ROVA_wins | mixed | ROVA_wins |
| ramp_defect|collapse_moderate_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| ramp_defect|collapse_moderate_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| collusion|favorable_hmm_coupled|0.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| collusion|favorable_hmm_coupled|1.5 | mixed | ROVA_loses | mixed |
| collusion|favorable_hmm_coupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| collusion|favorable_hmm_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| collusion|favorable_hmm_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| collusion|collapse_moderate_coupled|0.5 | mixed | mixed | ROVA_wins |
| collusion|collapse_moderate_coupled|1.5 | mixed | mixed | ROVA_wins |
| collusion|collapse_moderate_coupled|3.5 | ROVA_wins | mixed | ROVA_wins |
| collusion|collapse_moderate_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| collusion|collapse_moderate_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| poisoning|favorable_hmm_coupled|0.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| poisoning|favorable_hmm_coupled|1.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| poisoning|favorable_hmm_coupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| poisoning|favorable_hmm_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| poisoning|favorable_hmm_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| poisoning|collapse_moderate_coupled|0.5 | mixed | mixed | mixed |
| poisoning|collapse_moderate_coupled|1.5 | mixed | mixed | ROVA_wins |
| poisoning|collapse_moderate_coupled|3.5 | ROVA_wins | mixed | ROVA_wins |
| poisoning|collapse_moderate_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| poisoning|collapse_moderate_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |

## Simulator-assumption sensitivity (R9a re-tuned; R9b transfer)

| perturbation / env / c | R9a verdict | R9b verdict | unperturbed CEW verdict |
|---|---|---|---|
| K1_mnar|favorable_hmm_coupled|0.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| K1_mnar|favorable_hmm_coupled|1.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| K1_mnar|favorable_hmm_coupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|favorable_hmm_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|favorable_hmm_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|unfavorable_oscillation_uncoupled|0.5 | mixed | mixed | mixed |
| K1_mnar|unfavorable_oscillation_uncoupled|1.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| K1_mnar|unfavorable_oscillation_uncoupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|unfavorable_oscillation_uncoupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|unfavorable_oscillation_uncoupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|collapse_moderate_coupled|0.5 | mixed | mixed | mixed |
| K1_mnar|collapse_moderate_coupled|1.5 | mixed | mixed | mixed |
| K1_mnar|collapse_moderate_coupled|3.5 | mixed | mixed | mixed |
| K1_mnar|collapse_moderate_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K1_mnar|collapse_moderate_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|favorable_hmm_coupled|0.5 | mixed | mixed | ROVA_loses |
| K2_delay|favorable_hmm_coupled|1.5 | mixed | ROVA_loses | ROVA_loses |
| K2_delay|favorable_hmm_coupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|favorable_hmm_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|favorable_hmm_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|unfavorable_oscillation_uncoupled|0.5 | mixed | mixed | mixed |
| K2_delay|unfavorable_oscillation_uncoupled|1.5 | mixed | ROVA_wins | ROVA_loses |
| K2_delay|unfavorable_oscillation_uncoupled|3.5 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|unfavorable_oscillation_uncoupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|unfavorable_oscillation_uncoupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|collapse_moderate_coupled|0.5 | mixed | mixed | mixed |
| K2_delay|collapse_moderate_coupled|1.5 | mixed | mixed | mixed |
| K2_delay|collapse_moderate_coupled|3.5 | mixed | mixed | mixed |
| K2_delay|collapse_moderate_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K2_delay|collapse_moderate_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K3_conflict|favorable_hmm_coupled|0.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| K3_conflict|favorable_hmm_coupled|1.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| K3_conflict|favorable_hmm_coupled|3.5 | ROVA_wins | mixed | ROVA_wins |
| K3_conflict|favorable_hmm_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K3_conflict|favorable_hmm_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K3_conflict|unfavorable_oscillation_uncoupled|0.5 | mixed | mixed | mixed |
| K3_conflict|unfavorable_oscillation_uncoupled|1.5 | ROVA_loses | ROVA_loses | ROVA_loses |
| K3_conflict|unfavorable_oscillation_uncoupled|3.5 | mixed | mixed | ROVA_wins |
| K3_conflict|unfavorable_oscillation_uncoupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K3_conflict|unfavorable_oscillation_uncoupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K3_conflict|collapse_moderate_coupled|0.5 | ROVA_loses | mixed | mixed |
| K3_conflict|collapse_moderate_coupled|1.5 | mixed | mixed | mixed |
| K3_conflict|collapse_moderate_coupled|3.5 | mixed | ROVA_wins | mixed |
| K3_conflict|collapse_moderate_coupled|8.0 | ROVA_wins | ROVA_wins | ROVA_wins |
| K3_conflict|collapse_moderate_coupled|20.0 | ROVA_wins | ROVA_wins | ROVA_wins |

## Sequential oracle (R7; exhaustive over all joint levels)

| env | N | c | source | gap per agent-step | 95% CI | disagreement | max abs(vertex − exhaustive) | worlds differing |
|---|---|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 2 | 0.5 | reduced instances | 0.0003577 | [0.0002332, 0.0005318] | 0.007305 | 2.132e-13 | 0 |
| favorable_hmm_coupled | 2 | 1.5 | reduced instances | 0.0008517 | [0.0005052, 0.001413] | 0.00998 | 5.116e-13 | 0 |
| favorable_hmm_coupled | 2 | 3.5 | reduced instances | 0.000322 | [0.0001774, 0.0005347] | 0.007007 | 5.116e-13 | 0 |
| favorable_hmm_coupled | 2 | 8.0 | reduced instances | 3.426e-05 | [1.765e-05, 6.402e-05] | 0.001578 | 9.663e-13 | 0 |
| favorable_hmm_coupled | 2 | 20.0 | reduced instances | 1.023e-16 | [-3.032e-17, 2.427e-16] | 0 | 7.39e-13 | 0 |
| favorable_hmm_coupled | 3 | 0.5 | reduced instances | 0.0007347 | [0.0005063, 0.001041] | 0.01192 | 3.553e-13 | 0 |
| favorable_hmm_coupled | 3 | 1.5 | reduced instances | 0.001558 | [0.001173, 0.002005] | 0.0179 | 9.095e-13 | 0 |
| favorable_hmm_coupled | 3 | 3.5 | reduced instances | 0.0007338 | [0.0005317, 0.001035] | 0.01384 | 1.251e-12 | 0 |
| favorable_hmm_coupled | 3 | 8.0 | reduced instances | 8.629e-05 | [4.363e-05, 0.0001658] | 0.002334 | 1.364e-12 | 0 |
| favorable_hmm_coupled | 3 | 20.0 | reduced instances | 2.164e-06 | [5.731e-07, 5.627e-06] | 0.0001556 | 7.958e-13 | 0 |
| favorable_hmm_coupled | 4 | 0.5 | reduced instances | 0.001271 | [0.0009048, 0.002037] | 0.01802 | 5.4e-13 | 0 |
| favorable_hmm_coupled | 4 | 1.5 | reduced instances | 0.002177 | [0.001766, 0.002694] | 0.02605 | 1.307e-12 | 0 |
| favorable_hmm_coupled | 4 | 3.5 | reduced instances | 0.0009597 | [0.0007148, 0.001305] | 0.01556 | 1.478e-12 | 0 |
| favorable_hmm_coupled | 4 | 8.0 | reduced instances | 0.0001177 | [8.076e-05, 0.0001741] | 0.003669 | 1.592e-12 | 0 |
| favorable_hmm_coupled | 4 | 20.0 | reduced instances | 2.705e-06 | [1.009e-06, 6.401e-06] | 0.0001833 | 1.592e-12 | 0 |
| favorable_hmm_coupled | 5 | 0.5 | reduced instances | 0.001638 | [0.001318, 0.002039] | 0.02327 | 7.958e-13 | 0 |
| favorable_hmm_coupled | 5 | 1.5 | reduced instances | 0.002801 | [0.002328, 0.003362] | 0.02942 | 1.705e-12 | 0 |
| favorable_hmm_coupled | 5 | 3.5 | reduced instances | 0.001589 | [0.001334, 0.001886] | 0.02461 | 2.387e-12 | 0 |
| favorable_hmm_coupled | 5 | 8.0 | reduced instances | 0.0001467 | [0.0001062, 0.0002056] | 0.004221 | 2.16e-12 | 0 |
| favorable_hmm_coupled | 5 | 20.0 | reduced instances | 4.55e-06 | [2.464e-06, 8.017e-06] | 0.0003196 | 2.842e-12 | 0 |
| favorable_hmm_coupled | 6 | 0.5 | reduced instances | 0.002728 | [0.002138, 0.00349] | 0.03177 | 9.095e-13 | 0 |
| favorable_hmm_coupled | 6 | 1.5 | reduced instances | 0.003806 | [0.003316, 0.00438] | 0.03888 | 2.387e-12 | 0 |
| favorable_hmm_coupled | 6 | 3.5 | reduced instances | 0.002111 | [0.001749, 0.002639] | 0.02887 | 3.752e-12 | 0 |
| favorable_hmm_coupled | 6 | 8.0 | reduced instances | 0.0002003 | [0.0001361, 0.0003243] | 0.005049 | 2.501e-12 | 0 |
| favorable_hmm_coupled | 6 | 20.0 | reduced instances | 3.219e-06 | [1.684e-06, 6.53e-06] | 0.0001662 | 2.501e-12 | 0 |
| collapse_moderate_coupled | 2 | 0.5 | reduced instances | 9.804e-06 | [3.062e-06, 2.565e-05] | 0.0009656 | 4.121e-13 | 0 |
| collapse_moderate_coupled | 2 | 1.5 | reduced instances | 8.247e-06 | [2.099e-17, 3.897e-05] | 5.96e-05 | 3.411e-13 | 0 |
| collapse_moderate_coupled | 2 | 3.5 | reduced instances | 0.0001618 | [5.893e-05, 0.0005017] | 0.003192 | 3.979e-13 | 0 |
| collapse_moderate_coupled | 2 | 8.0 | reduced instances | 5.732e-06 | [9.038e-07, 1.723e-05] | 0.00036 | 5.116e-13 | 0 |
| collapse_moderate_coupled | 2 | 20.0 | reduced instances | 3.986e-07 | [-1.359e-17, 1.74e-06] | 6.59e-05 | 3.979e-13 | 0 |
| collapse_moderate_coupled | 3 | 0.5 | reduced instances | 6.439e-05 | [3.044e-05, 0.0001474] | 0.003741 | 3.695e-13 | 0 |
| collapse_moderate_coupled | 3 | 1.5 | reduced instances | 0.0001571 | [5.963e-05, 0.0004041] | 0.002504 | 5.4e-13 | 0 |
| collapse_moderate_coupled | 3 | 3.5 | reduced instances | 0.0003676 | [0.0001755, 0.0007708] | 0.006147 | 7.39e-13 | 0 |
| collapse_moderate_coupled | 3 | 8.0 | reduced instances | 6.534e-06 | [2.626e-06, 1.51e-05] | 0.0003756 | 7.958e-13 | 0 |
| collapse_moderate_coupled | 3 | 20.0 | reduced instances | 4.878e-07 | [1.114e-07, 1.463e-06] | 0.0001102 | 6.821e-13 | 0 |
| collapse_moderate_coupled | 4 | 0.5 | reduced instances | 0.0001177 | [5.174e-05, 0.0003232] | 0.004549 | 7.39e-13 | 0 |
| collapse_moderate_coupled | 4 | 1.5 | reduced instances | 8.49e-05 | [4.462e-05, 0.0001629] | 0.001373 | 7.958e-13 | 0 |
| collapse_moderate_coupled | 4 | 3.5 | reduced instances | 0.0003386 | [0.0002108, 0.0005526] | 0.006342 | 1.705e-12 | 0 |
| collapse_moderate_coupled | 4 | 8.0 | reduced instances | 1.701e-05 | [1.028e-05, 3.197e-05] | 0.0009325 | 1.592e-12 | 0 |
| collapse_moderate_coupled | 4 | 20.0 | reduced instances | 8.784e-07 | [2.959e-07, 2.282e-06] | 0.0001167 | 1.023e-12 | 0 |
| collapse_moderate_coupled | 5 | 0.5 | reduced instances | 0.0001539 | [6.123e-05, 0.0005062] | 0.005326 | 9.379e-13 | 0 |
| collapse_moderate_coupled | 5 | 1.5 | reduced instances | 0.0002162 | [0.0001116, 0.0004357] | 0.002803 | 1.194e-12 | 0 |
| collapse_moderate_coupled | 5 | 3.5 | reduced instances | 0.00066 | [0.0004394, 0.001127] | 0.01038 | 2.501e-12 | 0 |
| collapse_moderate_coupled | 5 | 8.0 | reduced instances | 3.719e-05 | [2.546e-05, 5.657e-05] | 0.001673 | 1.592e-12 | 0 |
| collapse_moderate_coupled | 5 | 20.0 | reduced instances | 9.26e-07 | [4.626e-07, 1.673e-06] | 0.0001463 | 1.819e-12 | 0 |
| collapse_moderate_coupled | 6 | 0.5 | full size, common evaluation worlds | 0.0001823 | [0.0001037, 0.000367] | 0.006518 | 7.958e-13 | 0 |
| collapse_moderate_coupled | 6 | 1.5 | full size, common evaluation worlds | 0.000472 | [0.0002887, 0.0008026] | 0.005291 | 1.933e-12 | 0 |
| collapse_moderate_coupled | 6 | 3.5 | full size, common evaluation worlds | 0.0009781 | [0.0007133, 0.001488] | 0.01388 | 2.046e-12 | 0 |
| collapse_moderate_coupled | 6 | 8.0 | full size, common evaluation worlds | 5.013e-05 | [3.53e-05, 7.651e-05] | 0.002188 | 2.046e-12 | 0 |
| collapse_moderate_coupled | 6 | 20.0 | full size, common evaluation worlds | 2.001e-06 | [9.225e-07, 3.883e-06] | 0.0001658 | 1.933e-12 | 0 |

Label changes under the sequential reference: 0


## Penalty sweep (R11): tuned versus zero

| env / c | comparison | δ | p | label | reproduction ok |
|---|---|---|---|---|---|
| favorable_hmm_coupled|0.5 | tuned vs prop_scale=0 | +0.000 | 3.17e-01 | no detected difference | True |
| favorable_hmm_coupled|0.5 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| favorable_hmm_coupled|0.5 | tuned vs both=0 | +0.000 | 3.17e-01 | no detected difference | True |
| favorable_hmm_coupled|1.5 | tuned vs prop_scale=0 | -0.002 | 1.69e-01 | no detected difference | True |
| favorable_hmm_coupled|1.5 | tuned vs stab_scale=0 | -0.176 | 2.22e-03 | tuned lower-regret | True |
| favorable_hmm_coupled|1.5 | tuned vs both=0 | -0.176 | 2.22e-03 | tuned lower-regret | True |
| favorable_hmm_coupled|3.5 | tuned vs prop_scale=0 | +0.059 | 2.22e-03 | no detected difference | True |
| favorable_hmm_coupled|3.5 | tuned vs stab_scale=0 | +0.000 | 9.17e-01 | no detected difference | True |
| favorable_hmm_coupled|3.5 | tuned vs both=0 | +0.059 | 1.01e-03 | no detected difference | True |
| favorable_hmm_coupled|8.0 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| favorable_hmm_coupled|8.0 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| favorable_hmm_coupled|8.0 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |
| favorable_hmm_coupled|20.0 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| favorable_hmm_coupled|20.0 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| favorable_hmm_coupled|20.0 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|0.5 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|0.5 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|0.5 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|1.5 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|1.5 | tuned vs stab_scale=0 | +0.008 | 7.65e-03 | no detected difference | True |
| unfavorable_oscillation_uncoupled|1.5 | tuned vs both=0 | +0.008 | 7.65e-03 | no detected difference | True |
| unfavorable_oscillation_uncoupled|3.5 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|3.5 | tuned vs stab_scale=0 | +0.002 | 6.79e-02 | no detected difference | True |
| unfavorable_oscillation_uncoupled|3.5 | tuned vs both=0 | +0.002 | 6.79e-02 | no detected difference | True |
| unfavorable_oscillation_uncoupled|8.0 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|8.0 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|8.0 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|20.0 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|20.0 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| unfavorable_oscillation_uncoupled|20.0 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|0.5 | tuned vs prop_scale=0 | -0.027 | 2.72e-01 | no detected difference | True |
| collapse_moderate_coupled|0.5 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|0.5 | tuned vs both=0 | -0.027 | 2.72e-01 | no detected difference | True |
| collapse_moderate_coupled|1.5 | tuned vs prop_scale=0 | +0.047 | 2.81e-02 | no detected difference | True |
| collapse_moderate_coupled|1.5 | tuned vs stab_scale=0 | -0.000 | 3.17e-01 | no detected difference | True |
| collapse_moderate_coupled|1.5 | tuned vs both=0 | +0.047 | 2.81e-02 | no detected difference | True |
| collapse_moderate_coupled|3.5 | tuned vs prop_scale=0 | -0.164 | 1.15e-03 | tuned lower-regret | True |
| collapse_moderate_coupled|3.5 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|3.5 | tuned vs both=0 | -0.164 | 1.15e-03 | tuned lower-regret | True |
| collapse_moderate_coupled|8.0 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|8.0 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|8.0 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|20.0 | tuned vs prop_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|20.0 | tuned vs stab_scale=0 | +0.000 | 1.00e+00 | no detected difference | True |
| collapse_moderate_coupled|20.0 | tuned vs both=0 | +0.000 | 1.00e+00 | no detected difference | True |

## Decision cost (R6)

- N=1: static 4996 ns (×1.00); ewma 5966 ns (×1.19); rova 13074 ns (×2.62); A0 982 ns (×0.20); A5 980 ns (×0.20); learned 16530 ns (×3.31); qlearn 9944 ns (×1.99); static_ext 5902 ns (×1.18); ewma_ext 6875 ns (×1.38); clairvoyant 2529 ns (×0.51); rova_default 13168 ns (×2.64); _simulator_and_runner_static 39059 ns
- N=6: static 3665 ns (×1.00); ewma 3816 ns (×1.04); rova 11782 ns (×3.21); A0 164 ns (×0.04); A5 164 ns (×0.04); learned 2965 ns (×0.81); qlearn 1638 ns (×0.45); static_ext 3800 ns (×1.04); ewma_ext 3965 ns (×1.08); clairvoyant 1599 ns (×0.44); rova_default 11824 ns (×3.23); _simulator_and_runner_static 24963 ns
- N=10: static 3525 ns (×1.00); ewma 3633 ns (×1.03); rova 11627 ns (×3.30); A0 99 ns (×0.03); A5 98 ns (×0.03); learned 1840 ns (×0.52); qlearn 1004 ns (×0.28); static_ext 3614 ns (×1.03); ewma_ext 3723 ns (×1.06); clairvoyant 1517 ns (×0.43); rova_default 11634 ns (×3.30); _simulator_and_runner_static 23746 ns
- N=100: static 3311 ns (×1.00); ewma 3338 ns (×1.01); rova 11389 ns (×3.44); A0 10 ns (×0.00); A5 10 ns (×0.00); learned 314 ns (×0.09); qlearn 123 ns (×0.04); static_ext 3344 ns (×1.01); ewma_ext 3357 ns (×1.01); clairvoyant 1405 ns (×0.42); rova_default 11442 ns (×3.46)
- N=1000: static 3331 ns (×1.00); ewma 3310 ns (×0.99); rova 11326 ns (×3.40); A0 1 ns (×0.00); A5 1 ns (×0.00); learned 401 ns (×0.12); qlearn 33 ns (×0.01); static_ext 3270 ns (×0.98); ewma_ext 3296 ns (×0.99); clairvoyant 1384 ns (×0.42); rova_default 11374 ns (×3.41)

## Multiplicity

- S1 (Holm over 45 published tests): 2 pairwise label changes
- S2 (Holm over 405 CEW tests in F1–F7): 24 label changes

## Consistency checks

- gate_passed: True
- cew_misaligned_methods: {}
- archived_bca_matches_stats_summary: True
- archived_wilcoxon_p_recomputed_equal: True
- archived_pairs_reproduce_published_verdicts: True
- sweep_tuned_point_reproduces_archive: True
- tpe_startup_reproduces_archive: True
- dp_alignment_problems: {}
- dp_worlds_where_vertex_solution_differs_from_exhaustive: 0
- r5a_attacked_and_clean_worlds_match: True
- shift_worlds_matched: True
