# A1 tuning-convergence report

Auto-generated from unit results; lists results without interpretation. Plan: docs/REVISION_002_ANALYSIS_PLAN.md (specified after the REV-001 results).

Convergence criterion: fold converged iff B(160) - B(320) <= max(0.05 * B(160), 0.0002).

## Reproduction

- gate_passed: True
- r0_exact_zero: True
- campaign_checks_ok: True
- eval_checks_ok: True
- n_campaign_units: 45
- n_eval_units: 15
- failed: []

## Verdicts by budget and convergence status

| env | c | verdict@80 | verdict@160 | verdict@320 | static conv | ewma conv | rova conv | cell converged | G@final | G CI |
|---|---|---|---|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 0.5 | ROVA_loses | ROVA_loses | ROVA_loses | False | False | False | False | – | – |
| favorable_hmm_coupled | 1.5 | ROVA_loses | ROVA_loses | ROVA_loses | False | False | False | False | – | – |
| favorable_hmm_coupled | 3.5 | mixed | mixed | mixed | False | False | False | False | – | – |
| favorable_hmm_coupled | 8.0 | mixed | ROVA_loses | ROVA_loses | False | False | True | False | – | – |
| favorable_hmm_coupled | 20.0 | mixed | mixed | mixed | False | False | False | False | – | – |
| unfavorable_oscillation_uncoupled | 0.5 | mixed | mixed | mixed | False | False | True | False | – | – |
| unfavorable_oscillation_uncoupled | 1.5 | mixed | mixed | mixed | False | False | False | False | – | – |
| unfavorable_oscillation_uncoupled | 3.5 | ROVA_loses | ROVA_loses | ROVA_loses | False | False | False | False | – | – |
| unfavorable_oscillation_uncoupled | 8.0 | mixed | mixed | mixed | False | False | False | False | – | – |
| unfavorable_oscillation_uncoupled | 20.0 | mixed | mixed | mixed | False | False | False | False | – | – |
| collapse_moderate_coupled | 0.5 | ROVA_loses | ROVA_loses | ROVA_loses | False | False | False | False | – | – |
| collapse_moderate_coupled | 1.5 | ROVA_loses | ROVA_loses | mixed | True | False | False | False | – | – |
| collapse_moderate_coupled | 3.5 | ROVA_loses | ROVA_loses | ROVA_loses | False | False | False | False | – | – |
| collapse_moderate_coupled | 8.0 | ROVA_loses | ROVA_loses | ROVA_loses | False | False | False | False | – | – |
| collapse_moderate_coupled | 20.0 | mixed | mixed | mixed | False | False | False | False | – | – |

## Pairwise comparisons (within-family Holm; P = A1-family Holm)

| env | c | family | a | b | δ | p | mean diff [BCa] | label | P |
|---|---|---|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 0.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.962 | 1.6e-11 | 0.01438 [0.01172, 0.017] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.703 | 9.5e-10 | 0.01152 [0.008748, 0.01448] | ewma_tpe80 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.647 | 1.9e-07 | -0.002861 [-0.004256, -0.00193] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.576 | 1.1e-08 | 0.009753 [0.007609, 0.01188] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.467 | 2.2e-06 | 0.008914 [0.006823, 0.01105] | ewma_tpe160 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.286 | 1.1e-05 | -0.0008387 [-0.001326, -0.0005011] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.392 | 4.4e-06 | 0.005373 [0.004013, 0.006858] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.382 | 4.4e-06 | 0.00528 [0.0039, 0.006776] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.083 | 0.36 | -9.322e-05 [-0.0001676, -3.837e-05] | no detected difference | False |
| favorable_hmm_coupled | 0.5 | H2 | rova_tpe320 | A0 | -1.000 | 1.6e-11 | -0.4873 [-0.4948, -0.4789] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H2 | ewma_tpe320 | A0 | -1.000 | 1.6e-11 | -0.4926 [-0.4997, -0.4845] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.4927 [-0.4998, -0.4846] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H3 | rova_tpe320 | learned | +0.995 | 1.6e-11 | 0.006231 [0.004855, 0.007716] | learned lower-regret | True |
| favorable_hmm_coupled | 0.5 | H3 | rova_tpe320 | qlearn | +0.319 | 4.4e-06 | 0.00517 [0.003793, 0.006668] | qlearn lower-regret | True |
| favorable_hmm_coupled | 0.5 | H3 | ewma_tpe320 | learned | +0.999 | 1.6e-11 | 0.0009518 [0.000859, 0.001066] | learned lower-regret | True |
| favorable_hmm_coupled | 0.5 | H3 | ewma_tpe320 | qlearn | -0.172 | 0.013 | -0.0001094 [-0.0001901, -3.261e-05] | ewma_tpe320 lower-regret | False |
| favorable_hmm_coupled | 0.5 | H3 | static_tpe320 | learned | +1.000 | 1.6e-11 | 0.0008586 [0.0007916, 0.0009318] | learned lower-regret | True |
| favorable_hmm_coupled | 0.5 | H3 | static_tpe320 | qlearn | -0.289 | 4.1e-09 | -0.0002026 [-0.0002613, -0.0001545] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H4 | rova_tpe320 | rova_tpe80 | -0.537 | 1.6e-11 | -0.009596 [-0.0114, -0.007919] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.908 | 1.6e-11 | -0.003359 [-0.004675, -0.002462] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H4 | static_tpe320 | static_tpe80 | -0.505 | 3.8e-11 | -0.0005913 [-0.0007753, -0.0004421] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H5 | rova_tpe320 | rova | -0.998 | 1.6e-11 | -0.03181 [-0.03556, -0.02825] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -0.01859 [-0.02106, -0.01656] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 0.5 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.00851 [-0.01025, -0.006935] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.886 | 1.1e-10 | 0.01438 [0.01021, 0.02007] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.192 | 0.0034 | 0.00912 [0.004974, 0.01451] | ewma_tpe80 lower-regret | False |
| favorable_hmm_coupled | 1.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.589 | 8.4e-07 | -0.005258 [-0.006553, -0.003945] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.991 | 1.8e-11 | 0.009038 [0.00635, 0.01262] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.526 | 2.6e-08 | 0.007763 [0.005147, 0.01129] | ewma_tpe160 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.702 | 3.5e-09 | -0.001274 [-0.001578, -0.0009806] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.922 | 1.6e-11 | 0.0015 [0.001137, 0.002033] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.753 | 2e-09 | 0.001305 [0.0009149, 0.001855] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.337 | 0.00046 | -0.0001947 [-0.000307, -0.0001104] | static_tpe320 lower-regret | False |
| favorable_hmm_coupled | 1.5 | H2 | rova_tpe320 | A0 | -1.000 | 1.6e-11 | -0.2733 [-0.2825, -0.2638] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H2 | ewma_tpe320 | A0 | -1.000 | 1.6e-11 | -0.2746 [-0.2838, -0.2651] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.2748 [-0.284, -0.2653] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H3 | rova_tpe320 | learned | +1.000 | 1.6e-11 | 0.001863 [0.001498, 0.002397] | learned lower-regret | True |
| favorable_hmm_coupled | 1.5 | H3 | rova_tpe320 | qlearn | +0.377 | 0.2 | -0.0009621 [-0.002438, 0.0001958] | no detected difference | False |
| favorable_hmm_coupled | 1.5 | H3 | ewma_tpe320 | learned | +0.932 | 1.6e-11 | 0.0005576 [0.0004786, 0.0006609] | learned lower-regret | True |
| favorable_hmm_coupled | 1.5 | H3 | ewma_tpe320 | qlearn | -0.239 | 0.014 | -0.002268 [-0.003671, -0.001256] | ewma_tpe320 lower-regret | False |
| favorable_hmm_coupled | 1.5 | H3 | static_tpe320 | learned | +0.838 | 1.6e-11 | 0.0003629 [0.0003148, 0.0004221] | learned lower-regret | True |
| favorable_hmm_coupled | 1.5 | H3 | static_tpe320 | qlearn | -0.488 | 4.9e-08 | -0.002462 [-0.003865, -0.001476] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H4 | rova_tpe320 | rova_tpe80 | -0.903 | 1.6e-11 | -0.0149 [-0.01989, -0.01125] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.984 | 1.6e-11 | -0.007089 [-0.00832, -0.005898] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H4 | static_tpe320 | static_tpe80 | -0.968 | 1.6e-11 | -0.002025 [-0.002351, -0.001726] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H5 | rova_tpe320 | rova | -1.000 | 1.6e-11 | -0.07735 [-0.08179, -0.07284] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -0.0619 [-0.06851, -0.05543] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 1.5 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.02642 [-0.02823, -0.02462] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.994 | 1.6e-11 | 0.0329 [0.02733, 0.03905] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H1_80 | rova_tpe80 | ewma_tpe80 | -0.021 | 0.082 | -0.006667 [-0.01561, 0.004057] | no detected difference | False |
| favorable_hmm_coupled | 3.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.961 | 1.6e-11 | -0.03956 [-0.04842, -0.03152] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.961 | 1.6e-11 | 0.02816 [0.02252, 0.03456] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.118 | 0.26 | -0.005915 [-0.01665, 0.006182] | no detected difference | False |
| favorable_hmm_coupled | 3.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.868 | 3.1e-11 | -0.03407 [-0.0444, -0.02493] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.878 | 1.6e-11 | 0.02236 [0.01606, 0.02972] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.043 | 0.11 | -0.009837 [-0.02149, 0.003164] | no detected difference | False |
| favorable_hmm_coupled | 3.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.549 | 1.1e-07 | -0.0322 [-0.04297, -0.02264] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H2 | rova_tpe320 | A0 | -0.829 | 1.6e-11 | -0.05886 [-0.06683, -0.0515] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H2 | ewma_tpe320 | A0 | -0.635 | 5.7e-09 | -0.04902 [-0.0611, -0.03729] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.08122 [-0.0881, -0.07383] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H3 | rova_tpe320 | learned | +1.000 | 1.6e-11 | 0.0268 [0.02034, 0.03423] | learned lower-regret | True |
| favorable_hmm_coupled | 3.5 | H3 | rova_tpe320 | qlearn | +0.480 | 1e-06 | 0.01977 [0.01343, 0.02716] | qlearn lower-regret | True |
| favorable_hmm_coupled | 3.5 | H3 | ewma_tpe320 | learned | +0.999 | 1.6e-11 | 0.03663 [0.02713, 0.04738] | learned lower-regret | True |
| favorable_hmm_coupled | 3.5 | H3 | ewma_tpe320 | qlearn | +0.238 | 0.0011 | 0.02961 [0.0199, 0.04046] | qlearn lower-regret | False |
| favorable_hmm_coupled | 3.5 | H3 | static_tpe320 | learned | +1.000 | 1.6e-11 | 0.004433 [0.004084, 0.004804] | learned lower-regret | True |
| favorable_hmm_coupled | 3.5 | H3 | static_tpe320 | qlearn | -0.638 | 4.4e-09 | -0.002588 [-0.003273, -0.001986] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H4 | rova_tpe320 | rova_tpe80 | -0.444 | 1.6e-09 | -0.01377 [-0.01761, -0.01089] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.329 | 1.4e-07 | -0.0106 [-0.01439, -0.00759] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H4 | static_tpe320 | static_tpe80 | -0.783 | 1.6e-11 | -0.00324 [-0.003831, -0.002763] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H5 | rova_tpe320 | rova | -0.784 | 1.6e-11 | -0.04868 [-0.05423, -0.04348] | rova_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H5 | ewma_tpe320 | ewma | -0.870 | 1.6e-11 | -0.1142 [-0.1247, -0.1036] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 3.5 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.08903 [-0.1011, -0.07715] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H1_80 | rova_tpe80 | static_tpe80 | +0.586 | 4.4e-11 | 0.009876 [0.008094, 0.01197] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.141 | 0.067 | 0.002408 [0.0007757, 0.004915] | no detected difference | False |
| favorable_hmm_coupled | 8.0 | H1_80 | static_tpe80 | ewma_tpe80 | -0.460 | 3.2e-09 | -0.007468 [-0.009489, -0.005676] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H1_160 | rova_tpe160 | static_tpe160 | +0.702 | 1.2e-10 | 0.01138 [0.0093, 0.01381] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.192 | 0.012 | 0.00321 [0.001654, 0.005738] | ewma_tpe160 lower-regret | False |
| favorable_hmm_coupled | 8.0 | H1_160 | static_tpe160 | ewma_tpe160 | -0.481 | 7.2e-09 | -0.008167 [-0.01057, -0.006073] | static_tpe160 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H1_320 | rova_tpe320 | static_tpe320 | +0.721 | 4.4e-11 | 0.01181 [0.0098, 0.01418] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.224 | 0.0066 | 0.003723 [0.001987, 0.006429] | ewma_tpe320 lower-regret | False |
| favorable_hmm_coupled | 8.0 | H1_320 | static_tpe320 | ewma_tpe320 | -0.416 | 2.9e-05 | -0.008083 [-0.01055, -0.005891] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H2 | rova_tpe320 | A0 | -0.037 | 3e-05 | -0.0009566 [-0.001499, -0.0006067] | no detected difference | True |
| favorable_hmm_coupled | 8.0 | H2 | ewma_tpe320 | A0 | -0.248 | 1.2e-05 | -0.00468 [-0.007714, -0.002927] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H2 | static_tpe320 | A0 | -0.724 | 4.7e-11 | -0.01276 [-0.01545, -0.01058] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H3 | rova_tpe320 | learned | +0.838 | 2e-11 | 0.01473 [0.01248, 0.01733] | learned lower-regret | True |
| favorable_hmm_coupled | 8.0 | H3 | rova_tpe320 | qlearn | +0.487 | 1.9e-10 | 0.007848 [0.006284, 0.01008] | qlearn lower-regret | True |
| favorable_hmm_coupled | 8.0 | H3 | ewma_tpe320 | learned | +0.782 | 1.6e-11 | 0.011 [0.008735, 0.01362] | learned lower-regret | True |
| favorable_hmm_coupled | 8.0 | H3 | ewma_tpe320 | qlearn | +0.145 | 0.0025 | 0.004125 [0.002061, 0.006382] | no detected difference | False |
| favorable_hmm_coupled | 8.0 | H3 | static_tpe320 | learned | +0.742 | 1.6e-11 | 0.002919 [0.002591, 0.003277] | learned lower-regret | True |
| favorable_hmm_coupled | 8.0 | H3 | static_tpe320 | qlearn | -0.538 | 1.1e-10 | -0.003958 [-0.005069, -0.003111] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H4 | rova_tpe320 | rova_tpe80 | -0.022 | 0.0029 | -0.0005857 [-0.00107, -0.0002919] | no detected difference | False |
| favorable_hmm_coupled | 8.0 | H4 | ewma_tpe320 | ewma_tpe80 | -0.137 | 1.6e-06 | -0.001901 [-0.002719, -0.001201] | no detected difference | True |
| favorable_hmm_coupled | 8.0 | H4 | static_tpe320 | static_tpe80 | -0.382 | 2.2e-10 | -0.002515 [-0.003228, -0.001991] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H5 | rova_tpe320 | rova | -0.022 | 0.0029 | -0.0005857 [-0.00107, -0.0002919] | no detected difference | False |
| favorable_hmm_coupled | 8.0 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -0.4189 [-0.4485, -0.3853] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 8.0 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.3788 [-0.421, -0.3427] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 20.0 | H1_80 | rova_tpe80 | static_tpe80 | -0.001 | 0.054 | 0.0001956 [-1.286e-06, 0.0003991] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H1_80 | rova_tpe80 | ewma_tpe80 | -0.154 | 0.00033 | -0.001573 [-0.002617, -0.0008776] | rova_tpe80 lower-regret | True |
| favorable_hmm_coupled | 20.0 | H1_80 | static_tpe80 | ewma_tpe80 | -0.158 | 1.6e-05 | -0.001768 [-0.002849, -0.001055] | static_tpe80 lower-regret | True |
| favorable_hmm_coupled | 20.0 | H1_160 | rova_tpe160 | static_tpe160 | +0.040 | 0.00084 | 0.0003803 [0.0001825, 0.0006525] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H1_160 | rova_tpe160 | ewma_tpe160 | -0.017 | 0.012 | -9.897e-05 [-0.0002603, -3.041e-05] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H1_160 | static_tpe160 | ewma_tpe160 | -0.049 | 0.00041 | -0.0004793 [-0.000813, -0.000253] | no detected difference | True |
| favorable_hmm_coupled | 20.0 | H1_320 | rova_tpe320 | static_tpe320 | +0.076 | 9.5e-07 | 0.0005473 [0.0003802, 0.0007915] | no detected difference | True |
| favorable_hmm_coupled | 20.0 | H1_320 | rova_tpe320 | ewma_tpe320 | -0.009 | 0.5 | -4.004e-05 [-0.0002057, 3.944e-06] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H1_320 | static_tpe320 | ewma_tpe320 | -0.081 | 9.5e-07 | -0.0005873 [-0.0008274, -0.0004046] | no detected difference | True |
| favorable_hmm_coupled | 20.0 | H2 | rova_tpe320 | A0 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H2 | ewma_tpe320 | A0 | +0.009 | 0.5 | 4.004e-05 [-3.944e-06, 0.0002055] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H2 | static_tpe320 | A0 | -0.076 | 9.5e-07 | -0.0005473 [-0.0007915, -0.0003802] | no detected difference | True |
| favorable_hmm_coupled | 20.0 | H3 | rova_tpe320 | learned | +0.175 | 4.9e-08 | 0.001004 [0.0007348, 0.001457] | learned lower-regret | True |
| favorable_hmm_coupled | 20.0 | H3 | rova_tpe320 | qlearn | -0.182 | 0.0015 | -0.002384 [-0.004249, -0.001264] | rova_tpe320 lower-regret | False |
| favorable_hmm_coupled | 20.0 | H3 | ewma_tpe320 | learned | +0.176 | 4.9e-08 | 0.001044 [0.0007639, 0.001474] | learned lower-regret | True |
| favorable_hmm_coupled | 20.0 | H3 | ewma_tpe320 | qlearn | -0.176 | 0.0012 | -0.002344 [-0.004194, -0.001223] | ewma_tpe320 lower-regret | False |
| favorable_hmm_coupled | 20.0 | H3 | static_tpe320 | learned | +0.128 | 5.2e-05 | 0.0004569 [0.0002728, 0.0006967] | no detected difference | True |
| favorable_hmm_coupled | 20.0 | H3 | static_tpe320 | qlearn | -0.242 | 1.4e-07 | -0.002932 [-0.004762, -0.001802] | static_tpe320 lower-regret | True |
| favorable_hmm_coupled | 20.0 | H4 | rova_tpe320 | rova_tpe80 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H4 | ewma_tpe320 | ewma_tpe80 | -0.147 | 0.00083 | -0.001533 [-0.002591, -0.0008444] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H4 | static_tpe320 | static_tpe80 | -0.087 | 1.2e-05 | -0.0003517 [-0.0005085, -0.0002156] | no detected difference | True |
| favorable_hmm_coupled | 20.0 | H5 | rova_tpe320 | rova | -0.052 | 0.0015 | -0.000199 [-0.0003766, -0.000103] | no detected difference | False |
| favorable_hmm_coupled | 20.0 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -1.259 [-1.329, -1.178] | ewma_tpe320 lower-regret | True |
| favorable_hmm_coupled | 20.0 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -1.269 [-1.374, -1.168] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.125 | 5.9e-07 | 0.0003467 [0.0002364, 0.0004889] | no detected difference | True |
| unfavorable_oscillation_uncoupled | 0.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.021 | 0.051 | 6.678e-05 [2.08e-05, 0.0001658] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 0.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.104 | 8.3e-06 | -0.0002799 [-0.0004199, -0.0001789] | no detected difference | True |
| unfavorable_oscillation_uncoupled | 0.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.168 | 9.6e-07 | 0.0003933 [0.0002657, 0.0005494] | static_tpe160 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H1_160 | rova_tpe160 | ewma_tpe160 | -0.003 | 0.79 | 4.67e-06 [-4.452e-05, 6.672e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 0.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.169 | 8.8e-07 | -0.0003886 [-0.0005562, -0.000265] | static_tpe160 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.254 | 3.5e-07 | 0.0004787 [0.0003374, 0.000689] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.001 | 0.62 | -1.495e-05 [-9.379e-05, 6.31e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 0.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.250 | 2.8e-07 | -0.0004936 [-0.0006945, -0.0003484] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H2 | rova_tpe320 | A0 | -1.000 | 1.6e-11 | -0.4275 [-0.4387, -0.4163] | rova_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H2 | ewma_tpe320 | A0 | -1.000 | 1.6e-11 | -0.4275 [-0.4387, -0.4163] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.428 [-0.4391, -0.4169] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | rova_tpe320 | learned | +0.389 | 1.6e-08 | 0.0005977 [0.0004433, 0.0008051] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | rova_tpe320 | qlearn | +0.098 | 4.5e-05 | 0.0002497 [0.0001478, 0.000429] | no detected difference | True |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | ewma_tpe320 | learned | +0.385 | 1.7e-08 | 0.0006126 [0.0004507, 0.000821] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | ewma_tpe320 | qlearn | +0.092 | 8.3e-05 | 0.0002647 [0.0001533, 0.0004416] | no detected difference | True |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | static_tpe320 | learned | +0.203 | 1.6e-05 | 0.000119 [7.376e-05, 0.0001751] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | static_tpe320 | qlearn | -0.193 | 0.00042 | -0.0002289 [-0.0003496, -0.0001351] | static_tpe320 lower-regret | False |
| unfavorable_oscillation_uncoupled | 0.5 | H4 | rova_tpe320 | rova_tpe80 | -0.027 | 0.0044 | -8.288e-05 [-0.000157, -4.122e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 0.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.003 | 0.74 | -1.154e-06 [-8.59e-06, 8.728e-06] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 0.5 | H4 | static_tpe320 | static_tpe80 | -0.193 | 2.9e-06 | -0.0002148 [-0.0003182, -0.0001422] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H5 | rova_tpe320 | rova | -0.231 | 4.6e-05 | -0.009002 [-0.01541, -0.004409] | rova_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 0.5 | H5 | ewma_tpe320 | ewma | -0.024 | 0.025 | -5.922e-05 [-0.0001434, -1.989e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 0.5 | H5 | static_tpe320 | static | -0.616 | 1.8e-10 | -0.00306 [-0.003933, -0.002236] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H1_80 | rova_tpe80 | static_tpe80 | +1.000 | 1.6e-11 | 0.03666 [0.02905, 0.04664] | static_tpe80 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H1_80 | rova_tpe80 | ewma_tpe80 | -0.106 | 0.21 | -0.007194 [-0.02091, 0.008819] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 1.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.945 | 1.6e-11 | -0.04385 [-0.0546, -0.0349] | static_tpe80 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.958 | 1.6e-11 | 0.01844 [0.01238, 0.02733] | static_tpe160 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.019 | 0.25 | -0.01121 [-0.02684, 0.002683] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 1.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.772 | 3.6e-10 | -0.02964 [-0.0434, -0.02036] | static_tpe160 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.720 | 1.8e-10 | 0.008459 [0.005314, 0.01292] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.037 | 0.43 | -0.01506 [-0.03019, -0.0045] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 1.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.556 | 2.3e-09 | -0.02352 [-0.03775, -0.01465] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H2 | rova_tpe320 | A0 | -1.000 | 1.6e-11 | -0.2015 [-0.2196, -0.1849] | rova_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H2 | ewma_tpe320 | A0 | -0.957 | 2.6e-11 | -0.1864 [-0.2074, -0.1642] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.21 [-0.2278, -0.1938] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | rova_tpe320 | learned | +0.802 | 5.4e-11 | 0.008783 [0.005596, 0.01325] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | rova_tpe320 | qlearn | +0.057 | 0.77 | 0.003996 [0.0004095, 0.008422] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | ewma_tpe320 | learned | +0.667 | 1.7e-10 | 0.02384 [0.01493, 0.03813] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | ewma_tpe320 | qlearn | +0.074 | 0.0029 | 0.01905 [0.01068, 0.03282] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | static_tpe320 | learned | +0.191 | 0.0025 | 0.0003244 [0.0001472, 0.0005116] | learned lower-regret | False |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | static_tpe320 | qlearn | -0.593 | 8.2e-09 | -0.004462 [-0.006201, -0.00312] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H4 | rova_tpe320 | rova_tpe80 | -0.757 | 1.6e-11 | -0.02849 [-0.03454, -0.0236] | rova_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.506 | 7e-07 | -0.02063 [-0.02722, -0.01428] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H4 | static_tpe320 | static_tpe80 | -0.174 | 0.00046 | -0.0002959 [-0.0004506, -0.0001575] | static_tpe320 lower-regret | False |
| unfavorable_oscillation_uncoupled | 1.5 | H5 | rova_tpe320 | rova | -0.985 | 1.6e-11 | -0.078 [-0.08546, -0.06973] | rova_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H5 | ewma_tpe320 | ewma | -0.729 | 4.5e-06 | -0.04304 [-0.05497, -0.02653] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 1.5 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.02957 [-0.03249, -0.02672] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.225 | 6.6e-05 | 0.03941 [0.02537, 0.05546] | static_tpe80 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.171 | 8.2e-05 | 0.02786 [0.01741, 0.04216] | ewma_tpe80 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.044 | 0.16 | -0.01155 [-0.0259, -0.003903] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 3.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.267 | 9.3e-05 | 0.03954 [0.02537, 0.05556] | static_tpe160 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.218 | 0.0053 | 0.02797 [0.01588, 0.04324] | ewma_tpe160 lower-regret | False |
| unfavorable_oscillation_uncoupled | 3.5 | H1_160 | static_tpe160 | ewma_tpe160 | +0.001 | 0.4 | -0.01156 [-0.02862, -0.002432] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 3.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.293 | 1.5e-05 | 0.04086 [0.02706, 0.05644] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.244 | 0.0015 | 0.02893 [0.01704, 0.04365] | ewma_tpe320 lower-regret | False |
| unfavorable_oscillation_uncoupled | 3.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.014 | 0.6 | -0.01193 [-0.02849, -0.003055] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 3.5 | H2 | rova_tpe320 | A0 | -0.002 | 0.06 | -0.002397 [-0.005561, -0.0007051] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 3.5 | H2 | ewma_tpe320 | A0 | -0.247 | 3.3e-05 | -0.03133 [-0.04578, -0.02024] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H2 | static_tpe320 | A0 | -0.296 | 1.2e-05 | -0.04326 [-0.06045, -0.02846] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | rova_tpe320 | learned | +0.497 | 7.9e-09 | 0.04581 [0.03226, 0.06164] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | rova_tpe320 | qlearn | +0.192 | 8.2e-06 | 0.03284 [0.02215, 0.04609] | qlearn lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | ewma_tpe320 | learned | +0.621 | 5.3e-09 | 0.01688 [0.007921, 0.0334] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | ewma_tpe320 | qlearn | -0.217 | 0.013 | 0.003913 [-0.002498, 0.01581] | ewma_tpe320 lower-regret | False |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | static_tpe320 | learned | +0.744 | 4.3e-10 | 0.00495 [0.003988, 0.005914] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | static_tpe320 | qlearn | -0.272 | 0.0001 | -0.008022 [-0.0127, -0.004542] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H4 | rova_tpe320 | rova_tpe80 | -0.002 | 0.21 | -0.002276 [-0.005372, -0.0005526] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 3.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.261 | 3.6e-05 | -0.003341 [-0.004742, -0.002046] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H4 | static_tpe320 | static_tpe80 | -0.301 | 3.2e-06 | -0.00373 [-0.005626, -0.002312] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H5 | rova_tpe320 | rova | -0.091 | 1.2e-07 | -0.007654 [-0.01148, -0.004878] | no detected difference | True |
| unfavorable_oscillation_uncoupled | 3.5 | H5 | ewma_tpe320 | ewma | -0.920 | 1.6e-11 | -0.1417 [-0.1579, -0.1241] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 3.5 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.1017 [-0.1193, -0.0861] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 8.0 | H1_80 | rova_tpe80 | static_tpe80 | -0.254 | 0.49 | 0.002377 [-9.336e-05, 0.006146] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.004 | 0.075 | 0.0002187 [3.328e-05, 0.0009695] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_80 | static_tpe80 | ewma_tpe80 | +0.262 | 0.48 | -0.002158 [-0.005769, 0.0002598] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_160 | rova_tpe160 | static_tpe160 | -0.098 | 0.07 | 0.003702 [0.001711, 0.006965] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_160 | rova_tpe160 | ewma_tpe160 | -0.013 | 0.24 | 2.425e-07 [-0.0002015, 0.0004668] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_160 | static_tpe160 | ewma_tpe160 | +0.081 | 0.043 | -0.003702 [-0.007016, -0.001714] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_320 | rova_tpe320 | static_tpe320 | -0.120 | 0.23 | 0.004343 [0.001888, 0.008228] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_320 | rova_tpe320 | ewma_tpe320 | -0.012 | 0.48 | 6.787e-05 [-8.631e-05, 0.0005882] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H1_320 | static_tpe320 | ewma_tpe320 | +0.104 | 0.14 | -0.004275 [-0.008087, -0.00186] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H2 | rova_tpe320 | A0 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H2 | ewma_tpe320 | A0 | +0.012 | 0.48 | -6.787e-05 [-0.0005883, 8.631e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H2 | static_tpe320 | A0 | +0.120 | 0.23 | -0.004343 [-0.008228, -0.001888] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | rova_tpe320 | learned | +0.051 | 0.00084 | 0.006899 [0.003655, 0.01218] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | rova_tpe320 | qlearn | -0.019 | 0.043 | -0.0007908 [-0.001814, -0.0002389] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | ewma_tpe320 | learned | +0.066 | 0.00039 | 0.006831 [0.003624, 0.01201] | no detected difference | True |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | ewma_tpe320 | qlearn | -0.007 | 0.12 | -0.0008587 [-0.00185, -0.0002733] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | static_tpe320 | learned | +0.173 | 1.8e-05 | 0.002556 [0.001441, 0.004342] | learned lower-regret | True |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | static_tpe320 | qlearn | +0.099 | 0.16 | -0.005134 [-0.009435, -0.002374] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H4 | rova_tpe320 | rova_tpe80 | -0.003 | 0.11 | -0.0001211 [-0.0004076, -2.371e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H4 | ewma_tpe320 | ewma_tpe80 | +0.013 | 0.4 | 2.966e-05 [-7.122e-05, 0.0001203] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H4 | static_tpe320 | static_tpe80 | -0.197 | 3e-05 | -0.002088 [-0.003285, -0.001052] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 8.0 | H5 | rova_tpe320 | rova | -0.031 | 0.012 | -0.0006133 [-0.00127, -0.0002617] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 8.0 | H5 | ewma_tpe320 | ewma | -0.999 | 1.6e-11 | -0.4069 [-0.4529, -0.3604] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 8.0 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.3795 [-0.4295, -0.3358] | static_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 20.0 | H1_80 | rova_tpe80 | static_tpe80 | -0.014 | 0.21 | 0.000317 [-0.0001108, 0.0008717] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_80 | rova_tpe80 | ewma_tpe80 | -0.000 | 0.32 | -0.0001254 [-0.0007521, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_80 | static_tpe80 | ewma_tpe80 | +0.014 | 0.21 | -0.0004423 [-0.001407, 2.155e-05] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_160 | rova_tpe160 | static_tpe160 | -0.084 | 0.64 | -6.255e-05 [-0.0004962, 0.0003858] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_160 | static_tpe160 | ewma_tpe160 | +0.084 | 0.64 | 6.255e-05 [-0.0003858, 0.0004962] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_320 | rova_tpe320 | static_tpe320 | -0.024 | 0.27 | 0.0002586 [-0.0001203, 0.0007596] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H1_320 | static_tpe320 | ewma_tpe320 | +0.024 | 0.27 | -0.0002586 [-0.0007596, 0.0001203] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H2 | rova_tpe320 | A0 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H2 | ewma_tpe320 | A0 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H2 | static_tpe320 | A0 | +0.024 | 0.27 | -0.0002586 [-0.0007596, 0.0001203] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | rova_tpe320 | learned | -0.001 | 0.65 | 2.282e-05 [-9.325e-05, 0.0001845] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | rova_tpe320 | qlearn | -0.041 | 0.18 | -0.00105 [-0.00509, -0.0002617] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | ewma_tpe320 | learned | -0.001 | 0.65 | 2.282e-05 [-9.325e-05, 0.0001845] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | ewma_tpe320 | qlearn | -0.041 | 0.18 | -0.00105 [-0.00509, -0.0002617] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | static_tpe320 | learned | +0.023 | 0.29 | -0.0002357 [-0.0007349, 0.0001637] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | static_tpe320 | qlearn | -0.019 | 0.091 | -0.001309 [-0.004575, -0.0002999] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H4 | rova_tpe320 | rova_tpe80 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H4 | ewma_tpe320 | ewma_tpe80 | -0.000 | 0.32 | -0.0001254 [-0.0007521, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H4 | static_tpe320 | static_tpe80 | +0.009 | 0.52 | 5.843e-05 [-0.0001496, 0.0002612] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H5 | rova_tpe320 | rova | -0.002 | 0.29 | -2.478e-05 [-0.0001472, 0] | no detected difference | False |
| unfavorable_oscillation_uncoupled | 20.0 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -1.169 [-1.285, -1.048] | ewma_tpe320 lower-regret | True |
| unfavorable_oscillation_uncoupled | 20.0 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -1.235 [-1.368, -1.115] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.659 | 5.2e-10 | 0.001252 [0.0009492, 0.001622] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.229 | 0.0017 | 0.0004532 [0.0001369, 0.0007434] | ewma_tpe80 lower-regret | False |
| collapse_moderate_coupled | 0.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.389 | 1.5e-09 | -0.0007989 [-0.001046, -0.0006014] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.713 | 6.9e-10 | 0.001287 [0.001011, 0.001653] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.612 | 2e-09 | 0.001143 [0.0008782, 0.001504] | ewma_tpe160 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.110 | 0.0092 | -0.0001435 [-0.0002824, 2.399e-05] | no detected difference | False |
| collapse_moderate_coupled | 0.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.564 | 2.9e-07 | 0.0009275 [0.0006252, 0.001249] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.636 | 1.3e-08 | 0.001041 [0.0007588, 0.001346] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H1_320 | static_tpe320 | ewma_tpe320 | +0.113 | 0.00011 | 0.0001137 [6.463e-05, 0.0001678] | no detected difference | True |
| collapse_moderate_coupled | 0.5 | H2 | rova_tpe320 | A0 | -1.000 | 1.6e-11 | -0.3801 [-0.3924, -0.3684] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H2 | ewma_tpe320 | A0 | -1.000 | 1.6e-11 | -0.3811 [-0.3935, -0.3695] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.381 [-0.3934, -0.3694] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H3 | rova_tpe320 | learned | +0.897 | 1.6e-11 | 0.001485 [0.00126, 0.001799] | learned lower-regret | True |
| collapse_moderate_coupled | 0.5 | H3 | rova_tpe320 | qlearn | -0.146 | 0.12 | -0.001888 [-0.003319, -0.0009127] | no detected difference | False |
| collapse_moderate_coupled | 0.5 | H3 | ewma_tpe320 | learned | +0.504 | 3.8e-11 | 0.0004438 [0.0003501, 0.000634] | learned lower-regret | True |
| collapse_moderate_coupled | 0.5 | H3 | ewma_tpe320 | qlearn | -0.646 | 5.4e-10 | -0.002929 [-0.004229, -0.002003] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H3 | static_tpe320 | learned | +0.614 | 2e-11 | 0.0005575 [0.0004424, 0.0007545] | learned lower-regret | True |
| collapse_moderate_coupled | 0.5 | H3 | static_tpe320 | qlearn | -0.576 | 2.2e-08 | -0.002815 [-0.004108, -0.001896] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H4 | rova_tpe320 | rova_tpe80 | -0.281 | 1.8e-05 | -0.0005394 [-0.0008359, -0.0002634] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.579 | 1.1e-10 | -0.001127 [-0.001436, -0.0008849] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H4 | static_tpe320 | static_tpe80 | -0.113 | 0.0011 | -0.0002148 [-0.0003752, -6.419e-05] | no detected difference | False |
| collapse_moderate_coupled | 0.5 | H5 | rova_tpe320 | rova | -0.962 | 1.6e-11 | -0.01358 [-0.01636, -0.01111] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H5 | ewma_tpe320 | ewma | -0.994 | 1.6e-11 | -0.01252 [-0.01449, -0.01085] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 0.5 | H5 | static_tpe320 | static | -0.970 | 2.2e-11 | -0.007655 [-0.009098, -0.00644] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.967 | 1.6e-11 | 0.003815 [0.003218, 0.004595] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.592 | 1e-08 | 0.002474 [0.001791, 0.003325] | ewma_tpe80 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.780 | 4e-11 | -0.001341 [-0.001673, -0.001081] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.747 | 1.6e-11 | 0.001223 [0.0009617, 0.00164] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.426 | 0.00025 | 0.0007471 [0.0004237, 0.001181] | ewma_tpe160 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.442 | 1.1e-09 | -0.0004762 [-0.00072, -0.0003337] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.328 | 1.4e-10 | 0.0002276 [0.0001735, 0.0003206] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.147 | 0.059 | 7.55e-05 [-1.44e-05, 0.0001696] | no detected difference | False |
| collapse_moderate_coupled | 1.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.195 | 4.4e-06 | -0.0001521 [-0.0002542, -9.407e-05] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H2 | rova_tpe320 | A0 | -1.000 | 1.6e-11 | -0.265 [-0.2753, -0.2543] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H2 | ewma_tpe320 | A0 | -1.000 | 1.6e-11 | -0.2651 [-0.2753, -0.2544] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.2653 [-0.2755, -0.2545] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H3 | rova_tpe320 | learned | +0.463 | 9.8e-10 | 0.0002995 [0.0002312, 0.0004029] | learned lower-regret | True |
| collapse_moderate_coupled | 1.5 | H3 | rova_tpe320 | qlearn | -0.768 | 4e-11 | -0.008838 [-0.01283, -0.006149] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H3 | ewma_tpe320 | learned | +0.346 | 8.4e-08 | 0.000224 [0.0001603, 0.0003192] | learned lower-regret | True |
| collapse_moderate_coupled | 1.5 | H3 | ewma_tpe320 | qlearn | -0.817 | 9.3e-11 | -0.008913 [-0.01294, -0.006167] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H3 | static_tpe320 | learned | +0.182 | 3.9e-05 | 7.19e-05 [4.096e-05, 0.0001065] | learned lower-regret | True |
| collapse_moderate_coupled | 1.5 | H3 | static_tpe320 | qlearn | -0.866 | 2.1e-11 | -0.009065 [-0.01308, -0.006326] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H4 | rova_tpe320 | rova_tpe80 | -0.946 | 1.6e-11 | -0.003705 [-0.004448, -0.003122] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.761 | 2e-11 | -0.001306 [-0.001627, -0.00107] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H4 | static_tpe320 | static_tpe80 | -0.198 | 1.5e-09 | -0.0001172 [-0.0001762, -8.387e-05] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H5 | rova_tpe320 | rova | -1.000 | 1.6e-11 | -0.0282 [-0.03304, -0.02416] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H5 | ewma_tpe320 | ewma | -0.999 | 1.6e-11 | -0.04254 [-0.05155, -0.03426] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 1.5 | H5 | static_tpe320 | static | -0.999 | 1.6e-11 | -0.01071 [-0.01262, -0.008994] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_80 | rova_tpe80 | static_tpe80 | +0.939 | 1.6e-11 | 0.03622 [0.03032, 0.04396] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.779 | 1e-08 | 0.02932 [0.02175, 0.03811] | ewma_tpe80 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_80 | static_tpe80 | ewma_tpe80 | -0.486 | 3e-07 | -0.006902 [-0.009558, -0.004661] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_160 | rova_tpe160 | static_tpe160 | +0.816 | 1.6e-11 | 0.02256 [0.01697, 0.02956] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.701 | 7.9e-10 | 0.02102 [0.01534, 0.02825] | ewma_tpe160 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_160 | static_tpe160 | ewma_tpe160 | -0.287 | 2.3e-09 | -0.001534 [-0.002055, -0.001147] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_320 | rova_tpe320 | static_tpe320 | +0.633 | 1.9e-10 | 0.02099 [0.01494, 0.02879] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.627 | 2.6e-10 | 0.02089 [0.01479, 0.0287] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H1_320 | static_tpe320 | ewma_tpe320 | -0.015 | 0.37 | -0.0001076 [-0.0003033, 7.504e-05] | no detected difference | False |
| collapse_moderate_coupled | 3.5 | H2 | rova_tpe320 | A0 | -0.846 | 2e-11 | -0.07029 [-0.08337, -0.05994] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H2 | ewma_tpe320 | A0 | -1.000 | 1.6e-11 | -0.09117 [-0.1043, -0.08066] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H2 | static_tpe320 | A0 | -1.000 | 1.6e-11 | -0.09128 [-0.1044, -0.08078] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H3 | rova_tpe320 | learned | +0.951 | 1.6e-11 | 0.02425 [0.01815, 0.03207] | learned lower-regret | True |
| collapse_moderate_coupled | 3.5 | H3 | rova_tpe320 | qlearn | +0.074 | 0.61 | 0.004852 [-0.002527, 0.01465] | no detected difference | False |
| collapse_moderate_coupled | 3.5 | H3 | ewma_tpe320 | learned | +0.789 | 1.6e-11 | 0.003362 [0.002865, 0.003994] | learned lower-regret | True |
| collapse_moderate_coupled | 3.5 | H3 | ewma_tpe320 | qlearn | -0.572 | 5.1e-09 | -0.01603 [-0.02268, -0.01081] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H3 | static_tpe320 | learned | +0.791 | 1.6e-11 | 0.003254 [0.00279, 0.003803] | learned lower-regret | True |
| collapse_moderate_coupled | 3.5 | H3 | static_tpe320 | qlearn | -0.585 | 2.7e-09 | -0.01614 [-0.02279, -0.01092] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H4 | rova_tpe320 | rova_tpe80 | -0.469 | 1e-10 | -0.01887 [-0.02244, -0.01552] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H4 | ewma_tpe320 | ewma_tpe80 | -0.775 | 2.4e-11 | -0.01044 [-0.0127, -0.008549] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H4 | static_tpe320 | static_tpe80 | -0.463 | 1.8e-11 | -0.003645 [-0.004675, -0.002866] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H5 | rova_tpe320 | rova | -0.695 | 1.9e-10 | -0.03552 [-0.04234, -0.02898] | rova_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -0.08584 [-0.09872, -0.07569] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 3.5 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.04455 [-0.05071, -0.03921] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_80 | rova_tpe80 | static_tpe80 | +0.434 | 2.4e-10 | 0.01573 [0.01224, 0.02019] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_80 | rova_tpe80 | ewma_tpe80 | +0.342 | 6.5e-10 | 0.01237 [0.009318, 0.0162] | ewma_tpe80 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_80 | static_tpe80 | ewma_tpe80 | -0.174 | 6.8e-09 | -0.00336 [-0.004624, -0.002472] | static_tpe80 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_160 | rova_tpe160 | static_tpe160 | +0.522 | 4.2e-09 | 0.01811 [0.01381, 0.02319] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_160 | rova_tpe160 | ewma_tpe160 | +0.404 | 4.3e-09 | 0.0146 [0.01107, 0.01904] | ewma_tpe160 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_160 | static_tpe160 | ewma_tpe160 | -0.272 | 1.5e-05 | -0.003507 [-0.005087, -0.002209] | static_tpe160 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_320 | rova_tpe320 | static_tpe320 | +0.542 | 2.4e-09 | 0.01858 [0.0143, 0.02361] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.494 | 3.7e-09 | 0.01706 [0.01301, 0.02188] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H1_320 | static_tpe320 | ewma_tpe320 | -0.132 | 0.0043 | -0.001525 [-0.002436, -0.0007661] | no detected difference | False |
| collapse_moderate_coupled | 8.0 | H2 | rova_tpe320 | A0 | -0.012 | 0.0051 | -0.0003248 [-0.0008591, -0.000114] | no detected difference | False |
| collapse_moderate_coupled | 8.0 | H2 | ewma_tpe320 | A0 | -0.498 | 3.7e-09 | -0.01738 [-0.02226, -0.0132] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H2 | static_tpe320 | A0 | -0.543 | 2.4e-09 | -0.01891 [-0.02407, -0.01455] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H3 | rova_tpe320 | learned | +0.739 | 6e-11 | 0.02354 [0.01901, 0.02878] | learned lower-regret | True |
| collapse_moderate_coupled | 8.0 | H3 | rova_tpe320 | qlearn | +0.314 | 1.7e-07 | 0.01127 [0.008025, 0.01506] | qlearn lower-regret | True |
| collapse_moderate_coupled | 8.0 | H3 | ewma_tpe320 | learned | +0.670 | 2.6e-11 | 0.006482 [0.005435, 0.007732] | learned lower-regret | True |
| collapse_moderate_coupled | 8.0 | H3 | ewma_tpe320 | qlearn | -0.315 | 3.2e-06 | -0.005789 [-0.008345, -0.003879] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H3 | static_tpe320 | learned | +0.607 | 2.3e-11 | 0.004957 [0.004217, 0.005812] | learned lower-regret | True |
| collapse_moderate_coupled | 8.0 | H3 | static_tpe320 | qlearn | -0.401 | 6.9e-09 | -0.007314 [-0.01004, -0.005413] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H4 | rova_tpe320 | rova_tpe80 | -0.012 | 0.0051 | -0.0003248 [-0.0008591, -0.000114] | no detected difference | False |
| collapse_moderate_coupled | 8.0 | H4 | ewma_tpe320 | ewma_tpe80 | -0.272 | 2.9e-06 | -0.005014 [-0.007037, -0.003489] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H4 | static_tpe320 | static_tpe80 | -0.263 | 5.4e-06 | -0.003179 [-0.004483, -0.002104] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H5 | rova_tpe320 | rova | +0.001 | 0.66 | 7.065e-05 [-0.000566, 0.0006608] | no detected difference | False |
| collapse_moderate_coupled | 8.0 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -0.3264 [-0.3584, -0.298] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 8.0 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.2494 [-0.277, -0.2237] | static_tpe320 lower-regret | True |
| collapse_moderate_coupled | 20.0 | H1_80 | rova_tpe80 | static_tpe80 | -0.019 | 0.094 | 0.001027 [0.0003082, 0.002068] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_80 | rova_tpe80 | ewma_tpe80 | -0.006 | 0.65 | -8.673e-05 [-0.0004317, 8.022e-05] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_80 | static_tpe80 | ewma_tpe80 | +0.005 | 0.071 | -0.001114 [-0.002143, -0.0004112] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_160 | rova_tpe160 | static_tpe160 | +0.044 | 0.00054 | 0.001222 [0.0006841, 0.002047] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_160 | rova_tpe160 | ewma_tpe160 | -0.001 | 0.48 | 5.068e-05 [-0.0001454, 0.0002421] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_160 | static_tpe160 | ewma_tpe160 | -0.049 | 0.00015 | -0.001171 [-0.002026, -0.0006643] | no detected difference | True |
| collapse_moderate_coupled | 20.0 | H1_320 | rova_tpe320 | static_tpe320 | +0.035 | 0.002 | 0.0009913 [0.0005262, 0.001673] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_320 | rova_tpe320 | ewma_tpe320 | +0.005 | 0.42 | 0.0001796 [-6.169e-06, 0.0005942] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H1_320 | static_tpe320 | ewma_tpe320 | -0.022 | 0.013 | -0.0008117 [-0.001535, -0.0003882] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H2 | rova_tpe320 | A0 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H2 | ewma_tpe320 | A0 | -0.005 | 0.42 | -0.0001796 [-0.0005942, 6.169e-06] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H2 | static_tpe320 | A0 | -0.035 | 0.002 | -0.0009913 [-0.001673, -0.0005262] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H3 | rova_tpe320 | learned | +0.135 | 9.9e-07 | 0.002114 [0.001428, 0.002999] | no detected difference | True |
| collapse_moderate_coupled | 20.0 | H3 | rova_tpe320 | qlearn | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H3 | ewma_tpe320 | learned | +0.133 | 6.8e-07 | 0.001934 [0.001309, 0.002792] | no detected difference | True |
| collapse_moderate_coupled | 20.0 | H3 | ewma_tpe320 | qlearn | -0.005 | 0.42 | -0.0001796 [-0.0005942, 6.169e-06] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H3 | static_tpe320 | learned | +0.123 | 2.9e-07 | 0.001122 [0.0007972, 0.001514] | no detected difference | True |
| collapse_moderate_coupled | 20.0 | H3 | static_tpe320 | qlearn | -0.035 | 0.002 | -0.0009913 [-0.001673, -0.0005262] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H4 | rova_tpe320 | rova_tpe80 | +0.000 | 1 | 0 [0, 0] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H4 | ewma_tpe320 | ewma_tpe80 | -0.014 | 0.064 | -0.0002663 [-0.0007021, -6.119e-05] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H4 | static_tpe320 | static_tpe80 | -0.060 | 0.78 | 3.609e-05 [-0.0003396, 0.0004844] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H5 | rova_tpe320 | rova | -0.085 | 0.00042 | -0.001936 [-0.00444, -0.001001] | no detected difference | False |
| collapse_moderate_coupled | 20.0 | H5 | ewma_tpe320 | ewma | -1.000 | 1.6e-11 | -1.199 [-1.272, -1.124] | ewma_tpe320 lower-regret | True |
| collapse_moderate_coupled | 20.0 | H5 | static_tpe320 | static | -1.000 | 1.6e-11 | -0.9284 [-1.014, -0.8493] | static_tpe320 lower-regret | True |

## Decision rules at the final budget (A1-family significance)

- rova_tpe320_vs_static_tpe320: operating-condition-dependent advantage; DR8 False; c=0.5: static_tpe320 superior; c=1.5: static_tpe320 superior; c=3.5: static_tpe320 superior; c=8.0: static_tpe320 superior; c=20.0: no superiority claim; crossovers {"favorable_hmm_coupled": [], "unfavorable_oscillation_uncoupled": [], "collapse_moderate_coupled": []}
- rova_tpe320_vs_ewma_tpe320: operating-condition-dependent advantage; DR8 False; c=0.5: ewma_tpe320 superior; c=1.5: no superiority claim; c=3.5: no superiority claim; c=8.0: no superiority claim; c=20.0: no superiority claim; crossovers {"favorable_hmm_coupled": [1.6565489773565274, 6.375448229120042, 19.805994528448117], "unfavorable_oscillation_uncoupled": [2.0047140184448575, 19.999999999999996], "collapse_moderate_coupled": []}
- rova_tpe320_vs_A0: operating-condition-dependent advantage; DR8 False; c=0.5: rova_tpe320 superior; c=1.5: rova_tpe320 superior; c=3.5: rova_tpe320 superior; c=8.0: no superiority claim; c=20.0: no superiority claim; crossovers {"favorable_hmm_coupled": [19.999999999999996], "unfavorable_oscillation_uncoupled": [7.999999999999998], "collapse_moderate_coupled": [19.999999999999996]}

## A2 statistics on A1 comparisons

| env | c | family | pair | label | two-stage CI (d) | sign-flip p | n_eff | generalization |
|---|---|---|---|---|---|---|---|---|
| favorable_hmm_coupled | 0.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.0005853, 0.01033] | 0.25 | 5.32 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [0.0004927, 0.0103] | 0.25 | 5.31 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.0003236, 4.393e-05] | 0.812 | 5.82 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 0.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.4983, -0.4762] | 0.0625 | 46.1 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.5011, -0.4842] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.5011, -0.4843] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.001412, 0.0112] | 0.0625 | 5.3 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H3 | rova_tpe320–qlearn | qlearn lower-regret | [0.0003578, 0.01015] | 0.25 | 5.32 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.0007599, 0.001244] | 0.0625 | 8.75 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.0002746, 0.0001228] | 0.375 | 8.56 | not established across tuning runs |
| favorable_hmm_coupled | 0.5 | H3 | static_tpe320–learned | learned lower-regret | [0.0007751, 0.0009498] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.0002765, -0.0001452] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.01489, -0.004279] | 0.0625 | 6.22 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.007048, -0.0009897] | 0.0625 | 6.4 | generalizes across tuning runs |
| favorable_hmm_coupled | 0.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.001139, -0.0001396] | 0.0625 | 6.15 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.0005425, 0.00321] | 0.0625 | 5.35 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [0.000215, 0.003084] | 0.125 | 5.37 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H1_320 | static_tpe320–ewma_tpe320 | static_tpe320 lower-regret | [-0.000535, 3.915e-05] | 0.312 | 6.16 | not established across tuning runs |
| favorable_hmm_coupled | 1.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.2848, -0.2625] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.2857, -0.2641] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.2859, -0.2642] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.0009313, 0.003565] | 0.0625 | 5.37 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H3 | rova_tpe320–qlearn | no detected difference | [-0.006014, 0.002796] | 0.938 | 5.26 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 1.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.0003804, 0.0008498] | 0.0625 | 7.23 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.006839, 0.0002734] | 0.438 | 5.25 | not established across tuning runs |
| favorable_hmm_coupled | 1.5 | H3 | static_tpe320–learned | learned lower-regret | [0.000279, 0.0004764] | 0.0625 | 17.6 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.006992, -0.000149] | 0.0625 | 5.25 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.03147, -0.004522] | 0.0625 | 5.18 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.01112, -0.002982] | 0.0625 | 5.21 | generalizes across tuning runs |
| favorable_hmm_coupled | 1.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.003099, -0.001] | 0.0625 | 5.39 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.002877, 0.04775] | 0.0625 | 5.51 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-0.04839, 0.03139] | 0.875 | 5.34 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 3.5 | H1_320 | static_tpe320–ewma_tpe320 | static_tpe320 lower-regret | [-0.06659, -0.001157] | 0.188 | 5.5 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.07499, -0.03918] | 0.0625 | 10.6 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.08412, -0.01454] | 0.125 | 6.43 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.09152, -0.07079] | 0.0625 | 42.4 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.007183, 0.05221] | 0.0625 | 5.56 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H3 | rova_tpe320–qlearn | qlearn lower-regret | [0.0003619, 0.04475] | 0.25 | 5.58 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.00566, 0.07101] | 0.0625 | 5.53 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H3 | ewma_tpe320–qlearn | qlearn lower-regret | [-0.002295, 0.06435] | 0.375 | 5.47 | not established across tuning runs |
| favorable_hmm_coupled | 3.5 | H3 | static_tpe320–learned | learned lower-regret | [0.003934, 0.004965] | 0.0625 | 38.9 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.003792, -0.001404] | 0.0625 | 17.6 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.02592, -0.004556] | 0.125 | 5.52 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.02184, -0.001117] | 0.25 | 5.78 | generalizes across tuning runs |
| favorable_hmm_coupled | 3.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.004943, -0.001675] | 0.0625 | 6.3 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.009257, 0.01428] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [-0.001225, 0.009259] | 0.375 | 9.53 | not established across tuning runs |
| favorable_hmm_coupled | 8.0 | H1_320 | static_tpe320–ewma_tpe320 | static_tpe320 lower-regret | [-0.01436, -0.001929] | 0.25 | 8.46 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H2 | rova_tpe320–A0 | no detected difference | [-0.002101, 0] | 0.5 | 8.89 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 8.0 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.01044, -4.116e-05] | 0.25 | 10.5 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.01578, -0.009758] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H3 | rova_tpe320–learned | learned lower-regret | [0.0119, 0.01742] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H3 | rova_tpe320–qlearn | qlearn lower-regret | [0.004841, 0.01095] | 0.0625 | 28 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H3 | ewma_tpe320–learned | learned lower-regret | [0.004791, 0.01728] | 0.0625 | 9.29 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H3 | ewma_tpe320–qlearn | no detected difference | [-0.002145, 0.01042] | 0.375 | 7.26 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 8.0 | H3 | static_tpe320–learned | learned lower-regret | [0.00254, 0.003322] | 0.0625 | 60 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.006073, -0.002131] | 0.0625 | 14.6 | generalizes across tuning runs |
| favorable_hmm_coupled | 8.0 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [-0.001775, 0] | 1 | 7.39 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 8.0 | H4 | ewma_tpe320–ewma_tpe80 | no detected difference | [-0.003624, -0.0003817] | 0.125 | 13.1 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 8.0 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.003852, -0.001301] | 0.0625 | 14.6 | generalizes across tuning runs |
| favorable_hmm_coupled | 20.0 | H1_320 | rova_tpe320–static_tpe320 | no detected difference | [0.0002988, 0.0008415] | 0.0625 | 49.6 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-0.0001654, 1.203e-05] | 0.75 | 60 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.0008748, -0.0003149] | 0.0625 | 54.5 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H2 | rova_tpe320–A0 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H2 | ewma_tpe320–A0 | no detected difference | [-1.203e-05, 0.0001654] | 0.75 | 60 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H2 | static_tpe320–A0 | no detected difference | [-0.0008415, -0.0002988] | 0.0625 | 49.6 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H3 | rova_tpe320–learned | learned lower-regret | [0.0005631, 0.001526] | 0.0625 | 41.3 | generalizes across tuning runs |
| favorable_hmm_coupled | 20.0 | H3 | rova_tpe320–qlearn | rova_tpe320 lower-regret | [-0.007433, 0] | 0.5 | 6.56 | not established across tuning runs |
| favorable_hmm_coupled | 20.0 | H3 | ewma_tpe320–learned | learned lower-regret | [0.0005856, 0.001572] | 0.0625 | 39.3 | generalizes across tuning runs |
| favorable_hmm_coupled | 20.0 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.007399, 0.0001423] | 0.625 | 6.57 | not established across tuning runs |
| favorable_hmm_coupled | 20.0 | H3 | static_tpe320–learned | no detected difference | [4.082e-05, 0.0008235] | 0.125 | 17.9 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.00799, -0.0003458] | 0.0625 | 6.57 | generalizes across tuning runs |
| favorable_hmm_coupled | 20.0 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H4 | ewma_tpe320–ewma_tpe80 | no detected difference | [-0.00468, 8.194e-07] | 0.125 | 5.94 | no per-world label (no detected difference) |
| favorable_hmm_coupled | 20.0 | H4 | static_tpe320–static_tpe80 | no detected difference | [-0.0006415, -0.0001032] | 0.0625 | 19.2 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 0.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.0003219, 0.0006574] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-0.0002081, 0.0001725] | 1 | 9.61 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 0.5 | H1_320 | static_tpe320–ewma_tpe320 | static_tpe320 lower-regret | [-0.0007329, -0.0002831] | 0.0625 | 57.4 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.4442, -0.4105] | 0.0625 | 33.7 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.4443, -0.4104] | 0.0625 | 33.3 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.4448, -0.4111] | 0.0625 | 33.4 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.0004083, 0.0007939] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | rova_tpe320–qlearn | no detected difference | [6.784e-05, 0.0004669] | 0.125 | 30.1 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.0003544, 0.0008764] | 0.0625 | 39.9 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | ewma_tpe320–qlearn | no detected difference | [4.072e-05, 0.0005303] | 0.125 | 19.1 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | static_tpe320–learned | learned lower-regret | [3.069e-05, 0.00022] | 0.125 | 17.6 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.0004091, -6.847e-05] | 0.0625 | 26.4 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 0.5 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [-0.0002297, 0] | 0.5 | 9.86 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 0.5 | H4 | ewma_tpe320–ewma_tpe80 | no detected difference | [-1.107e-05, 7.48e-06] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 0.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.0003195, -0.0001252] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.0009626, 0.02263] | 0.0625 | 5.36 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-0.06019, 0.01875] | 0.75 | 5.99 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 1.5 | H1_320 | static_tpe320–ewma_tpe320 | static_tpe320 lower-regret | [-0.06417, -0.0003863] | 0.0625 | 6.25 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.2235, -0.1817] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.2169, -0.1482] | 0.0625 | 30.4 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.2314, -0.1903] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.001199, 0.02312] | 0.0625 | 5.34 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | rova_tpe320–qlearn | no detected difference | [-0.006704, 0.01935] | 0.875 | 5.27 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.0007614, 0.06452] | 0.0625 | 6.27 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | ewma_tpe320–qlearn | no detected difference | [-0.001907, 0.05543] | 0.5 | 6.93 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | static_tpe320–learned | learned lower-regret | [7.693e-05, 0.0005963] | 0.0625 | 39.1 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.009085, -0.001467] | 0.0625 | 8.02 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.04422, -0.01365] | 0.0625 | 6.81 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.04158, 0.0001047] | 0.188 | 5.73 | not established across tuning runs |
| unfavorable_oscillation_uncoupled | 1.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.0006111, 1.004e-05] | 0.188 | 13.4 | not established across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.01947, 0.06608] | 0.0625 | 24.9 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [0.003524, 0.05967] | 0.125 | 12.5 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.0389, 0.0006325] | 0.875 | 14.8 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 3.5 | H2 | rova_tpe320–A0 | no detected difference | [-0.007659, 0] | 1 | 14 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 3.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.05997, -0.009344] | 0.125 | 13.9 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.07039, -0.02004] | 0.0625 | 26.2 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.02437, 0.07112] | 0.0625 | 25.1 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | rova_tpe320–qlearn | qlearn lower-regret | [0.01464, 0.05672] | 0.0625 | 17.9 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.003655, 0.04449] | 0.0625 | 14.4 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.007892, 0.02564] | 1 | 12 | not established across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | static_tpe320–learned | learned lower-regret | [0.003834, 0.006042] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.01434, -0.003837] | 0.0625 | 50.4 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [-0.007585, 0.0004209] | 1 | 13.8 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 3.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.006796, -0.0005066] | 0.125 | 10.5 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 3.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.006096, -0.002147] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 8.0 | H1_320 | rova_tpe320–static_tpe320 | no detected difference | [0.001021, 0.008576] | 0.0625 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-0.0001192, 0.0004446] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.008507, -0.001023] | 0.0625 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H2 | rova_tpe320–A0 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H2 | ewma_tpe320–A0 | no detected difference | [-0.0004446, 0.0001192] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H2 | static_tpe320–A0 | no detected difference | [-0.008576, -0.001021] | 0.0625 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | rova_tpe320–learned | no detected difference | [0.002108, 0.01359] | 0.0625 | 45 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | rova_tpe320–qlearn | no detected difference | [-0.002188, 0] | 0.5 | 27.2 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | ewma_tpe320–learned | no detected difference | [0.002096, 0.01348] | 0.0625 | 42.7 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | ewma_tpe320–qlearn | no detected difference | [-0.002229, 0] | 0.25 | 32.6 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | static_tpe320–learned | learned lower-regret | [0.0007597, 0.005202] | 0.0625 | 26.5 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 8.0 | H3 | static_tpe320–qlearn | no detected difference | [-0.01056, -0.001178] | 0.0625 | 52.7 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [-0.0004157, 0] | 1 | 23.7 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H4 | ewma_tpe320–ewma_tpe80 | no detected difference | [-5.688e-05, 0.0001578] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 8.0 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.003553, -0.0007363] | 0.0625 | 60 | generalizes across tuning runs |
| unfavorable_oscillation_uncoupled | 20.0 | H1_320 | rova_tpe320–static_tpe320 | no detected difference | [-0.0003954, 0.001024] | 0.5 | 26.4 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.001024, 0.0003954] | 0.5 | 26.4 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H2 | rova_tpe320–A0 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H2 | ewma_tpe320–A0 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H2 | static_tpe320–A0 | no detected difference | [-0.001024, 0.0003954] | 0.5 | 26.4 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | rova_tpe320–learned | no detected difference | [-0.0001161, 0.0002073] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | rova_tpe320–qlearn | no detected difference | [-0.003939, 0] | 0.5 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | ewma_tpe320–learned | no detected difference | [-0.0001161, 0.0002073] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | ewma_tpe320–qlearn | no detected difference | [-0.003939, 0] | 0.5 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | static_tpe320–learned | no detected difference | [-0.001025, 0.0004462] | 0.625 | 27.2 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H3 | static_tpe320–qlearn | no detected difference | [-0.003855, 1.308e-06] | 0.125 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H4 | ewma_tpe320–ewma_tpe80 | no detected difference | [-0.0005014, 0] | 1 | 60 | no per-world label (no detected difference) |
| unfavorable_oscillation_uncoupled | 20.0 | H4 | static_tpe320–static_tpe80 | no detected difference | [-0.0001594, 0.0002983] | 0.438 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 0.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.0004391, 0.001491] | 0.0625 | 22 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [0.0005519, 0.001581] | 0.0625 | 19.7 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [4.019e-05, 0.0001925] | 0.0625 | 34 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 0.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.3967, -0.3641] | 0.0625 | 55.7 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.3975, -0.3653] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.3974, -0.3651] | 0.0625 | 59.9 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.001078, 0.001954] | 0.0625 | 23.8 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H3 | rova_tpe320–qlearn | no detected difference | [-0.005966, 0.0008478] | 0.625 | 6.19 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 0.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.0002888, 0.0006584] | 0.0625 | 39.6 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.007, -0.0003453] | 0.0625 | 5.6 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H3 | static_tpe320–learned | learned lower-regret | [0.0003603, 0.0008026] | 0.0625 | 35.6 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.006867, -0.0002069] | 0.188 | 5.58 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.001317, 7.697e-05] | 0.25 | 9.27 | not established across tuning runs |
| collapse_moderate_coupled | 0.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.001514, -0.0008334] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 0.5 | H4 | static_tpe320–static_tpe80 | no detected difference | [-0.0004672, -1.146e-05] | 0.125 | 41.1 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 1.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.0001162, 0.000403] | 0.0625 | 11.4 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-0.0001394, 0.0003171] | 0.688 | 8.75 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 1.5 | H1_320 | static_tpe320–ewma_tpe320 | static_tpe320 lower-regret | [-0.0003165, -1.659e-05] | 0.188 | 14.4 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.2765, -0.2542] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.2767, -0.2542] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.2768, -0.2544] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.0001666, 0.0005024] | 0.0625 | 12.5 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H3 | rova_tpe320–qlearn | rova_tpe320 lower-regret | [-0.02056, -0.001323] | 0.0625 | 5.77 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.000102, 0.0003673] | 0.0625 | 21.9 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.02085, -0.001344] | 0.0625 | 5.72 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H3 | static_tpe320–learned | learned lower-regret | [3.025e-05, 0.0001188] | 0.0625 | 52.1 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.02097, -0.001477] | 0.0625 | 5.73 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.005628, -0.002262] | 0.0625 | 7.79 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.002007, -0.0007951] | 0.0625 | 12.5 | generalizes across tuning runs |
| collapse_moderate_coupled | 1.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.0002086, -4.964e-05] | 0.0625 | 18 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.001902, 0.04525] | 0.0625 | 5.56 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [0.001724, 0.04522] | 0.0625 | 5.54 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.0003687, 0.0001495] | 0.375 | 51.2 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 3.5 | H2 | rova_tpe320–A0 | rova_tpe320 lower-regret | [-0.09212, -0.05037] | 0.0625 | 19.3 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.1082, -0.07701] | 0.0625 | 52.7 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.1084, -0.07712] | 0.0625 | 52.6 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H3 | rova_tpe320–learned | learned lower-regret | [0.005184, 0.04837] | 0.0625 | 5.57 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H3 | rova_tpe320–qlearn | no detected difference | [-0.01699, 0.03601] | 0.938 | 5.58 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 3.5 | H3 | ewma_tpe320–learned | learned lower-regret | [0.002709, 0.004153] | 0.0625 | 59.6 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.03557, -0.001605] | 0.0625 | 6.32 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H3 | static_tpe320–learned | learned lower-regret | [0.002675, 0.003933] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.0357, -0.001586] | 0.0625 | 6.3 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H4 | rova_tpe320–rova_tpe80 | rova_tpe320 lower-regret | [-0.02763, -0.01085] | 0.0625 | 10.1 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.01731, -0.004497] | 0.0625 | 5.9 | generalizes across tuning runs |
| collapse_moderate_coupled | 3.5 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.006463, -0.001592] | 0.0625 | 7.39 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H1_320 | rova_tpe320–static_tpe320 | static_tpe320 lower-regret | [0.01208, 0.02602] | 0.0625 | 38.6 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H1_320 | rova_tpe320–ewma_tpe320 | ewma_tpe320 lower-regret | [0.01119, 0.02366] | 0.0625 | 50.4 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.003536, 0.0002151] | 0.375 | 11.8 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 8.0 | H2 | rova_tpe320–A0 | no detected difference | [-0.001016, 0] | 0.5 | 19.2 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 8.0 | H2 | ewma_tpe320–A0 | ewma_tpe320 lower-regret | [-0.02394, -0.01159] | 0.0625 | 60 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H2 | static_tpe320–A0 | static_tpe320 lower-regret | [-0.02624, -0.01258] | 0.0625 | 44.5 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H3 | rova_tpe320–learned | learned lower-regret | [0.0164, 0.03166] | 0.0625 | 33.5 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H3 | rova_tpe320–qlearn | qlearn lower-regret | [0.005359, 0.0174] | 0.0625 | 24 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H3 | ewma_tpe320–learned | learned lower-regret | [0.004406, 0.008994] | 0.0625 | 14.8 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H3 | ewma_tpe320–qlearn | ewma_tpe320 lower-regret | [-0.01015, -0.001219] | 0.125 | 14.4 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H3 | static_tpe320–learned | learned lower-regret | [0.003905, 0.006063] | 0.0625 | 58.4 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H3 | static_tpe320–qlearn | static_tpe320 lower-regret | [-0.01237, -0.003172] | 0.0625 | 14.9 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [-0.001016, 0] | 0.5 | 19.2 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 8.0 | H4 | ewma_tpe320–ewma_tpe80 | ewma_tpe320 lower-regret | [-0.008704, -0.001713] | 0.0625 | 14.7 | generalizes across tuning runs |
| collapse_moderate_coupled | 8.0 | H4 | static_tpe320–static_tpe80 | static_tpe320 lower-regret | [-0.005162, -0.001284] | 0.0625 | 24.5 | generalizes across tuning runs |
| collapse_moderate_coupled | 20.0 | H1_320 | rova_tpe320–static_tpe320 | no detected difference | [0.0003531, 0.001768] | 0.0625 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H1_320 | rova_tpe320–ewma_tpe320 | no detected difference | [-1.969e-05, 0.0006317] | 0.5 | 47.7 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H1_320 | static_tpe320–ewma_tpe320 | no detected difference | [-0.001704, -6.517e-05] | 0.125 | 33.7 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H2 | rova_tpe320–A0 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H2 | ewma_tpe320–A0 | no detected difference | [-0.0006317, 1.969e-05] | 0.5 | 47.7 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H2 | static_tpe320–A0 | no detected difference | [-0.001768, -0.0003531] | 0.0625 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H3 | rova_tpe320–learned | no detected difference | [0.001328, 0.003031] | 0.0625 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H3 | rova_tpe320–qlearn | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H3 | ewma_tpe320–learned | no detected difference | [0.00112, 0.002915] | 0.0625 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H3 | ewma_tpe320–qlearn | no detected difference | [-0.0006317, 1.969e-05] | 0.5 | 47.7 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H3 | static_tpe320–learned | no detected difference | [0.0007215, 0.001577] | 0.0625 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H3 | static_tpe320–qlearn | no detected difference | [-0.001768, -0.0003531] | 0.0625 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H4 | rova_tpe320–rova_tpe80 | no detected difference | [0, 0] | 1 | 60 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H4 | ewma_tpe320–ewma_tpe80 | no detected difference | [-0.000768, 0.0001153] | 0.5 | 29.6 | no per-world label (no detected difference) |
| collapse_moderate_coupled | 20.0 | H4 | static_tpe320–static_tpe80 | no detected difference | [-0.0007121, 0.0008323] | 1 | 16.7 | no per-world label (no detected difference) |
