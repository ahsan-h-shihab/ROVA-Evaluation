import os
from playwright.sync_api import sync_playwright
from PIL import Image

HTML = "file://" + os.path.abspath("index.html")
TARGET_PX = 4296      # 7.16in @ 600 dpi
PDF_W_IN = 7.16

with sync_playwright() as p:
    b = p.chromium.launch()
    pg0 = b.new_page()
    pg0.goto(HTML); pg0.wait_for_function("window.__ready===true", timeout=15000); pg0.wait_for_timeout(150)
    info = pg0.evaluate("""() => {
        const c = document.getElementById('canvas').getBoundingClientRect();
        const bx = document.querySelector('.cbox').getBoundingClientRect();
        const cards = [];
        for(let i=1;i<=5;i++){
            const r = document.getElementById('card'+i).getBoundingClientRect();
            cards.push({i, top:Math.round(r.top-c.top), bottom:Math.round(r.bottom-c.top),
                        center:Math.round((r.top+r.bottom)/2-c.top), h:Math.round(r.height)});
        }
        return {w:Math.round(c.width), h:Math.round(c.height), boxBottom:Math.round(bx.bottom-c.top), boxTop:Math.round(bx.top-c.top), cards};
    }""")
    pg0.close()
    cw, ch = info['w'], info['h']
    print("canvas", cw, "x", ch, "| box top", info['boxTop'], "bottom", info['boxBottom'], "| margin below box", ch-info['boxBottom'])
    for cd in info['cards']:
        print(f"  card{cd['i']}: top={cd['top']} bottom={cd['bottom']} center={cd['center']} h={cd['h']}")

    dsf = TARGET_PX / cw
    pg = b.new_page(viewport={"width":cw, "height":ch}, device_scale_factor=dsf)
    pg.goto(HTML); pg.wait_for_function("window.__ready===true", timeout=15000); pg.wait_for_timeout(200)
    pg.query_selector("#canvas").screenshot(path="figure_600dpi.png")

    scale = PDF_W_IN * 96 / cw
    pdf_h = ch * scale / 96
    pg.pdf(path="figure_vector.pdf", width=f"{PDF_W_IN}in", height=f"{pdf_h:.3f}in",
           scale=scale, print_background=True,
           margin={"top":"0","bottom":"0","left":"0","right":"0"})
    b.close()

im = Image.open("figure_600dpi.png")
print("rendered:", im.size, "| effective dpi:", round(im.size[0]/PDF_W_IN))
w = 1500
prev = im.resize((w, round(im.size[1]*w/im.size[0])), Image.LANCZOS)
prev.convert("RGB").save("preview.png")
print("preview:", prev.size)
